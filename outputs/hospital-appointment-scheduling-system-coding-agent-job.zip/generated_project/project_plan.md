# Build a hospital appointment scheduling system

## Summary
A medium complexity healthcare workflow improvement in the healthcare domain.

- Domain: healthcare
- Project type: healthcare workflow improvement
- Complexity: medium
- Status: plan_generated

## Warnings
- AI planning failed or was unavailable; generated deterministic mock plan instead. Reason: Gemini request failed: 504 The request timed out. Please try again.

## Phases
### P1: Workflow Discovery
Understand current clinical or administrative workflow.

Estimated duration: 1-2 weeks

Tasks:
- T1: Map current workflow - Document steps, roles, handoffs, and pain points.
- T2: Identify compliance constraints - Capture privacy, security, and policy requirements. Dependencies: T1.

Deliverables:
- workflow map
- compliance notes

### P2: Solution Design
Design process and technology changes without assuming unsafe integrations.

Estimated duration: 1-2 weeks

Tasks:
- T3: Define future-state workflow - Design improved scheduling, reminders, and staff responsibilities. Dependencies: T2.
- T4: Plan pilot - Define pilot scope, success metrics, training, and rollback plan. Dependencies: T3.

Deliverables:
- future workflow
- pilot plan

### P3: Pilot and Measurement
Launch a controlled pilot and measure operational impact.

Estimated duration: 2-4 weeks

Tasks:
- T5: Train staff - Prepare staff to execute the updated workflow. Dependencies: T4.
- T6: Measure outcomes - Track backlog, reminder success, patient experience, and staff workload. Dependencies: T5.

Deliverables:
- pilot results
- rollout recommendation

## Milestones
- M1: Workflow Discovery Complete (P1)
- M2: Solution Design Complete (P2)
- M3: Pilot and Measurement Complete (P3)

## Risks
- R1: Project scope may expand beyond the initial plan. Mitigation: Maintain an explicit MVP scope and review changes before adding work.
- R2: Missing stakeholder input may lead to rework. Mitigation: Confirm requirements and acceptance criteria before implementation.
- R3: Privacy or compliance requirements may constrain the solution. Mitigation: Run compliance review before pilot or integration work.

## Recommendations
- Planning: Validate assumptions before execution starts.
- Delivery: Use milestones as decision gates before expanding scope.

## Assumptions
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.

## Engineering Prompt Pack
### Frontend Engineer implementation prompt

**Target Role:** Frontend Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Implement the frontend experience for the planned project while preserving the validated project scope.

**Related Phases:**
- P1
- P2
- P3

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- AI planning failed or was unavailable; generated deterministic mock plan instead. Reason: Gemini request failed: 504 The request timed out. Please try again.

**Acceptance Criteria:**
- The Frontend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Map current workflow is reviewed and accepted by the project lead.
- Identify compliance constraints is reviewed and accepted by the project lead.
- Define future-state workflow is reviewed and accepted by the project lead.

**Prompt:**
```text
You are a senior frontend engineer responsible for implementing the user-facing experience.

## Project Context
Project name: Build a hospital appointment scheduling system
Project description: Build a hospital appointment scheduling system
Domain: healthcare
Project type: healthcare workflow improvement
Complexity: medium
Summary: A medium complexity healthcare workflow improvement in the healthcare domain.

## Your Role
Frontend Engineer

## Goal
Implement the frontend experience for the planned project while preserving the validated project scope.

## Technical Scope
UI workflows, client-side validation, accessibility, responsive behavior, and integration points with backend APIs.

Relevant tasks:
- T1: Map current workflow - Document steps, roles, handoffs, and pain points.
- T2: Identify compliance constraints - Capture privacy, security, and policy requirements.
- T3: Define future-state workflow - Design improved scheduling, reminders, and staff responsibilities.
- T4: Plan pilot - Define pilot scope, success metrics, training, and rollback plan.
- T5: Train staff - Prepare staff to execute the updated workflow.
- T6: Measure outcomes - Track backlog, reminder success, patient experience, and staff workload.

Risks to account for:
- Project scope may expand beyond the initial plan.
- Missing stakeholder input may lead to rework.
- Privacy or compliance requirements may constrain the solution.

Recommendations to preserve:
- Validate assumptions before execution starts.
- Use milestones as decision gates before expanding scope.

Assumptions to keep visible:
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.

## Related Phases
- P1: Workflow Discovery (1-2 weeks) - Understand current clinical or administrative workflow.
- P2: Solution Design (1-2 weeks) - Design process and technology changes without assuming unsafe integrations.
- P3: Pilot and Measurement (2-4 weeks) - Launch a controlled pilot and measure operational impact.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- AI planning failed or was unavailable; generated deterministic mock plan instead. Reason: Gemini request failed: 504 The request timed out. Please try again.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Frontend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Map current workflow is reviewed and accepted by the project lead.
- Identify compliance constraints is reviewed and accepted by the project lead.
- Define future-state workflow is reviewed and accepted by the project lead.

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### Backend Engineer implementation prompt

**Target Role:** Backend Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Implement backend services that support the planned workflows, validation rules, and task sequencing.

**Related Phases:**
- P1
- P2
- P3

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- AI planning failed or was unavailable; generated deterministic mock plan instead. Reason: Gemini request failed: 504 The request timed out. Please try again.

**Acceptance Criteria:**
- The Backend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Map current workflow is reviewed and accepted by the project lead.
- Identify compliance constraints is reviewed and accepted by the project lead.
- Define future-state workflow is reviewed and accepted by the project lead.

**Prompt:**
```text
You are a senior backend engineer responsible for building the application services and API layer.

## Project Context
Project name: Build a hospital appointment scheduling system
Project description: Build a hospital appointment scheduling system
Domain: healthcare
Project type: healthcare workflow improvement
Complexity: medium
Summary: A medium complexity healthcare workflow improvement in the healthcare domain.

## Your Role
Backend Engineer

## Goal
Implement backend services that support the planned workflows, validation rules, and task sequencing.

## Technical Scope
API contracts, service logic, validation, error handling, integrations, and backend test coverage.

Relevant tasks:
- T1: Map current workflow - Document steps, roles, handoffs, and pain points.
- T2: Identify compliance constraints - Capture privacy, security, and policy requirements.
- T3: Define future-state workflow - Design improved scheduling, reminders, and staff responsibilities.
- T4: Plan pilot - Define pilot scope, success metrics, training, and rollback plan.
- T5: Train staff - Prepare staff to execute the updated workflow.
- T6: Measure outcomes - Track backlog, reminder success, patient experience, and staff workload.

Risks to account for:
- Project scope may expand beyond the initial plan.
- Missing stakeholder input may lead to rework.
- Privacy or compliance requirements may constrain the solution.

Recommendations to preserve:
- Validate assumptions before execution starts.
- Use milestones as decision gates before expanding scope.

Assumptions to keep visible:
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.

## Related Phases
- P1: Workflow Discovery (1-2 weeks) - Understand current clinical or administrative workflow.
- P2: Solution Design (1-2 weeks) - Design process and technology changes without assuming unsafe integrations.
- P3: Pilot and Measurement (2-4 weeks) - Launch a controlled pilot and measure operational impact.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- AI planning failed or was unavailable; generated deterministic mock plan instead. Reason: Gemini request failed: 504 The request timed out. Please try again.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Backend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Map current workflow is reviewed and accepted by the project lead.
- Identify compliance constraints is reviewed and accepted by the project lead.
- Define future-state workflow is reviewed and accepted by the project lead.

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### Database Engineer implementation prompt

**Target Role:** Database Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Define storage structures that support the project requirements without inventing unsupported data sources.

**Related Phases:**
- P1
- P2
- P3

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- AI planning failed or was unavailable; generated deterministic mock plan instead. Reason: Gemini request failed: 504 The request timed out. Please try again.

**Acceptance Criteria:**
- The Database Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Map current workflow is reviewed and accepted by the project lead.
- Identify compliance constraints is reviewed and accepted by the project lead.
- Define future-state workflow is reviewed and accepted by the project lead.

**Prompt:**
```text
You are a senior database engineer responsible for designing the data model and persistence approach.

## Project Context
Project name: Build a hospital appointment scheduling system
Project description: Build a hospital appointment scheduling system
Domain: healthcare
Project type: healthcare workflow improvement
Complexity: medium
Summary: A medium complexity healthcare workflow improvement in the healthcare domain.

## Your Role
Database Engineer

## Goal
Define storage structures that support the project requirements without inventing unsupported data sources.

## Technical Scope
Entities, relationships, indexes, migrations, data quality checks, retention needs, and backup assumptions.

Relevant tasks:
- T1: Map current workflow - Document steps, roles, handoffs, and pain points.
- T2: Identify compliance constraints - Capture privacy, security, and policy requirements.
- T3: Define future-state workflow - Design improved scheduling, reminders, and staff responsibilities.
- T4: Plan pilot - Define pilot scope, success metrics, training, and rollback plan.
- T5: Train staff - Prepare staff to execute the updated workflow.
- T6: Measure outcomes - Track backlog, reminder success, patient experience, and staff workload.

Risks to account for:
- Project scope may expand beyond the initial plan.
- Missing stakeholder input may lead to rework.
- Privacy or compliance requirements may constrain the solution.

Recommendations to preserve:
- Validate assumptions before execution starts.
- Use milestones as decision gates before expanding scope.

Assumptions to keep visible:
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.

## Related Phases
- P1: Workflow Discovery (1-2 weeks) - Understand current clinical or administrative workflow.
- P2: Solution Design (1-2 weeks) - Design process and technology changes without assuming unsafe integrations.
- P3: Pilot and Measurement (2-4 weeks) - Launch a controlled pilot and measure operational impact.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- AI planning failed or was unavailable; generated deterministic mock plan instead. Reason: Gemini request failed: 504 The request timed out. Please try again.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Database Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Map current workflow is reviewed and accepted by the project lead.
- Identify compliance constraints is reviewed and accepted by the project lead.
- Define future-state workflow is reviewed and accepted by the project lead.

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### QA / Testing Engineer implementation prompt

**Target Role:** QA / Testing Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Create a practical test strategy for the project phases, risks, acceptance criteria, and release workflow.

**Related Phases:**
- P1
- P2
- P3

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- AI planning failed or was unavailable; generated deterministic mock plan instead. Reason: Gemini request failed: 504 The request timed out. Please try again.

**Acceptance Criteria:**
- The QA / Testing Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Map current workflow is reviewed and accepted by the project lead.
- Identify compliance constraints is reviewed and accepted by the project lead.
- Define future-state workflow is reviewed and accepted by the project lead.

**Prompt:**
```text
You are a senior QA engineer responsible for validating the implementation against the plan.

## Project Context
Project name: Build a hospital appointment scheduling system
Project description: Build a hospital appointment scheduling system
Domain: healthcare
Project type: healthcare workflow improvement
Complexity: medium
Summary: A medium complexity healthcare workflow improvement in the healthcare domain.

## Your Role
QA / Testing Engineer

## Goal
Create a practical test strategy for the project phases, risks, acceptance criteria, and release workflow.

## Technical Scope
Functional tests, regression tests, edge cases, acceptance criteria validation, risk-based testing, and defect reporting.

Relevant tasks:
- T1: Map current workflow - Document steps, roles, handoffs, and pain points.
- T2: Identify compliance constraints - Capture privacy, security, and policy requirements.
- T3: Define future-state workflow - Design improved scheduling, reminders, and staff responsibilities.
- T4: Plan pilot - Define pilot scope, success metrics, training, and rollback plan.
- T5: Train staff - Prepare staff to execute the updated workflow.
- T6: Measure outcomes - Track backlog, reminder success, patient experience, and staff workload.

Risks to account for:
- Project scope may expand beyond the initial plan.
- Missing stakeholder input may lead to rework.
- Privacy or compliance requirements may constrain the solution.

Recommendations to preserve:
- Validate assumptions before execution starts.
- Use milestones as decision gates before expanding scope.

Assumptions to keep visible:
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.

## Related Phases
- P1: Workflow Discovery (1-2 weeks) - Understand current clinical or administrative workflow.
- P2: Solution Design (1-2 weeks) - Design process and technology changes without assuming unsafe integrations.
- P3: Pilot and Measurement (2-4 weeks) - Launch a controlled pilot and measure operational impact.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- AI planning failed or was unavailable; generated deterministic mock plan instead. Reason: Gemini request failed: 504 The request timed out. Please try again.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The QA / Testing Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Map current workflow is reviewed and accepted by the project lead.
- Identify compliance constraints is reviewed and accepted by the project lead.
- Define future-state workflow is reviewed and accepted by the project lead.

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### DevOps Engineer implementation prompt

**Target Role:** DevOps Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Plan environment, build, release, monitoring, and rollback work without deploying anything automatically.

**Related Phases:**
- P1
- P2
- P3

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- AI planning failed or was unavailable; generated deterministic mock plan instead. Reason: Gemini request failed: 504 The request timed out. Please try again.

**Acceptance Criteria:**
- The DevOps Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Map current workflow is reviewed and accepted by the project lead.
- Identify compliance constraints is reviewed and accepted by the project lead.
- Define future-state workflow is reviewed and accepted by the project lead.

**Prompt:**
```text
You are a senior DevOps engineer responsible for deployment readiness and operational workflow.

## Project Context
Project name: Build a hospital appointment scheduling system
Project description: Build a hospital appointment scheduling system
Domain: healthcare
Project type: healthcare workflow improvement
Complexity: medium
Summary: A medium complexity healthcare workflow improvement in the healthcare domain.

## Your Role
DevOps Engineer

## Goal
Plan environment, build, release, monitoring, and rollback work without deploying anything automatically.

## Technical Scope
Local development setup, CI checks, configuration, deployment plan, observability, release checklist, and rollback notes.

Relevant tasks:
- T1: Map current workflow - Document steps, roles, handoffs, and pain points.
- T2: Identify compliance constraints - Capture privacy, security, and policy requirements.
- T3: Define future-state workflow - Design improved scheduling, reminders, and staff responsibilities.
- T4: Plan pilot - Define pilot scope, success metrics, training, and rollback plan.
- T5: Train staff - Prepare staff to execute the updated workflow.
- T6: Measure outcomes - Track backlog, reminder success, patient experience, and staff workload.

Risks to account for:
- Project scope may expand beyond the initial plan.
- Missing stakeholder input may lead to rework.
- Privacy or compliance requirements may constrain the solution.

Recommendations to preserve:
- Validate assumptions before execution starts.
- Use milestones as decision gates before expanding scope.

Assumptions to keep visible:
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.

## Related Phases
- P1: Workflow Discovery (1-2 weeks) - Understand current clinical or administrative workflow.
- P2: Solution Design (1-2 weeks) - Design process and technology changes without assuming unsafe integrations.
- P3: Pilot and Measurement (2-4 weeks) - Launch a controlled pilot and measure operational impact.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- AI planning failed or was unavailable; generated deterministic mock plan instead. Reason: Gemini request failed: 504 The request timed out. Please try again.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The DevOps Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Map current workflow is reviewed and accepted by the project lead.
- Identify compliance constraints is reviewed and accepted by the project lead.
- Define future-state workflow is reviewed and accepted by the project lead.

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### Security Reviewer implementation prompt

**Target Role:** Security Reviewer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Review implementation plans for security, privacy, access control, data handling, and compliance risks.

**Related Phases:**
- P1
- P2
- P3

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- AI planning failed or was unavailable; generated deterministic mock plan instead. Reason: Gemini request failed: 504 The request timed out. Please try again.

**Acceptance Criteria:**
- The Security Reviewer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Map current workflow is reviewed and accepted by the project lead.
- Identify compliance constraints is reviewed and accepted by the project lead.
- Define future-state workflow is reviewed and accepted by the project lead.

**Prompt:**
```text
You are a senior security engineer responsible for reviewing the plan for security and privacy risks.

## Project Context
Project name: Build a hospital appointment scheduling system
Project description: Build a hospital appointment scheduling system
Domain: healthcare
Project type: healthcare workflow improvement
Complexity: medium
Summary: A medium complexity healthcare workflow improvement in the healthcare domain.

## Your Role
Security Reviewer

## Goal
Review implementation plans for security, privacy, access control, data handling, and compliance risks.

## Technical Scope
Threat modeling, authentication and authorization concerns, sensitive data handling, dependency risk, and secure defaults.

Relevant tasks:
- T1: Map current workflow - Document steps, roles, handoffs, and pain points.
- T2: Identify compliance constraints - Capture privacy, security, and policy requirements.
- T3: Define future-state workflow - Design improved scheduling, reminders, and staff responsibilities.
- T4: Plan pilot - Define pilot scope, success metrics, training, and rollback plan.
- T5: Train staff - Prepare staff to execute the updated workflow.
- T6: Measure outcomes - Track backlog, reminder success, patient experience, and staff workload.

Risks to account for:
- Project scope may expand beyond the initial plan.
- Missing stakeholder input may lead to rework.
- Privacy or compliance requirements may constrain the solution.

Recommendations to preserve:
- Validate assumptions before execution starts.
- Use milestones as decision gates before expanding scope.

Assumptions to keep visible:
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.

## Related Phases
- P1: Workflow Discovery (1-2 weeks) - Understand current clinical or administrative workflow.
- P2: Solution Design (1-2 weeks) - Design process and technology changes without assuming unsafe integrations.
- P3: Pilot and Measurement (2-4 weeks) - Launch a controlled pilot and measure operational impact.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- AI planning failed or was unavailable; generated deterministic mock plan instead. Reason: Gemini request failed: 504 The request timed out. Please try again.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Security Reviewer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Map current workflow is reviewed and accepted by the project lead.
- Identify compliance constraints is reviewed and accepted by the project lead.
- Define future-state workflow is reviewed and accepted by the project lead.

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

## Prompt Quality Evaluations
### Evaluation for EP1

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP2

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP3

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP4

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP5

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP6

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.
