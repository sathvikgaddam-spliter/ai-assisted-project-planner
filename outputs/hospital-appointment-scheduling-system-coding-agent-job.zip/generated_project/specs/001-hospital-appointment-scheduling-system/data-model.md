# Data Model

## User

**Fields**
- id
- created_at
- updated_at
- status
- email
- display_name
- role

**Validation Rules**
- id is required and stable
- created_at and updated_at are maintained
- status uses an explicit allowed value
- owner or permission checks apply where user-owned

**Relationships**
- User records relate to users, workflows, or parent records as required by the MVP.

## Account

**Fields**
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

**Validation Rules**
- id is required and stable
- created_at and updated_at are maintained
- status uses an explicit allowed value
- owner or permission checks apply where user-owned

**Relationships**
- Account records relate to users, workflows, or parent records as required by the MVP.

## Item

**Fields**
- id
- created_at
- updated_at
- status
- owner_id
- title
- description
- price

**Validation Rules**
- id is required and stable
- created_at and updated_at are maintained
- status uses an explicit allowed value
- owner or permission checks apply where user-owned

**Relationships**
- Item records relate to users, workflows, or parent records as required by the MVP.

## Activity

**Fields**
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

**Validation Rules**
- id is required and stable
- created_at and updated_at are maintained
- status uses an explicit allowed value
- owner or permission checks apply where user-owned

**Relationships**
- Activity records relate to users, workflows, or parent records as required by the MVP.

## Notification

**Fields**
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

**Validation Rules**
- id is required and stable
- created_at and updated_at are maintained
- status uses an explicit allowed value
- owner or permission checks apply where user-owned

**Relationships**
- Notification records relate to users, workflows, or parent records as required by the MVP.

## Task

**Fields**
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

**Validation Rules**
- id is required and stable
- created_at and updated_at are maintained
- status uses an explicit allowed value
- owner or permission checks apply where user-owned

**Relationships**
- Task records relate to users, workflows, or parent records as required by the MVP.

## Event

**Fields**
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

**Validation Rules**
- id is required and stable
- created_at and updated_at are maintained
- status uses an explicit allowed value
- owner or permission checks apply where user-owned

**Relationships**
- Event records relate to users, workflows, or parent records as required by the MVP.

## Reminder

**Fields**
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

**Validation Rules**
- id is required and stable
- created_at and updated_at are maintained
- status uses an explicit allowed value
- owner or permission checks apply where user-owned

**Relationships**
- Reminder records relate to users, workflows, or parent records as required by the MVP.

## Timeline

**Fields**
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

**Validation Rules**
- id is required and stable
- created_at and updated_at are maintained
- status uses an explicit allowed value
- owner or permission checks apply where user-owned

**Relationships**
- Timeline records relate to users, workflows, or parent records as required by the MVP.
