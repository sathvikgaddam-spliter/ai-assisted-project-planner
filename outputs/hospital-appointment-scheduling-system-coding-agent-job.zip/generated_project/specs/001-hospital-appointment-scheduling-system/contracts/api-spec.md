# API Contract

## Conventions

- JSON request and response bodies
- field-level validation errors
- 404 for missing resources
- authorization checks on user-owned records

## /api/users

- `GET /api/users` lists users.
- `POST /api/users` creates a User.
- `GET /api/users/{id}` returns one User.
- `PATCH /api/users/{id}` updates a User.
- `DELETE /api/users/{id}` archives or deletes a User.

## /api/accounts

- `GET /api/accounts` lists accounts.
- `POST /api/accounts` creates a Account.
- `GET /api/accounts/{id}` returns one Account.
- `PATCH /api/accounts/{id}` updates a Account.
- `DELETE /api/accounts/{id}` archives or deletes a Account.

## /api/items

- `GET /api/items` lists items.
- `POST /api/items` creates a Item.
- `GET /api/items/{id}` returns one Item.
- `PATCH /api/items/{id}` updates a Item.
- `DELETE /api/items/{id}` archives or deletes a Item.

## /api/activitys

- `GET /api/activitys` lists activitys.
- `POST /api/activitys` creates a Activity.
- `GET /api/activitys/{id}` returns one Activity.
- `PATCH /api/activitys/{id}` updates a Activity.
- `DELETE /api/activitys/{id}` archives or deletes a Activity.

## /api/notifications

- `GET /api/notifications` lists notifications.
- `POST /api/notifications` creates a Notification.
- `GET /api/notifications/{id}` returns one Notification.
- `PATCH /api/notifications/{id}` updates a Notification.
- `DELETE /api/notifications/{id}` archives or deletes a Notification.

## /api/tasks

- `GET /api/tasks` lists tasks.
- `POST /api/tasks` creates a Task.
- `GET /api/tasks/{id}` returns one Task.
- `PATCH /api/tasks/{id}` updates a Task.
- `DELETE /api/tasks/{id}` archives or deletes a Task.

## /api/events

- `GET /api/events` lists events.
- `POST /api/events` creates a Event.
- `GET /api/events/{id}` returns one Event.
- `PATCH /api/events/{id}` updates a Event.
- `DELETE /api/events/{id}` archives or deletes a Event.

## /api/reminders

- `GET /api/reminders` lists reminders.
- `POST /api/reminders` creates a Reminder.
- `GET /api/reminders/{id}` returns one Reminder.
- `PATCH /api/reminders/{id}` updates a Reminder.
- `DELETE /api/reminders/{id}` archives or deletes a Reminder.

## /api/timelines

- `GET /api/timelines` lists timelines.
- `POST /api/timelines` creates a Timeline.
- `GET /api/timelines/{id}` returns one Timeline.
- `PATCH /api/timelines/{id}` updates a Timeline.
- `DELETE /api/timelines/{id}` archives or deletes a Timeline.

## Workflow APIs

- CRUD APIs
- authentication APIs
- validation
- authorization
- schedule APIs
- reminder APIs
