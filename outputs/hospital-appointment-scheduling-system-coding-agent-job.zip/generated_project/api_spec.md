# API Specification

## Authentication
Use authenticated routes for user-owned data and admin-only routes for administrative actions.

## Required API Capabilities
- CRUD APIs
- authentication APIs
- validation
- authorization
- schedule APIs
- reminder APIs

## User Endpoints

- `GET /api/users`: list users; supports pagination and filtering.
- `POST /api/users`: create a User; validates request body and ownership.
- `GET /api/users/{id}`: fetch one User; returns 404 when unavailable.
- `PATCH /api/users/{id}`: update a User; enforces authorization.
- `DELETE /api/users/{id}`: archive or delete a User; requires authorization.

## Account Endpoints

- `GET /api/accounts`: list accounts; supports pagination and filtering.
- `POST /api/accounts`: create a Account; validates request body and ownership.
- `GET /api/accounts/{id}`: fetch one Account; returns 404 when unavailable.
- `PATCH /api/accounts/{id}`: update a Account; enforces authorization.
- `DELETE /api/accounts/{id}`: archive or delete a Account; requires authorization.

## Item Endpoints

- `GET /api/items`: list items; supports pagination and filtering.
- `POST /api/items`: create a Item; validates request body and ownership.
- `GET /api/items/{id}`: fetch one Item; returns 404 when unavailable.
- `PATCH /api/items/{id}`: update a Item; enforces authorization.
- `DELETE /api/items/{id}`: archive or delete a Item; requires authorization.

## Activity Endpoints

- `GET /api/activitys`: list activitys; supports pagination and filtering.
- `POST /api/activitys`: create a Activity; validates request body and ownership.
- `GET /api/activitys/{id}`: fetch one Activity; returns 404 when unavailable.
- `PATCH /api/activitys/{id}`: update a Activity; enforces authorization.
- `DELETE /api/activitys/{id}`: archive or delete a Activity; requires authorization.

## Notification Endpoints

- `GET /api/notifications`: list notifications; supports pagination and filtering.
- `POST /api/notifications`: create a Notification; validates request body and ownership.
- `GET /api/notifications/{id}`: fetch one Notification; returns 404 when unavailable.
- `PATCH /api/notifications/{id}`: update a Notification; enforces authorization.
- `DELETE /api/notifications/{id}`: archive or delete a Notification; requires authorization.

## Task Endpoints

- `GET /api/tasks`: list tasks; supports pagination and filtering.
- `POST /api/tasks`: create a Task; validates request body and ownership.
- `GET /api/tasks/{id}`: fetch one Task; returns 404 when unavailable.
- `PATCH /api/tasks/{id}`: update a Task; enforces authorization.
- `DELETE /api/tasks/{id}`: archive or delete a Task; requires authorization.

## Event Endpoints

- `GET /api/events`: list events; supports pagination and filtering.
- `POST /api/events`: create a Event; validates request body and ownership.
- `GET /api/events/{id}`: fetch one Event; returns 404 when unavailable.
- `PATCH /api/events/{id}`: update a Event; enforces authorization.
- `DELETE /api/events/{id}`: archive or delete a Event; requires authorization.

## Reminder Endpoints

- `GET /api/reminders`: list reminders; supports pagination and filtering.
- `POST /api/reminders`: create a Reminder; validates request body and ownership.
- `GET /api/reminders/{id}`: fetch one Reminder; returns 404 when unavailable.
- `PATCH /api/reminders/{id}`: update a Reminder; enforces authorization.
- `DELETE /api/reminders/{id}`: archive or delete a Reminder; requires authorization.

## Timeline Endpoints

- `GET /api/timelines`: list timelines; supports pagination and filtering.
- `POST /api/timelines`: create a Timeline; validates request body and ownership.
- `GET /api/timelines/{id}`: fetch one Timeline; returns 404 when unavailable.
- `PATCH /api/timelines/{id}`: update a Timeline; enforces authorization.
- `DELETE /api/timelines/{id}`: archive or delete a Timeline; requires authorization.

## Request/Response Expectations
- Use JSON request bodies.
- Return validation errors with field-level messages.
- Return consistent success envelopes for created and updated records.
