# Database Schema

## User

Suggested fields:
- id
- created_at
- updated_at
- status
- email
- display_name
- role

Relationships and constraints:
- Include a stable primary key.
- Track created_at and updated_at timestamps.
- Add indexes for owner, status, and lookup fields where applicable.

## Account

Suggested fields:
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

Relationships and constraints:
- Include a stable primary key.
- Track created_at and updated_at timestamps.
- Add indexes for owner, status, and lookup fields where applicable.

## Item

Suggested fields:
- id
- created_at
- updated_at
- status
- owner_id
- title
- description
- price

Relationships and constraints:
- Include a stable primary key.
- Track created_at and updated_at timestamps.
- Add indexes for owner, status, and lookup fields where applicable.

## Activity

Suggested fields:
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

Relationships and constraints:
- Include a stable primary key.
- Track created_at and updated_at timestamps.
- Add indexes for owner, status, and lookup fields where applicable.

## Notification

Suggested fields:
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

Relationships and constraints:
- Include a stable primary key.
- Track created_at and updated_at timestamps.
- Add indexes for owner, status, and lookup fields where applicable.

## Task

Suggested fields:
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

Relationships and constraints:
- Include a stable primary key.
- Track created_at and updated_at timestamps.
- Add indexes for owner, status, and lookup fields where applicable.

## Event

Suggested fields:
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

Relationships and constraints:
- Include a stable primary key.
- Track created_at and updated_at timestamps.
- Add indexes for owner, status, and lookup fields where applicable.

## Reminder

Suggested fields:
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

Relationships and constraints:
- Include a stable primary key.
- Track created_at and updated_at timestamps.
- Add indexes for owner, status, and lookup fields where applicable.

## Timeline

Suggested fields:
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

Relationships and constraints:
- Include a stable primary key.
- Track created_at and updated_at timestamps.
- Add indexes for owner, status, and lookup fields where applicable.
