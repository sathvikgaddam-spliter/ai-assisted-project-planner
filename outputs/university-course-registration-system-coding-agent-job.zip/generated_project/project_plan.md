# University Course Registration System

## Summary
A comprehensive plan for developing a university course registration system, covering discovery, design, development, testing, and deployment phases. The system will include user authentication, course browsing, registration workflows, and administrative management features.

- Domain: software
- Project type: software application
- Complexity: medium
- Status: plan_generated

## Clarification Questions
- What are the specific target user demographics (e.g., undergraduate, graduate, specific departments)?
- What is the desired timeline for the project's completion and launch?
- Are there any specific technology stack preferences or constraints?
- Are there any existing university systems that the course registration system will eventually need to integrate with (e.g., student information system, payment gateway, learning management system)?
- What are the specific reporting requirements for administrators (e.g., enrollment statistics, course capacity, student transcripts)?

## Phases
### P1: Discovery & Planning
To gather detailed requirements, define system scope, and create a foundational project plan.

Estimated duration: 2 weeks

Tasks:
- T1.1: Gather Functional Requirements - Conduct workshops and interviews with stakeholders (students, faculty, administrators) to define core features and user stories for course browsing, registration, dropping, course management, user management, and reporting.
- T1.2: Define Non-Functional Requirements - Document requirements for performance, security, scalability, usability, and accessibility. Dependencies: T1.1.
- T1.3: Technology Stack Selection - Evaluate and select appropriate technologies for frontend, backend, database, and deployment based on requirements and team expertise. Dependencies: T1.2.
- T1.4: Project Plan Finalization - Refine project scope, timeline, resource allocation, and risk assessment based on gathered information. Dependencies: T1.1, T1.2, T1.3.

Deliverables:
- Functional Requirements Document
- Non-Functional Requirements Document
- Technology Stack Proposal
- Detailed Project Plan

### P2: Design & Architecture
To create detailed system architecture, database schema, and user interface designs.

Estimated duration: 3 weeks

Tasks:
- T2.1: System Architecture Design - Design the overall system architecture, including microservices/monolith approach, API gateways, and integration patterns. Dependencies: T1.3, T1.4.
- T2.2: Database Schema Design - Design the database schema for entities like User (Student, Instructor, Admin), Course, Enrollment, Schedule, Notification. Dependencies: T1.1, T2.1.
- T2.3: API Design & Documentation - Design RESTful APIs for CRUD operations, authentication, and other core functionalities. Document APIs using OpenAPI/Swagger. Dependencies: T2.1, T2.2.
- T2.4: UI/UX Design & Prototyping - Create wireframes, mockups, and interactive prototypes for all user roles (student, instructor, admin) focusing on responsive design and usability. Dependencies: T1.1.

Deliverables:
- System Architecture Document
- Database Schema
- API Specification
- UI/UX Wireframes and Prototypes

### P3: Development
To implement the frontend, backend, and database components of the system.

Estimated duration: 8 weeks

Tasks:
- T3.1: Database Implementation - Set up the database and implement the designed schema. Dependencies: T2.2.
- T3.2: Backend API Development (Authentication & Authorization) - Develop APIs for user registration, login, session management, and role-based access control. Dependencies: T2.3, T3.1.
- T3.3: Backend API Development (Core CRUD Workflows) - Develop APIs for managing courses, enrollments, users (students, instructors, admins), and schedules. Dependencies: T2.3, T3.1, T3.2.
- T3.4: Frontend Development (User Authentication & Dashboard) - Implement user login, registration, and the main dashboard views for students, instructors, and administrators. Dependencies: T2.4, T3.2.
- T3.5: Frontend Development (Course Management & Registration) - Implement UI for course browsing, searching, registration, dropping courses, and administrative course management. Dependencies: T2.4, T3.3.
- T3.6: Notification System Implementation - Implement a system for sending notifications (e.g., registration confirmation, course updates) to users. Dependencies: T3.3.

Deliverables:
- Functional Backend APIs
- Functional Frontend Application
- Integrated Database

### P4: Testing & Quality Assurance
To ensure the system is robust, secure, and meets all functional and non-functional requirements.

Estimated duration: 4 weeks

Tasks:
- T4.1: Unit Testing - Write and execute unit tests for all backend and frontend components. Dependencies: P3.
- T4.2: Integration Testing - Test the integration between frontend and backend, and between different backend services. Dependencies: P3.
- T4.3: End-to-End (E2E) Testing - Perform E2E tests for critical user workflows (e.g., student registration, course enrollment, admin course creation). Dependencies: P3.
- T4.4: Security Testing - Conduct vulnerability scanning and penetration testing to identify and fix security flaws. Dependencies: P3.
- T4.5: User Acceptance Testing (UAT) - Engage end-users (students, faculty, administrators) to test the system and provide feedback. Dependencies: T4.1, T4.2, T4.3.

Deliverables:
- Test Reports (Unit, Integration, E2E)
- Security Audit Report
- UAT Feedback and Sign-off

### P5: Deployment & Launch
To deploy the system to a production environment and make it available to users.

Estimated duration: 1 week

Tasks:
- T5.1: Infrastructure Setup - Provision and configure production servers, databases, and networking components. Dependencies: P2.
- T5.2: Deployment Automation - Set up CI/CD pipelines for automated deployment to production. Dependencies: T5.1.
- T5.3: System Deployment - Deploy the application to the production environment. Dependencies: P3, P4, T5.2.
- T5.4: User Training & Documentation - Prepare user manuals and conduct training sessions for administrators and key users. Dependencies: P4.

Deliverables:
- Production Environment
- Deployed Application
- User Manuals and Training Materials

### P6: Post-Launch Support & Iteration
To monitor system performance, address issues, and plan for future enhancements.

Estimated duration: Ongoing

Tasks:
- T6.1: System Monitoring & Maintenance - Continuously monitor system performance, security, and availability. Perform regular maintenance tasks. Dependencies: P5.
- T6.2: Bug Fixing & Support - Address reported bugs and provide ongoing technical support to users. Dependencies: P5.
- T6.3: Feedback Collection & Feature Prioritization - Collect user feedback and prioritize new features or enhancements for future iterations. Dependencies: P5.

Deliverables:
- Monitoring Reports
- Bug Fix Releases
- Feature Backlog

## Milestones
- M1: Requirements Approved (P1)
- M2: Technical Design Complete (P2)
- M3: Core Features Developed (P3)
- M4: System Tested & UAT Complete (P4)
- M5: Production Launch (P5)

## Risks
- R1: Scope creep due to evolving stakeholder requirements during development. Mitigation: Implement strict change control processes and prioritize features in sprints. Clearly define 'Minimum Viable Product' (MVP).
- R2: Performance issues with a large number of concurrent users during peak registration periods. Mitigation: Conduct load testing, optimize database queries, and implement caching mechanisms. Design for scalability from the outset.
- R3: Security vulnerabilities leading to data breaches or unauthorized access. Mitigation: Follow security best practices (OWASP Top 10), conduct regular security audits and penetration testing, and implement robust authentication/authorization.
- R4: Lack of user adoption due to poor usability or insufficient training. Mitigation: Involve users in UI/UX design and UAT. Provide comprehensive training and clear documentation.

## Recommendations
- Technology: Utilize a modern, scalable web framework (e.g., React/Angular/Vue for frontend, Node.js/Python/Java for backend) and a robust relational database (e.g., PostgreSQL).
- Process: Adopt an Agile development methodology (e.g., Scrum) to allow for iterative development, continuous feedback, and flexibility to adapt to changing requirements.
- Security: Implement multi-factor authentication (MFA) for all user roles, especially administrators, to enhance security.
- Scalability: Design the system with a microservices-oriented architecture (if complexity allows) or a modular monolith to facilitate future scaling and independent development of features.

## Assumptions
- The project will be developed as a standalone web application, with no initial integration required with existing university legacy systems (e.g., student information systems, payment gateways).
- A dedicated development team (frontend, backend, QA, DevOps, UI/UX) will be available for the project duration.
- The primary user roles will be Student, Instructor, and Administrator, each with distinct permissions and workflows.
- Cloud infrastructure (e.g., AWS, Azure, GCP) will be used for deployment, providing scalability and managed services.
- Stakeholders will be available for timely feedback and approvals during the discovery, design, and UAT phases.

## Engineering Prompt Pack
### Frontend Engineer implementation prompt

**Target Role:** Frontend Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Implement the frontend experience for the planned project while preserving the validated project scope.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5
- P6

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The project will be developed as a standalone web application, with no initial integration required with existing university legacy systems (e.g., student information systems, payment gateways).
- A dedicated development team (frontend, backend, QA, DevOps, UI/UX) will be available for the project duration.
- The primary user roles will be Student, Instructor, and Administrator, each with distinct permissions and workflows.
- Cloud infrastructure (e.g., AWS, Azure, GCP) will be used for deployment, providing scalability and managed services.
- Stakeholders will be available for timely feedback and approvals during the discovery, design, and UAT phases.

**Acceptance Criteria:**
- The Frontend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed functional requirements document approved by stakeholders
- User stories defined for all core workflows
- Non-functional requirements document approved

**Prompt:**
```text
You are a senior frontend engineer responsible for implementing the user-facing experience.

## Project Context
Project name: University Course Registration System
Project description: Build a web-based application to enable university students to register for courses, manage their schedules, and allow administrators to manage courses, students, and instructors.
Domain: software
Project type: software application
Complexity: medium
Summary: A comprehensive plan for developing a university course registration system, covering discovery, design, development, testing, and deployment phases. The system will include user authentication, course browsing, registration workflows, and administrative management features.

## Your Role
Frontend Engineer

## Goal
Implement the frontend experience for the planned project while preserving the validated project scope.

## Technical Scope
UI workflows, client-side validation, accessibility, responsive behavior, and integration points with backend APIs.

Relevant tasks:
- T1.1: Gather Functional Requirements - Conduct workshops and interviews with stakeholders (students, faculty, administrators) to define core features and user stories for course browsing, registration, dropping, course management, user management, and reporting.
- T1.2: Define Non-Functional Requirements - Document requirements for performance, security, scalability, usability, and accessibility.
- T1.3: Technology Stack Selection - Evaluate and select appropriate technologies for frontend, backend, database, and deployment based on requirements and team expertise.
- T1.4: Project Plan Finalization - Refine project scope, timeline, resource allocation, and risk assessment based on gathered information.
- T2.1: System Architecture Design - Design the overall system architecture, including microservices/monolith approach, API gateways, and integration patterns.
- T2.2: Database Schema Design - Design the database schema for entities like User (Student, Instructor, Admin), Course, Enrollment, Schedule, Notification.
- T2.3: API Design & Documentation - Design RESTful APIs for CRUD operations, authentication, and other core functionalities. Document APIs using OpenAPI/Swagger.
- T2.4: UI/UX Design & Prototyping - Create wireframes, mockups, and interactive prototypes for all user roles (student, instructor, admin) focusing on responsive design and usability.
- T3.1: Database Implementation - Set up the database and implement the designed schema.
- T3.2: Backend API Development (Authentication & Authorization) - Develop APIs for user registration, login, session management, and role-based access control.
- T3.3: Backend API Development (Core CRUD Workflows) - Develop APIs for managing courses, enrollments, users (students, instructors, admins), and schedules.
- T3.4: Frontend Development (User Authentication & Dashboard) - Implement user login, registration, and the main dashboard views for students, instructors, and administrators.
- T3.5: Frontend Development (Course Management & Registration) - Implement UI for course browsing, searching, registration, dropping courses, and administrative course management.
- T3.6: Notification System Implementation - Implement a system for sending notifications (e.g., registration confirmation, course updates) to users.
- T4.1: Unit Testing - Write and execute unit tests for all backend and frontend components.
- T4.2: Integration Testing - Test the integration between frontend and backend, and between different backend services.
- T4.3: End-to-End (E2E) Testing - Perform E2E tests for critical user workflows (e.g., student registration, course enrollment, admin course creation).
- T4.4: Security Testing - Conduct vulnerability scanning and penetration testing to identify and fix security flaws.
- T4.5: User Acceptance Testing (UAT) - Engage end-users (students, faculty, administrators) to test the system and provide feedback.
- T5.1: Infrastructure Setup - Provision and configure production servers, databases, and networking components.
- T5.2: Deployment Automation - Set up CI/CD pipelines for automated deployment to production.
- T5.3: System Deployment - Deploy the application to the production environment.
- T5.4: User Training & Documentation - Prepare user manuals and conduct training sessions for administrators and key users.
- T6.1: System Monitoring & Maintenance - Continuously monitor system performance, security, and availability. Perform regular maintenance tasks.
- T6.2: Bug Fixing & Support - Address reported bugs and provide ongoing technical support to users.
- T6.3: Feedback Collection & Feature Prioritization - Collect user feedback and prioritize new features or enhancements for future iterations.

Risks to account for:
- Scope creep due to evolving stakeholder requirements during development.
- Performance issues with a large number of concurrent users during peak registration periods.
- Security vulnerabilities leading to data breaches or unauthorized access.
- Lack of user adoption due to poor usability or insufficient training.

Recommendations to preserve:
- Utilize a modern, scalable web framework (e.g., React/Angular/Vue for frontend, Node.js/Python/Java for backend) and a robust relational database (e.g., PostgreSQL).
- Adopt an Agile development methodology (e.g., Scrum) to allow for iterative development, continuous feedback, and flexibility to adapt to changing requirements.
- Implement multi-factor authentication (MFA) for all user roles, especially administrators, to enhance security.
- Design the system with a microservices-oriented architecture (if complexity allows) or a modular monolith to facilitate future scaling and independent development of features.

Assumptions to keep visible:
- The project will be developed as a standalone web application, with no initial integration required with existing university legacy systems (e.g., student information systems, payment gateways).
- A dedicated development team (frontend, backend, QA, DevOps, UI/UX) will be available for the project duration.
- The primary user roles will be Student, Instructor, and Administrator, each with distinct permissions and workflows.
- Cloud infrastructure (e.g., AWS, Azure, GCP) will be used for deployment, providing scalability and managed services.
- Stakeholders will be available for timely feedback and approvals during the discovery, design, and UAT phases.

## Related Phases
- P1: Discovery & Planning (2 weeks) - To gather detailed requirements, define system scope, and create a foundational project plan.
- P2: Design & Architecture (3 weeks) - To create detailed system architecture, database schema, and user interface designs.
- P3: Development (8 weeks) - To implement the frontend, backend, and database components of the system.
- P4: Testing & Quality Assurance (4 weeks) - To ensure the system is robust, secure, and meets all functional and non-functional requirements.
- P5: Deployment & Launch (1 week) - To deploy the system to a production environment and make it available to users.
- P6: Post-Launch Support & Iteration (Ongoing) - To monitor system performance, address issues, and plan for future enhancements.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The project will be developed as a standalone web application, with no initial integration required with existing university legacy systems (e.g., student information systems, payment gateways).
- A dedicated development team (frontend, backend, QA, DevOps, UI/UX) will be available for the project duration.
- The primary user roles will be Student, Instructor, and Administrator, each with distinct permissions and workflows.
- Cloud infrastructure (e.g., AWS, Azure, GCP) will be used for deployment, providing scalability and managed services.
- Stakeholders will be available for timely feedback and approvals during the discovery, design, and UAT phases.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Frontend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed functional requirements document approved by stakeholders
- User stories defined for all core workflows
- Non-functional requirements document approved

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### Backend Engineer implementation prompt

**Target Role:** Backend Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Implement backend services that support the planned workflows, validation rules, and task sequencing.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5
- P6

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The project will be developed as a standalone web application, with no initial integration required with existing university legacy systems (e.g., student information systems, payment gateways).
- A dedicated development team (frontend, backend, QA, DevOps, UI/UX) will be available for the project duration.
- The primary user roles will be Student, Instructor, and Administrator, each with distinct permissions and workflows.
- Cloud infrastructure (e.g., AWS, Azure, GCP) will be used for deployment, providing scalability and managed services.
- Stakeholders will be available for timely feedback and approvals during the discovery, design, and UAT phases.

**Acceptance Criteria:**
- The Backend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed functional requirements document approved by stakeholders
- User stories defined for all core workflows
- Non-functional requirements document approved

**Prompt:**
```text
You are a senior backend engineer responsible for building the application services and API layer.

## Project Context
Project name: University Course Registration System
Project description: Build a web-based application to enable university students to register for courses, manage their schedules, and allow administrators to manage courses, students, and instructors.
Domain: software
Project type: software application
Complexity: medium
Summary: A comprehensive plan for developing a university course registration system, covering discovery, design, development, testing, and deployment phases. The system will include user authentication, course browsing, registration workflows, and administrative management features.

## Your Role
Backend Engineer

## Goal
Implement backend services that support the planned workflows, validation rules, and task sequencing.

## Technical Scope
API contracts, service logic, validation, error handling, integrations, and backend test coverage.

Relevant tasks:
- T1.1: Gather Functional Requirements - Conduct workshops and interviews with stakeholders (students, faculty, administrators) to define core features and user stories for course browsing, registration, dropping, course management, user management, and reporting.
- T1.2: Define Non-Functional Requirements - Document requirements for performance, security, scalability, usability, and accessibility.
- T1.3: Technology Stack Selection - Evaluate and select appropriate technologies for frontend, backend, database, and deployment based on requirements and team expertise.
- T1.4: Project Plan Finalization - Refine project scope, timeline, resource allocation, and risk assessment based on gathered information.
- T2.1: System Architecture Design - Design the overall system architecture, including microservices/monolith approach, API gateways, and integration patterns.
- T2.2: Database Schema Design - Design the database schema for entities like User (Student, Instructor, Admin), Course, Enrollment, Schedule, Notification.
- T2.3: API Design & Documentation - Design RESTful APIs for CRUD operations, authentication, and other core functionalities. Document APIs using OpenAPI/Swagger.
- T2.4: UI/UX Design & Prototyping - Create wireframes, mockups, and interactive prototypes for all user roles (student, instructor, admin) focusing on responsive design and usability.
- T3.1: Database Implementation - Set up the database and implement the designed schema.
- T3.2: Backend API Development (Authentication & Authorization) - Develop APIs for user registration, login, session management, and role-based access control.
- T3.3: Backend API Development (Core CRUD Workflows) - Develop APIs for managing courses, enrollments, users (students, instructors, admins), and schedules.
- T3.4: Frontend Development (User Authentication & Dashboard) - Implement user login, registration, and the main dashboard views for students, instructors, and administrators.
- T3.5: Frontend Development (Course Management & Registration) - Implement UI for course browsing, searching, registration, dropping courses, and administrative course management.
- T3.6: Notification System Implementation - Implement a system for sending notifications (e.g., registration confirmation, course updates) to users.
- T4.1: Unit Testing - Write and execute unit tests for all backend and frontend components.
- T4.2: Integration Testing - Test the integration between frontend and backend, and between different backend services.
- T4.3: End-to-End (E2E) Testing - Perform E2E tests for critical user workflows (e.g., student registration, course enrollment, admin course creation).
- T4.4: Security Testing - Conduct vulnerability scanning and penetration testing to identify and fix security flaws.
- T4.5: User Acceptance Testing (UAT) - Engage end-users (students, faculty, administrators) to test the system and provide feedback.
- T5.1: Infrastructure Setup - Provision and configure production servers, databases, and networking components.
- T5.2: Deployment Automation - Set up CI/CD pipelines for automated deployment to production.
- T5.3: System Deployment - Deploy the application to the production environment.
- T5.4: User Training & Documentation - Prepare user manuals and conduct training sessions for administrators and key users.
- T6.1: System Monitoring & Maintenance - Continuously monitor system performance, security, and availability. Perform regular maintenance tasks.
- T6.2: Bug Fixing & Support - Address reported bugs and provide ongoing technical support to users.
- T6.3: Feedback Collection & Feature Prioritization - Collect user feedback and prioritize new features or enhancements for future iterations.

Risks to account for:
- Scope creep due to evolving stakeholder requirements during development.
- Performance issues with a large number of concurrent users during peak registration periods.
- Security vulnerabilities leading to data breaches or unauthorized access.
- Lack of user adoption due to poor usability or insufficient training.

Recommendations to preserve:
- Utilize a modern, scalable web framework (e.g., React/Angular/Vue for frontend, Node.js/Python/Java for backend) and a robust relational database (e.g., PostgreSQL).
- Adopt an Agile development methodology (e.g., Scrum) to allow for iterative development, continuous feedback, and flexibility to adapt to changing requirements.
- Implement multi-factor authentication (MFA) for all user roles, especially administrators, to enhance security.
- Design the system with a microservices-oriented architecture (if complexity allows) or a modular monolith to facilitate future scaling and independent development of features.

Assumptions to keep visible:
- The project will be developed as a standalone web application, with no initial integration required with existing university legacy systems (e.g., student information systems, payment gateways).
- A dedicated development team (frontend, backend, QA, DevOps, UI/UX) will be available for the project duration.
- The primary user roles will be Student, Instructor, and Administrator, each with distinct permissions and workflows.
- Cloud infrastructure (e.g., AWS, Azure, GCP) will be used for deployment, providing scalability and managed services.
- Stakeholders will be available for timely feedback and approvals during the discovery, design, and UAT phases.

## Related Phases
- P1: Discovery & Planning (2 weeks) - To gather detailed requirements, define system scope, and create a foundational project plan.
- P2: Design & Architecture (3 weeks) - To create detailed system architecture, database schema, and user interface designs.
- P3: Development (8 weeks) - To implement the frontend, backend, and database components of the system.
- P4: Testing & Quality Assurance (4 weeks) - To ensure the system is robust, secure, and meets all functional and non-functional requirements.
- P5: Deployment & Launch (1 week) - To deploy the system to a production environment and make it available to users.
- P6: Post-Launch Support & Iteration (Ongoing) - To monitor system performance, address issues, and plan for future enhancements.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The project will be developed as a standalone web application, with no initial integration required with existing university legacy systems (e.g., student information systems, payment gateways).
- A dedicated development team (frontend, backend, QA, DevOps, UI/UX) will be available for the project duration.
- The primary user roles will be Student, Instructor, and Administrator, each with distinct permissions and workflows.
- Cloud infrastructure (e.g., AWS, Azure, GCP) will be used for deployment, providing scalability and managed services.
- Stakeholders will be available for timely feedback and approvals during the discovery, design, and UAT phases.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Backend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed functional requirements document approved by stakeholders
- User stories defined for all core workflows
- Non-functional requirements document approved

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### Database Engineer implementation prompt

**Target Role:** Database Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Define storage structures that support the project requirements without inventing unsupported data sources.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5
- P6

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The project will be developed as a standalone web application, with no initial integration required with existing university legacy systems (e.g., student information systems, payment gateways).
- A dedicated development team (frontend, backend, QA, DevOps, UI/UX) will be available for the project duration.
- The primary user roles will be Student, Instructor, and Administrator, each with distinct permissions and workflows.
- Cloud infrastructure (e.g., AWS, Azure, GCP) will be used for deployment, providing scalability and managed services.
- Stakeholders will be available for timely feedback and approvals during the discovery, design, and UAT phases.

**Acceptance Criteria:**
- The Database Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed functional requirements document approved by stakeholders
- User stories defined for all core workflows
- Non-functional requirements document approved

**Prompt:**
```text
You are a senior database engineer responsible for designing the data model and persistence approach.

## Project Context
Project name: University Course Registration System
Project description: Build a web-based application to enable university students to register for courses, manage their schedules, and allow administrators to manage courses, students, and instructors.
Domain: software
Project type: software application
Complexity: medium
Summary: A comprehensive plan for developing a university course registration system, covering discovery, design, development, testing, and deployment phases. The system will include user authentication, course browsing, registration workflows, and administrative management features.

## Your Role
Database Engineer

## Goal
Define storage structures that support the project requirements without inventing unsupported data sources.

## Technical Scope
Entities, relationships, indexes, migrations, data quality checks, retention needs, and backup assumptions.

Relevant tasks:
- T1.1: Gather Functional Requirements - Conduct workshops and interviews with stakeholders (students, faculty, administrators) to define core features and user stories for course browsing, registration, dropping, course management, user management, and reporting.
- T1.2: Define Non-Functional Requirements - Document requirements for performance, security, scalability, usability, and accessibility.
- T1.3: Technology Stack Selection - Evaluate and select appropriate technologies for frontend, backend, database, and deployment based on requirements and team expertise.
- T1.4: Project Plan Finalization - Refine project scope, timeline, resource allocation, and risk assessment based on gathered information.
- T2.1: System Architecture Design - Design the overall system architecture, including microservices/monolith approach, API gateways, and integration patterns.
- T2.2: Database Schema Design - Design the database schema for entities like User (Student, Instructor, Admin), Course, Enrollment, Schedule, Notification.
- T2.3: API Design & Documentation - Design RESTful APIs for CRUD operations, authentication, and other core functionalities. Document APIs using OpenAPI/Swagger.
- T2.4: UI/UX Design & Prototyping - Create wireframes, mockups, and interactive prototypes for all user roles (student, instructor, admin) focusing on responsive design and usability.
- T3.1: Database Implementation - Set up the database and implement the designed schema.
- T3.2: Backend API Development (Authentication & Authorization) - Develop APIs for user registration, login, session management, and role-based access control.
- T3.3: Backend API Development (Core CRUD Workflows) - Develop APIs for managing courses, enrollments, users (students, instructors, admins), and schedules.
- T3.4: Frontend Development (User Authentication & Dashboard) - Implement user login, registration, and the main dashboard views for students, instructors, and administrators.
- T3.5: Frontend Development (Course Management & Registration) - Implement UI for course browsing, searching, registration, dropping courses, and administrative course management.
- T3.6: Notification System Implementation - Implement a system for sending notifications (e.g., registration confirmation, course updates) to users.
- T4.1: Unit Testing - Write and execute unit tests for all backend and frontend components.
- T4.2: Integration Testing - Test the integration between frontend and backend, and between different backend services.
- T4.3: End-to-End (E2E) Testing - Perform E2E tests for critical user workflows (e.g., student registration, course enrollment, admin course creation).
- T4.4: Security Testing - Conduct vulnerability scanning and penetration testing to identify and fix security flaws.
- T4.5: User Acceptance Testing (UAT) - Engage end-users (students, faculty, administrators) to test the system and provide feedback.
- T5.1: Infrastructure Setup - Provision and configure production servers, databases, and networking components.
- T5.2: Deployment Automation - Set up CI/CD pipelines for automated deployment to production.
- T5.3: System Deployment - Deploy the application to the production environment.
- T5.4: User Training & Documentation - Prepare user manuals and conduct training sessions for administrators and key users.
- T6.1: System Monitoring & Maintenance - Continuously monitor system performance, security, and availability. Perform regular maintenance tasks.
- T6.2: Bug Fixing & Support - Address reported bugs and provide ongoing technical support to users.
- T6.3: Feedback Collection & Feature Prioritization - Collect user feedback and prioritize new features or enhancements for future iterations.

Risks to account for:
- Scope creep due to evolving stakeholder requirements during development.
- Performance issues with a large number of concurrent users during peak registration periods.
- Security vulnerabilities leading to data breaches or unauthorized access.
- Lack of user adoption due to poor usability or insufficient training.

Recommendations to preserve:
- Utilize a modern, scalable web framework (e.g., React/Angular/Vue for frontend, Node.js/Python/Java for backend) and a robust relational database (e.g., PostgreSQL).
- Adopt an Agile development methodology (e.g., Scrum) to allow for iterative development, continuous feedback, and flexibility to adapt to changing requirements.
- Implement multi-factor authentication (MFA) for all user roles, especially administrators, to enhance security.
- Design the system with a microservices-oriented architecture (if complexity allows) or a modular monolith to facilitate future scaling and independent development of features.

Assumptions to keep visible:
- The project will be developed as a standalone web application, with no initial integration required with existing university legacy systems (e.g., student information systems, payment gateways).
- A dedicated development team (frontend, backend, QA, DevOps, UI/UX) will be available for the project duration.
- The primary user roles will be Student, Instructor, and Administrator, each with distinct permissions and workflows.
- Cloud infrastructure (e.g., AWS, Azure, GCP) will be used for deployment, providing scalability and managed services.
- Stakeholders will be available for timely feedback and approvals during the discovery, design, and UAT phases.

## Related Phases
- P1: Discovery & Planning (2 weeks) - To gather detailed requirements, define system scope, and create a foundational project plan.
- P2: Design & Architecture (3 weeks) - To create detailed system architecture, database schema, and user interface designs.
- P3: Development (8 weeks) - To implement the frontend, backend, and database components of the system.
- P4: Testing & Quality Assurance (4 weeks) - To ensure the system is robust, secure, and meets all functional and non-functional requirements.
- P5: Deployment & Launch (1 week) - To deploy the system to a production environment and make it available to users.
- P6: Post-Launch Support & Iteration (Ongoing) - To monitor system performance, address issues, and plan for future enhancements.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The project will be developed as a standalone web application, with no initial integration required with existing university legacy systems (e.g., student information systems, payment gateways).
- A dedicated development team (frontend, backend, QA, DevOps, UI/UX) will be available for the project duration.
- The primary user roles will be Student, Instructor, and Administrator, each with distinct permissions and workflows.
- Cloud infrastructure (e.g., AWS, Azure, GCP) will be used for deployment, providing scalability and managed services.
- Stakeholders will be available for timely feedback and approvals during the discovery, design, and UAT phases.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Database Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed functional requirements document approved by stakeholders
- User stories defined for all core workflows
- Non-functional requirements document approved

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### QA / Testing Engineer implementation prompt

**Target Role:** QA / Testing Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Create a practical test strategy for the project phases, risks, acceptance criteria, and release workflow.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5
- P6

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The project will be developed as a standalone web application, with no initial integration required with existing university legacy systems (e.g., student information systems, payment gateways).
- A dedicated development team (frontend, backend, QA, DevOps, UI/UX) will be available for the project duration.
- The primary user roles will be Student, Instructor, and Administrator, each with distinct permissions and workflows.
- Cloud infrastructure (e.g., AWS, Azure, GCP) will be used for deployment, providing scalability and managed services.
- Stakeholders will be available for timely feedback and approvals during the discovery, design, and UAT phases.

**Acceptance Criteria:**
- The QA / Testing Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed functional requirements document approved by stakeholders
- User stories defined for all core workflows
- Non-functional requirements document approved

**Prompt:**
```text
You are a senior QA engineer responsible for validating the implementation against the plan.

## Project Context
Project name: University Course Registration System
Project description: Build a web-based application to enable university students to register for courses, manage their schedules, and allow administrators to manage courses, students, and instructors.
Domain: software
Project type: software application
Complexity: medium
Summary: A comprehensive plan for developing a university course registration system, covering discovery, design, development, testing, and deployment phases. The system will include user authentication, course browsing, registration workflows, and administrative management features.

## Your Role
QA / Testing Engineer

## Goal
Create a practical test strategy for the project phases, risks, acceptance criteria, and release workflow.

## Technical Scope
Functional tests, regression tests, edge cases, acceptance criteria validation, risk-based testing, and defect reporting.

Relevant tasks:
- T1.1: Gather Functional Requirements - Conduct workshops and interviews with stakeholders (students, faculty, administrators) to define core features and user stories for course browsing, registration, dropping, course management, user management, and reporting.
- T1.2: Define Non-Functional Requirements - Document requirements for performance, security, scalability, usability, and accessibility.
- T1.3: Technology Stack Selection - Evaluate and select appropriate technologies for frontend, backend, database, and deployment based on requirements and team expertise.
- T1.4: Project Plan Finalization - Refine project scope, timeline, resource allocation, and risk assessment based on gathered information.
- T2.1: System Architecture Design - Design the overall system architecture, including microservices/monolith approach, API gateways, and integration patterns.
- T2.2: Database Schema Design - Design the database schema for entities like User (Student, Instructor, Admin), Course, Enrollment, Schedule, Notification.
- T2.3: API Design & Documentation - Design RESTful APIs for CRUD operations, authentication, and other core functionalities. Document APIs using OpenAPI/Swagger.
- T2.4: UI/UX Design & Prototyping - Create wireframes, mockups, and interactive prototypes for all user roles (student, instructor, admin) focusing on responsive design and usability.
- T3.1: Database Implementation - Set up the database and implement the designed schema.
- T3.2: Backend API Development (Authentication & Authorization) - Develop APIs for user registration, login, session management, and role-based access control.
- T3.3: Backend API Development (Core CRUD Workflows) - Develop APIs for managing courses, enrollments, users (students, instructors, admins), and schedules.
- T3.4: Frontend Development (User Authentication & Dashboard) - Implement user login, registration, and the main dashboard views for students, instructors, and administrators.
- T3.5: Frontend Development (Course Management & Registration) - Implement UI for course browsing, searching, registration, dropping courses, and administrative course management.
- T3.6: Notification System Implementation - Implement a system for sending notifications (e.g., registration confirmation, course updates) to users.
- T4.1: Unit Testing - Write and execute unit tests for all backend and frontend components.
- T4.2: Integration Testing - Test the integration between frontend and backend, and between different backend services.
- T4.3: End-to-End (E2E) Testing - Perform E2E tests for critical user workflows (e.g., student registration, course enrollment, admin course creation).
- T4.4: Security Testing - Conduct vulnerability scanning and penetration testing to identify and fix security flaws.
- T4.5: User Acceptance Testing (UAT) - Engage end-users (students, faculty, administrators) to test the system and provide feedback.
- T5.1: Infrastructure Setup - Provision and configure production servers, databases, and networking components.
- T5.2: Deployment Automation - Set up CI/CD pipelines for automated deployment to production.
- T5.3: System Deployment - Deploy the application to the production environment.
- T5.4: User Training & Documentation - Prepare user manuals and conduct training sessions for administrators and key users.
- T6.1: System Monitoring & Maintenance - Continuously monitor system performance, security, and availability. Perform regular maintenance tasks.
- T6.2: Bug Fixing & Support - Address reported bugs and provide ongoing technical support to users.
- T6.3: Feedback Collection & Feature Prioritization - Collect user feedback and prioritize new features or enhancements for future iterations.

Risks to account for:
- Scope creep due to evolving stakeholder requirements during development.
- Performance issues with a large number of concurrent users during peak registration periods.
- Security vulnerabilities leading to data breaches or unauthorized access.
- Lack of user adoption due to poor usability or insufficient training.

Recommendations to preserve:
- Utilize a modern, scalable web framework (e.g., React/Angular/Vue for frontend, Node.js/Python/Java for backend) and a robust relational database (e.g., PostgreSQL).
- Adopt an Agile development methodology (e.g., Scrum) to allow for iterative development, continuous feedback, and flexibility to adapt to changing requirements.
- Implement multi-factor authentication (MFA) for all user roles, especially administrators, to enhance security.
- Design the system with a microservices-oriented architecture (if complexity allows) or a modular monolith to facilitate future scaling and independent development of features.

Assumptions to keep visible:
- The project will be developed as a standalone web application, with no initial integration required with existing university legacy systems (e.g., student information systems, payment gateways).
- A dedicated development team (frontend, backend, QA, DevOps, UI/UX) will be available for the project duration.
- The primary user roles will be Student, Instructor, and Administrator, each with distinct permissions and workflows.
- Cloud infrastructure (e.g., AWS, Azure, GCP) will be used for deployment, providing scalability and managed services.
- Stakeholders will be available for timely feedback and approvals during the discovery, design, and UAT phases.

## Related Phases
- P1: Discovery & Planning (2 weeks) - To gather detailed requirements, define system scope, and create a foundational project plan.
- P2: Design & Architecture (3 weeks) - To create detailed system architecture, database schema, and user interface designs.
- P3: Development (8 weeks) - To implement the frontend, backend, and database components of the system.
- P4: Testing & Quality Assurance (4 weeks) - To ensure the system is robust, secure, and meets all functional and non-functional requirements.
- P5: Deployment & Launch (1 week) - To deploy the system to a production environment and make it available to users.
- P6: Post-Launch Support & Iteration (Ongoing) - To monitor system performance, address issues, and plan for future enhancements.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The project will be developed as a standalone web application, with no initial integration required with existing university legacy systems (e.g., student information systems, payment gateways).
- A dedicated development team (frontend, backend, QA, DevOps, UI/UX) will be available for the project duration.
- The primary user roles will be Student, Instructor, and Administrator, each with distinct permissions and workflows.
- Cloud infrastructure (e.g., AWS, Azure, GCP) will be used for deployment, providing scalability and managed services.
- Stakeholders will be available for timely feedback and approvals during the discovery, design, and UAT phases.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The QA / Testing Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed functional requirements document approved by stakeholders
- User stories defined for all core workflows
- Non-functional requirements document approved

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### DevOps Engineer implementation prompt

**Target Role:** DevOps Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Plan environment, build, release, monitoring, and rollback work without deploying anything automatically.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5
- P6

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The project will be developed as a standalone web application, with no initial integration required with existing university legacy systems (e.g., student information systems, payment gateways).
- A dedicated development team (frontend, backend, QA, DevOps, UI/UX) will be available for the project duration.
- The primary user roles will be Student, Instructor, and Administrator, each with distinct permissions and workflows.
- Cloud infrastructure (e.g., AWS, Azure, GCP) will be used for deployment, providing scalability and managed services.
- Stakeholders will be available for timely feedback and approvals during the discovery, design, and UAT phases.

**Acceptance Criteria:**
- The DevOps Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed functional requirements document approved by stakeholders
- User stories defined for all core workflows
- Non-functional requirements document approved

**Prompt:**
```text
You are a senior DevOps engineer responsible for deployment readiness and operational workflow.

## Project Context
Project name: University Course Registration System
Project description: Build a web-based application to enable university students to register for courses, manage their schedules, and allow administrators to manage courses, students, and instructors.
Domain: software
Project type: software application
Complexity: medium
Summary: A comprehensive plan for developing a university course registration system, covering discovery, design, development, testing, and deployment phases. The system will include user authentication, course browsing, registration workflows, and administrative management features.

## Your Role
DevOps Engineer

## Goal
Plan environment, build, release, monitoring, and rollback work without deploying anything automatically.

## Technical Scope
Local development setup, CI checks, configuration, deployment plan, observability, release checklist, and rollback notes.

Relevant tasks:
- T1.1: Gather Functional Requirements - Conduct workshops and interviews with stakeholders (students, faculty, administrators) to define core features and user stories for course browsing, registration, dropping, course management, user management, and reporting.
- T1.2: Define Non-Functional Requirements - Document requirements for performance, security, scalability, usability, and accessibility.
- T1.3: Technology Stack Selection - Evaluate and select appropriate technologies for frontend, backend, database, and deployment based on requirements and team expertise.
- T1.4: Project Plan Finalization - Refine project scope, timeline, resource allocation, and risk assessment based on gathered information.
- T2.1: System Architecture Design - Design the overall system architecture, including microservices/monolith approach, API gateways, and integration patterns.
- T2.2: Database Schema Design - Design the database schema for entities like User (Student, Instructor, Admin), Course, Enrollment, Schedule, Notification.
- T2.3: API Design & Documentation - Design RESTful APIs for CRUD operations, authentication, and other core functionalities. Document APIs using OpenAPI/Swagger.
- T2.4: UI/UX Design & Prototyping - Create wireframes, mockups, and interactive prototypes for all user roles (student, instructor, admin) focusing on responsive design and usability.
- T3.1: Database Implementation - Set up the database and implement the designed schema.
- T3.2: Backend API Development (Authentication & Authorization) - Develop APIs for user registration, login, session management, and role-based access control.
- T3.3: Backend API Development (Core CRUD Workflows) - Develop APIs for managing courses, enrollments, users (students, instructors, admins), and schedules.
- T3.4: Frontend Development (User Authentication & Dashboard) - Implement user login, registration, and the main dashboard views for students, instructors, and administrators.
- T3.5: Frontend Development (Course Management & Registration) - Implement UI for course browsing, searching, registration, dropping courses, and administrative course management.
- T3.6: Notification System Implementation - Implement a system for sending notifications (e.g., registration confirmation, course updates) to users.
- T4.1: Unit Testing - Write and execute unit tests for all backend and frontend components.
- T4.2: Integration Testing - Test the integration between frontend and backend, and between different backend services.
- T4.3: End-to-End (E2E) Testing - Perform E2E tests for critical user workflows (e.g., student registration, course enrollment, admin course creation).
- T4.4: Security Testing - Conduct vulnerability scanning and penetration testing to identify and fix security flaws.
- T4.5: User Acceptance Testing (UAT) - Engage end-users (students, faculty, administrators) to test the system and provide feedback.
- T5.1: Infrastructure Setup - Provision and configure production servers, databases, and networking components.
- T5.2: Deployment Automation - Set up CI/CD pipelines for automated deployment to production.
- T5.3: System Deployment - Deploy the application to the production environment.
- T5.4: User Training & Documentation - Prepare user manuals and conduct training sessions for administrators and key users.
- T6.1: System Monitoring & Maintenance - Continuously monitor system performance, security, and availability. Perform regular maintenance tasks.
- T6.2: Bug Fixing & Support - Address reported bugs and provide ongoing technical support to users.
- T6.3: Feedback Collection & Feature Prioritization - Collect user feedback and prioritize new features or enhancements for future iterations.

Risks to account for:
- Scope creep due to evolving stakeholder requirements during development.
- Performance issues with a large number of concurrent users during peak registration periods.
- Security vulnerabilities leading to data breaches or unauthorized access.
- Lack of user adoption due to poor usability or insufficient training.

Recommendations to preserve:
- Utilize a modern, scalable web framework (e.g., React/Angular/Vue for frontend, Node.js/Python/Java for backend) and a robust relational database (e.g., PostgreSQL).
- Adopt an Agile development methodology (e.g., Scrum) to allow for iterative development, continuous feedback, and flexibility to adapt to changing requirements.
- Implement multi-factor authentication (MFA) for all user roles, especially administrators, to enhance security.
- Design the system with a microservices-oriented architecture (if complexity allows) or a modular monolith to facilitate future scaling and independent development of features.

Assumptions to keep visible:
- The project will be developed as a standalone web application, with no initial integration required with existing university legacy systems (e.g., student information systems, payment gateways).
- A dedicated development team (frontend, backend, QA, DevOps, UI/UX) will be available for the project duration.
- The primary user roles will be Student, Instructor, and Administrator, each with distinct permissions and workflows.
- Cloud infrastructure (e.g., AWS, Azure, GCP) will be used for deployment, providing scalability and managed services.
- Stakeholders will be available for timely feedback and approvals during the discovery, design, and UAT phases.

## Related Phases
- P1: Discovery & Planning (2 weeks) - To gather detailed requirements, define system scope, and create a foundational project plan.
- P2: Design & Architecture (3 weeks) - To create detailed system architecture, database schema, and user interface designs.
- P3: Development (8 weeks) - To implement the frontend, backend, and database components of the system.
- P4: Testing & Quality Assurance (4 weeks) - To ensure the system is robust, secure, and meets all functional and non-functional requirements.
- P5: Deployment & Launch (1 week) - To deploy the system to a production environment and make it available to users.
- P6: Post-Launch Support & Iteration (Ongoing) - To monitor system performance, address issues, and plan for future enhancements.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The project will be developed as a standalone web application, with no initial integration required with existing university legacy systems (e.g., student information systems, payment gateways).
- A dedicated development team (frontend, backend, QA, DevOps, UI/UX) will be available for the project duration.
- The primary user roles will be Student, Instructor, and Administrator, each with distinct permissions and workflows.
- Cloud infrastructure (e.g., AWS, Azure, GCP) will be used for deployment, providing scalability and managed services.
- Stakeholders will be available for timely feedback and approvals during the discovery, design, and UAT phases.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The DevOps Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed functional requirements document approved by stakeholders
- User stories defined for all core workflows
- Non-functional requirements document approved

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### Security Reviewer implementation prompt

**Target Role:** Security Reviewer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Review implementation plans for security, privacy, access control, data handling, and compliance risks.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5
- P6

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The project will be developed as a standalone web application, with no initial integration required with existing university legacy systems (e.g., student information systems, payment gateways).
- A dedicated development team (frontend, backend, QA, DevOps, UI/UX) will be available for the project duration.
- The primary user roles will be Student, Instructor, and Administrator, each with distinct permissions and workflows.
- Cloud infrastructure (e.g., AWS, Azure, GCP) will be used for deployment, providing scalability and managed services.
- Stakeholders will be available for timely feedback and approvals during the discovery, design, and UAT phases.

**Acceptance Criteria:**
- The Security Reviewer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed functional requirements document approved by stakeholders
- User stories defined for all core workflows
- Non-functional requirements document approved

**Prompt:**
```text
You are a senior security engineer responsible for reviewing the plan for security and privacy risks.

## Project Context
Project name: University Course Registration System
Project description: Build a web-based application to enable university students to register for courses, manage their schedules, and allow administrators to manage courses, students, and instructors.
Domain: software
Project type: software application
Complexity: medium
Summary: A comprehensive plan for developing a university course registration system, covering discovery, design, development, testing, and deployment phases. The system will include user authentication, course browsing, registration workflows, and administrative management features.

## Your Role
Security Reviewer

## Goal
Review implementation plans for security, privacy, access control, data handling, and compliance risks.

## Technical Scope
Threat modeling, authentication and authorization concerns, sensitive data handling, dependency risk, and secure defaults.

Relevant tasks:
- T1.1: Gather Functional Requirements - Conduct workshops and interviews with stakeholders (students, faculty, administrators) to define core features and user stories for course browsing, registration, dropping, course management, user management, and reporting.
- T1.2: Define Non-Functional Requirements - Document requirements for performance, security, scalability, usability, and accessibility.
- T1.3: Technology Stack Selection - Evaluate and select appropriate technologies for frontend, backend, database, and deployment based on requirements and team expertise.
- T1.4: Project Plan Finalization - Refine project scope, timeline, resource allocation, and risk assessment based on gathered information.
- T2.1: System Architecture Design - Design the overall system architecture, including microservices/monolith approach, API gateways, and integration patterns.
- T2.2: Database Schema Design - Design the database schema for entities like User (Student, Instructor, Admin), Course, Enrollment, Schedule, Notification.
- T2.3: API Design & Documentation - Design RESTful APIs for CRUD operations, authentication, and other core functionalities. Document APIs using OpenAPI/Swagger.
- T2.4: UI/UX Design & Prototyping - Create wireframes, mockups, and interactive prototypes for all user roles (student, instructor, admin) focusing on responsive design and usability.
- T3.1: Database Implementation - Set up the database and implement the designed schema.
- T3.2: Backend API Development (Authentication & Authorization) - Develop APIs for user registration, login, session management, and role-based access control.
- T3.3: Backend API Development (Core CRUD Workflows) - Develop APIs for managing courses, enrollments, users (students, instructors, admins), and schedules.
- T3.4: Frontend Development (User Authentication & Dashboard) - Implement user login, registration, and the main dashboard views for students, instructors, and administrators.
- T3.5: Frontend Development (Course Management & Registration) - Implement UI for course browsing, searching, registration, dropping courses, and administrative course management.
- T3.6: Notification System Implementation - Implement a system for sending notifications (e.g., registration confirmation, course updates) to users.
- T4.1: Unit Testing - Write and execute unit tests for all backend and frontend components.
- T4.2: Integration Testing - Test the integration between frontend and backend, and between different backend services.
- T4.3: End-to-End (E2E) Testing - Perform E2E tests for critical user workflows (e.g., student registration, course enrollment, admin course creation).
- T4.4: Security Testing - Conduct vulnerability scanning and penetration testing to identify and fix security flaws.
- T4.5: User Acceptance Testing (UAT) - Engage end-users (students, faculty, administrators) to test the system and provide feedback.
- T5.1: Infrastructure Setup - Provision and configure production servers, databases, and networking components.
- T5.2: Deployment Automation - Set up CI/CD pipelines for automated deployment to production.
- T5.3: System Deployment - Deploy the application to the production environment.
- T5.4: User Training & Documentation - Prepare user manuals and conduct training sessions for administrators and key users.
- T6.1: System Monitoring & Maintenance - Continuously monitor system performance, security, and availability. Perform regular maintenance tasks.
- T6.2: Bug Fixing & Support - Address reported bugs and provide ongoing technical support to users.
- T6.3: Feedback Collection & Feature Prioritization - Collect user feedback and prioritize new features or enhancements for future iterations.

Risks to account for:
- Scope creep due to evolving stakeholder requirements during development.
- Performance issues with a large number of concurrent users during peak registration periods.
- Security vulnerabilities leading to data breaches or unauthorized access.
- Lack of user adoption due to poor usability or insufficient training.

Recommendations to preserve:
- Utilize a modern, scalable web framework (e.g., React/Angular/Vue for frontend, Node.js/Python/Java for backend) and a robust relational database (e.g., PostgreSQL).
- Adopt an Agile development methodology (e.g., Scrum) to allow for iterative development, continuous feedback, and flexibility to adapt to changing requirements.
- Implement multi-factor authentication (MFA) for all user roles, especially administrators, to enhance security.
- Design the system with a microservices-oriented architecture (if complexity allows) or a modular monolith to facilitate future scaling and independent development of features.

Assumptions to keep visible:
- The project will be developed as a standalone web application, with no initial integration required with existing university legacy systems (e.g., student information systems, payment gateways).
- A dedicated development team (frontend, backend, QA, DevOps, UI/UX) will be available for the project duration.
- The primary user roles will be Student, Instructor, and Administrator, each with distinct permissions and workflows.
- Cloud infrastructure (e.g., AWS, Azure, GCP) will be used for deployment, providing scalability and managed services.
- Stakeholders will be available for timely feedback and approvals during the discovery, design, and UAT phases.

## Related Phases
- P1: Discovery & Planning (2 weeks) - To gather detailed requirements, define system scope, and create a foundational project plan.
- P2: Design & Architecture (3 weeks) - To create detailed system architecture, database schema, and user interface designs.
- P3: Development (8 weeks) - To implement the frontend, backend, and database components of the system.
- P4: Testing & Quality Assurance (4 weeks) - To ensure the system is robust, secure, and meets all functional and non-functional requirements.
- P5: Deployment & Launch (1 week) - To deploy the system to a production environment and make it available to users.
- P6: Post-Launch Support & Iteration (Ongoing) - To monitor system performance, address issues, and plan for future enhancements.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The project will be developed as a standalone web application, with no initial integration required with existing university legacy systems (e.g., student information systems, payment gateways).
- A dedicated development team (frontend, backend, QA, DevOps, UI/UX) will be available for the project duration.
- The primary user roles will be Student, Instructor, and Administrator, each with distinct permissions and workflows.
- Cloud infrastructure (e.g., AWS, Azure, GCP) will be used for deployment, providing scalability and managed services.
- Stakeholders will be available for timely feedback and approvals during the discovery, design, and UAT phases.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Security Reviewer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed functional requirements document approved by stakeholders
- User stories defined for all core workflows
- Non-functional requirements document approved

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

## Prompt Quality Evaluations
### Evaluation for EP1

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP2

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP3

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP4

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP5

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP6

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.
