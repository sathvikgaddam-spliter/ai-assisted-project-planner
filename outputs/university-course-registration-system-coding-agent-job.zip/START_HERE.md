# Start Here

## Purpose
This folder is a coding-agent execution pack for building a runnable generic web application.

## Instruction for Codex, Claude Code, Cursor, Copilot, Lovable, Bolt, Gemini, or Similar Agents
Create a complete runnable MVP application from these specifications.

You must generate actual source code, build/runtime configuration, run scripts, and tests.
Do not only summarize, critique, or restate the markdown documents.

## Source of Truth
1. Read coding_agent_prompt.md first.
2. Follow requirements.md for functional scope and acceptance criteria.
3. Follow architecture.md for component boundaries and data flow.
4. Follow database_schema.md for data models, fields, relationships, and constraints.
5. Follow api_spec.md for backend routes, request/response expectations, and authorization behavior.
6. Follow frontend_spec.md for pages, components, user flows, and UI states.
7. Follow testing_plan.md for required validation coverage.
8. Use assumptions.md when the original user request is incomplete.

## Required Output
- A runnable application source tree.
- Build and runtime configuration such as package.json, pyproject.toml, requirements.txt, pom.xml, build.gradle, Makefile, or equivalent for the selected stack.
- Frontend and backend source files when the architecture requires both.
- Database models, migrations, seed data, or in-memory persistence suitable for the MVP.
- Automated tests for core behavior.
- A README with exact install, run, test, and build commands.

## Completion Rule
The implementation is not complete until a developer can run the generated project locally using the commands documented in the generated README.
