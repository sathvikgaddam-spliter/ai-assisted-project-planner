# API Specification

## Authentication
Use authenticated routes for user-owned data and admin-only routes for administrative actions.

## Required API Capabilities
- auth APIs
- workspace APIs
- membership APIs
- subscription APIs

## User Endpoints

- `GET /api/users`: list users; supports pagination and filtering.
- `POST /api/users`: create a User; validates request body and ownership.
- `GET /api/users/{id}`: fetch one User; returns 404 when unavailable.
- `PATCH /api/users/{id}`: update a User; enforces authorization.
- `DELETE /api/users/{id}`: archive or delete a User; requires authorization.

## Workspace Endpoints

- `GET /api/workspaces`: list workspaces; supports pagination and filtering.
- `POST /api/workspaces`: create a Workspace; validates request body and ownership.
- `GET /api/workspaces/{id}`: fetch one Workspace; returns 404 when unavailable.
- `PATCH /api/workspaces/{id}`: update a Workspace; enforces authorization.
- `DELETE /api/workspaces/{id}`: archive or delete a Workspace; requires authorization.

## Membership Endpoints

- `GET /api/memberships`: list memberships; supports pagination and filtering.
- `POST /api/memberships`: create a Membership; validates request body and ownership.
- `GET /api/memberships/{id}`: fetch one Membership; returns 404 when unavailable.
- `PATCH /api/memberships/{id}`: update a Membership; enforces authorization.
- `DELETE /api/memberships/{id}`: archive or delete a Membership; requires authorization.

## Subscription Endpoints

- `GET /api/subscriptions`: list subscriptions; supports pagination and filtering.
- `POST /api/subscriptions`: create a Subscription; validates request body and ownership.
- `GET /api/subscriptions/{id}`: fetch one Subscription; returns 404 when unavailable.
- `PATCH /api/subscriptions/{id}`: update a Subscription; enforces authorization.
- `DELETE /api/subscriptions/{id}`: archive or delete a Subscription; requires authorization.

## AuditLog Endpoints

- `GET /api/audit-logs`: list audit-logs; supports pagination and filtering.
- `POST /api/audit-logs`: create a AuditLog; validates request body and ownership.
- `GET /api/audit-logs/{id}`: fetch one AuditLog; returns 404 when unavailable.
- `PATCH /api/audit-logs/{id}`: update a AuditLog; enforces authorization.
- `DELETE /api/audit-logs/{id}`: archive or delete a AuditLog; requires authorization.

## Request/Response Expectations
- Use JSON request bodies.
- Return validation errors with field-level messages.
- Return consistent success envelopes for created and updated records.
