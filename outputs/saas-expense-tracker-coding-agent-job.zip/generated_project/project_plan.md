# Build a SaaS expense tracker

## Summary
Draft incomplete plan: A medium complexity SaaS platform in the software domain. Requirements are incomplete and should be clarified before implementation.

- Domain: software
- Project type: SaaS platform
- Complexity: medium
- Status: clarification_required

## Draft Plan Warning
This is a draft execution plan generated from incomplete requirements.
Clarification is required before implementation.
Assumptions must be validated.
Engineering prompts are provisional.
Engineer review is required before treating this as production-ready.

## Clarification Questions
- What type of project is this: software, analytics, business, academic, healthcare, or something else?
- Who are the target users or stakeholders?
- What concrete deliverable should the project produce?
- What timeline, resources, or constraints should the plan respect?

## Warnings
- This is a draft execution plan generated from incomplete requirements. Answer clarification questions before implementation.

## Phases
### P1: Discovery and Requirements
Define users, scope, core workflows, and MVP boundaries.

Estimated duration: 1-2 weeks

Tasks:
- T1: Identify users and goals - Document user segments, goals, and success criteria.
- T2: Define MVP scope - Prioritize core features and defer nonessential capabilities. Dependencies: T1.

Deliverables:
- requirements brief
- MVP scope

### P2: Architecture and Design
Design the technical foundation and user experience.

Estimated duration: 1-2 weeks

Tasks:
- T3: Design data model - Define entities, relationships, and persistence needs. Dependencies: T2.
- T4: Design user workflows - Map primary screens or API flows for the MVP. Dependencies: T2.

Deliverables:
- architecture outline
- workflow design

### P3: Implementation
Build the MVP features in dependency order.

Estimated duration: 3-6 weeks

Tasks:
- T5: Build backend foundation - Implement core services, validation, and data access. Dependencies: T3.
- T6: Build user-facing workflow - Implement the primary user workflow and connect it to backend services. Dependencies: T4, T5.

Deliverables:
- working MVP

### P4: Testing and Launch
Validate the MVP and prepare a controlled release.

Estimated duration: 1-2 weeks

Tasks:
- T7: Run functional testing - Test critical workflows, validation rules, and failure paths. Dependencies: T6.
- T8: Prepare launch checklist - Confirm deployment, monitoring, documentation, and rollback steps. Dependencies: T7.

Deliverables:
- test report
- launch checklist

## Milestones
- M1: Discovery and Requirements Complete (P1)
- M2: Architecture and Design Complete (P2)
- M3: Implementation Complete (P3)
- M4: Testing and Launch Complete (P4)

## Risks
- R1: Project scope may expand beyond the initial plan. Mitigation: Maintain an explicit MVP scope and review changes before adding work.
- R2: Missing stakeholder input may lead to rework. Mitigation: Confirm requirements and acceptance criteria before implementation.

## Recommendations
- Planning: Validate assumptions before execution starts.
- Delivery: Use milestones as decision gates before expanding scope.

## Assumptions
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.

## Engineering Prompt Pack
### Frontend Engineer implementation prompt

**Target Role:** Frontend Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Implement the frontend experience for the planned project while preserving the validated project scope.

**Related Phases:**
- P1
- P2
- P3
- P4

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- This is a draft execution plan generated from incomplete requirements. Answer clarification questions before implementation.

**Acceptance Criteria:**
- The Frontend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Identify users and goals is reviewed and accepted by the project lead.
- Define MVP scope is reviewed and accepted by the project lead.
- Design data model is reviewed and accepted by the project lead.

**Prompt:**
```text
You are a senior frontend engineer responsible for implementing the user-facing experience.

## Project Context
Project name: Build a SaaS expense tracker
Project description: Build a SaaS expense tracker
Domain: software
Project type: SaaS platform
Complexity: medium
Summary: Draft incomplete plan: A medium complexity SaaS platform in the software domain. Requirements are incomplete and should be clarified before implementation.

## Your Role
Frontend Engineer

## Goal
Implement the frontend experience for the planned project while preserving the validated project scope.

## Technical Scope
UI workflows, client-side validation, accessibility, responsive behavior, and integration points with backend APIs.

Relevant tasks:
- T1: Identify users and goals - Document user segments, goals, and success criteria.
- T2: Define MVP scope - Prioritize core features and defer nonessential capabilities.
- T3: Design data model - Define entities, relationships, and persistence needs.
- T4: Design user workflows - Map primary screens or API flows for the MVP.
- T5: Build backend foundation - Implement core services, validation, and data access.
- T6: Build user-facing workflow - Implement the primary user workflow and connect it to backend services.
- T7: Run functional testing - Test critical workflows, validation rules, and failure paths.
- T8: Prepare launch checklist - Confirm deployment, monitoring, documentation, and rollback steps.

Risks to account for:
- Project scope may expand beyond the initial plan.
- Missing stakeholder input may lead to rework.

Recommendations to preserve:
- Validate assumptions before execution starts.
- Use milestones as decision gates before expanding scope.

Assumptions to keep visible:
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.

## Related Phases
- P1: Discovery and Requirements (1-2 weeks) - Define users, scope, core workflows, and MVP boundaries.
- P2: Architecture and Design (1-2 weeks) - Design the technical foundation and user experience.
- P3: Implementation (3-6 weeks) - Build the MVP features in dependency order.
- P4: Testing and Launch (1-2 weeks) - Validate the MVP and prepare a controlled release.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- This is a draft execution plan generated from incomplete requirements. Answer clarification questions before implementation.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Frontend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Identify users and goals is reviewed and accepted by the project lead.
- Define MVP scope is reviewed and accepted by the project lead.
- Design data model is reviewed and accepted by the project lead.

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### Backend Engineer implementation prompt

**Target Role:** Backend Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Implement backend services that support the planned workflows, validation rules, and task sequencing.

**Related Phases:**
- P1
- P2
- P3
- P4

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- This is a draft execution plan generated from incomplete requirements. Answer clarification questions before implementation.

**Acceptance Criteria:**
- The Backend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Identify users and goals is reviewed and accepted by the project lead.
- Define MVP scope is reviewed and accepted by the project lead.
- Design data model is reviewed and accepted by the project lead.

**Prompt:**
```text
You are a senior backend engineer responsible for building the application services and API layer.

## Project Context
Project name: Build a SaaS expense tracker
Project description: Build a SaaS expense tracker
Domain: software
Project type: SaaS platform
Complexity: medium
Summary: Draft incomplete plan: A medium complexity SaaS platform in the software domain. Requirements are incomplete and should be clarified before implementation.

## Your Role
Backend Engineer

## Goal
Implement backend services that support the planned workflows, validation rules, and task sequencing.

## Technical Scope
API contracts, service logic, validation, error handling, integrations, and backend test coverage.

Relevant tasks:
- T1: Identify users and goals - Document user segments, goals, and success criteria.
- T2: Define MVP scope - Prioritize core features and defer nonessential capabilities.
- T3: Design data model - Define entities, relationships, and persistence needs.
- T4: Design user workflows - Map primary screens or API flows for the MVP.
- T5: Build backend foundation - Implement core services, validation, and data access.
- T6: Build user-facing workflow - Implement the primary user workflow and connect it to backend services.
- T7: Run functional testing - Test critical workflows, validation rules, and failure paths.
- T8: Prepare launch checklist - Confirm deployment, monitoring, documentation, and rollback steps.

Risks to account for:
- Project scope may expand beyond the initial plan.
- Missing stakeholder input may lead to rework.

Recommendations to preserve:
- Validate assumptions before execution starts.
- Use milestones as decision gates before expanding scope.

Assumptions to keep visible:
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.

## Related Phases
- P1: Discovery and Requirements (1-2 weeks) - Define users, scope, core workflows, and MVP boundaries.
- P2: Architecture and Design (1-2 weeks) - Design the technical foundation and user experience.
- P3: Implementation (3-6 weeks) - Build the MVP features in dependency order.
- P4: Testing and Launch (1-2 weeks) - Validate the MVP and prepare a controlled release.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- This is a draft execution plan generated from incomplete requirements. Answer clarification questions before implementation.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Backend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Identify users and goals is reviewed and accepted by the project lead.
- Define MVP scope is reviewed and accepted by the project lead.
- Design data model is reviewed and accepted by the project lead.

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### Database Engineer implementation prompt

**Target Role:** Database Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Define storage structures that support the project requirements without inventing unsupported data sources.

**Related Phases:**
- P1
- P2
- P3
- P4

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- This is a draft execution plan generated from incomplete requirements. Answer clarification questions before implementation.

**Acceptance Criteria:**
- The Database Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Identify users and goals is reviewed and accepted by the project lead.
- Define MVP scope is reviewed and accepted by the project lead.
- Design data model is reviewed and accepted by the project lead.

**Prompt:**
```text
You are a senior database engineer responsible for designing the data model and persistence approach.

## Project Context
Project name: Build a SaaS expense tracker
Project description: Build a SaaS expense tracker
Domain: software
Project type: SaaS platform
Complexity: medium
Summary: Draft incomplete plan: A medium complexity SaaS platform in the software domain. Requirements are incomplete and should be clarified before implementation.

## Your Role
Database Engineer

## Goal
Define storage structures that support the project requirements without inventing unsupported data sources.

## Technical Scope
Entities, relationships, indexes, migrations, data quality checks, retention needs, and backup assumptions.

Relevant tasks:
- T1: Identify users and goals - Document user segments, goals, and success criteria.
- T2: Define MVP scope - Prioritize core features and defer nonessential capabilities.
- T3: Design data model - Define entities, relationships, and persistence needs.
- T4: Design user workflows - Map primary screens or API flows for the MVP.
- T5: Build backend foundation - Implement core services, validation, and data access.
- T6: Build user-facing workflow - Implement the primary user workflow and connect it to backend services.
- T7: Run functional testing - Test critical workflows, validation rules, and failure paths.
- T8: Prepare launch checklist - Confirm deployment, monitoring, documentation, and rollback steps.

Risks to account for:
- Project scope may expand beyond the initial plan.
- Missing stakeholder input may lead to rework.

Recommendations to preserve:
- Validate assumptions before execution starts.
- Use milestones as decision gates before expanding scope.

Assumptions to keep visible:
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.

## Related Phases
- P1: Discovery and Requirements (1-2 weeks) - Define users, scope, core workflows, and MVP boundaries.
- P2: Architecture and Design (1-2 weeks) - Design the technical foundation and user experience.
- P3: Implementation (3-6 weeks) - Build the MVP features in dependency order.
- P4: Testing and Launch (1-2 weeks) - Validate the MVP and prepare a controlled release.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- This is a draft execution plan generated from incomplete requirements. Answer clarification questions before implementation.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Database Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Identify users and goals is reviewed and accepted by the project lead.
- Define MVP scope is reviewed and accepted by the project lead.
- Design data model is reviewed and accepted by the project lead.

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### QA / Testing Engineer implementation prompt

**Target Role:** QA / Testing Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Create a practical test strategy for the project phases, risks, acceptance criteria, and release workflow.

**Related Phases:**
- P1
- P2
- P3
- P4

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- This is a draft execution plan generated from incomplete requirements. Answer clarification questions before implementation.

**Acceptance Criteria:**
- The QA / Testing Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Identify users and goals is reviewed and accepted by the project lead.
- Define MVP scope is reviewed and accepted by the project lead.
- Design data model is reviewed and accepted by the project lead.

**Prompt:**
```text
You are a senior QA engineer responsible for validating the implementation against the plan.

## Project Context
Project name: Build a SaaS expense tracker
Project description: Build a SaaS expense tracker
Domain: software
Project type: SaaS platform
Complexity: medium
Summary: Draft incomplete plan: A medium complexity SaaS platform in the software domain. Requirements are incomplete and should be clarified before implementation.

## Your Role
QA / Testing Engineer

## Goal
Create a practical test strategy for the project phases, risks, acceptance criteria, and release workflow.

## Technical Scope
Functional tests, regression tests, edge cases, acceptance criteria validation, risk-based testing, and defect reporting.

Relevant tasks:
- T1: Identify users and goals - Document user segments, goals, and success criteria.
- T2: Define MVP scope - Prioritize core features and defer nonessential capabilities.
- T3: Design data model - Define entities, relationships, and persistence needs.
- T4: Design user workflows - Map primary screens or API flows for the MVP.
- T5: Build backend foundation - Implement core services, validation, and data access.
- T6: Build user-facing workflow - Implement the primary user workflow and connect it to backend services.
- T7: Run functional testing - Test critical workflows, validation rules, and failure paths.
- T8: Prepare launch checklist - Confirm deployment, monitoring, documentation, and rollback steps.

Risks to account for:
- Project scope may expand beyond the initial plan.
- Missing stakeholder input may lead to rework.

Recommendations to preserve:
- Validate assumptions before execution starts.
- Use milestones as decision gates before expanding scope.

Assumptions to keep visible:
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.

## Related Phases
- P1: Discovery and Requirements (1-2 weeks) - Define users, scope, core workflows, and MVP boundaries.
- P2: Architecture and Design (1-2 weeks) - Design the technical foundation and user experience.
- P3: Implementation (3-6 weeks) - Build the MVP features in dependency order.
- P4: Testing and Launch (1-2 weeks) - Validate the MVP and prepare a controlled release.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- This is a draft execution plan generated from incomplete requirements. Answer clarification questions before implementation.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The QA / Testing Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Identify users and goals is reviewed and accepted by the project lead.
- Define MVP scope is reviewed and accepted by the project lead.
- Design data model is reviewed and accepted by the project lead.

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### DevOps Engineer implementation prompt

**Target Role:** DevOps Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Plan environment, build, release, monitoring, and rollback work without deploying anything automatically.

**Related Phases:**
- P1
- P2
- P3
- P4

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- This is a draft execution plan generated from incomplete requirements. Answer clarification questions before implementation.

**Acceptance Criteria:**
- The DevOps Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Identify users and goals is reviewed and accepted by the project lead.
- Define MVP scope is reviewed and accepted by the project lead.
- Design data model is reviewed and accepted by the project lead.

**Prompt:**
```text
You are a senior DevOps engineer responsible for deployment readiness and operational workflow.

## Project Context
Project name: Build a SaaS expense tracker
Project description: Build a SaaS expense tracker
Domain: software
Project type: SaaS platform
Complexity: medium
Summary: Draft incomplete plan: A medium complexity SaaS platform in the software domain. Requirements are incomplete and should be clarified before implementation.

## Your Role
DevOps Engineer

## Goal
Plan environment, build, release, monitoring, and rollback work without deploying anything automatically.

## Technical Scope
Local development setup, CI checks, configuration, deployment plan, observability, release checklist, and rollback notes.

Relevant tasks:
- T1: Identify users and goals - Document user segments, goals, and success criteria.
- T2: Define MVP scope - Prioritize core features and defer nonessential capabilities.
- T3: Design data model - Define entities, relationships, and persistence needs.
- T4: Design user workflows - Map primary screens or API flows for the MVP.
- T5: Build backend foundation - Implement core services, validation, and data access.
- T6: Build user-facing workflow - Implement the primary user workflow and connect it to backend services.
- T7: Run functional testing - Test critical workflows, validation rules, and failure paths.
- T8: Prepare launch checklist - Confirm deployment, monitoring, documentation, and rollback steps.

Risks to account for:
- Project scope may expand beyond the initial plan.
- Missing stakeholder input may lead to rework.

Recommendations to preserve:
- Validate assumptions before execution starts.
- Use milestones as decision gates before expanding scope.

Assumptions to keep visible:
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.

## Related Phases
- P1: Discovery and Requirements (1-2 weeks) - Define users, scope, core workflows, and MVP boundaries.
- P2: Architecture and Design (1-2 weeks) - Design the technical foundation and user experience.
- P3: Implementation (3-6 weeks) - Build the MVP features in dependency order.
- P4: Testing and Launch (1-2 weeks) - Validate the MVP and prepare a controlled release.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- This is a draft execution plan generated from incomplete requirements. Answer clarification questions before implementation.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The DevOps Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Identify users and goals is reviewed and accepted by the project lead.
- Define MVP scope is reviewed and accepted by the project lead.
- Design data model is reviewed and accepted by the project lead.

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### Security Reviewer implementation prompt

**Target Role:** Security Reviewer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Review implementation plans for security, privacy, access control, data handling, and compliance risks.

**Related Phases:**
- P1
- P2
- P3
- P4

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- This is a draft execution plan generated from incomplete requirements. Answer clarification questions before implementation.

**Acceptance Criteria:**
- The Security Reviewer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Identify users and goals is reviewed and accepted by the project lead.
- Define MVP scope is reviewed and accepted by the project lead.
- Design data model is reviewed and accepted by the project lead.

**Prompt:**
```text
You are a senior security engineer responsible for reviewing the plan for security and privacy risks.

## Project Context
Project name: Build a SaaS expense tracker
Project description: Build a SaaS expense tracker
Domain: software
Project type: SaaS platform
Complexity: medium
Summary: Draft incomplete plan: A medium complexity SaaS platform in the software domain. Requirements are incomplete and should be clarified before implementation.

## Your Role
Security Reviewer

## Goal
Review implementation plans for security, privacy, access control, data handling, and compliance risks.

## Technical Scope
Threat modeling, authentication and authorization concerns, sensitive data handling, dependency risk, and secure defaults.

Relevant tasks:
- T1: Identify users and goals - Document user segments, goals, and success criteria.
- T2: Define MVP scope - Prioritize core features and defer nonessential capabilities.
- T3: Design data model - Define entities, relationships, and persistence needs.
- T4: Design user workflows - Map primary screens or API flows for the MVP.
- T5: Build backend foundation - Implement core services, validation, and data access.
- T6: Build user-facing workflow - Implement the primary user workflow and connect it to backend services.
- T7: Run functional testing - Test critical workflows, validation rules, and failure paths.
- T8: Prepare launch checklist - Confirm deployment, monitoring, documentation, and rollback steps.

Risks to account for:
- Project scope may expand beyond the initial plan.
- Missing stakeholder input may lead to rework.

Recommendations to preserve:
- Validate assumptions before execution starts.
- Use milestones as decision gates before expanding scope.

Assumptions to keep visible:
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.

## Related Phases
- P1: Discovery and Requirements (1-2 weeks) - Define users, scope, core workflows, and MVP boundaries.
- P2: Architecture and Design (1-2 weeks) - Design the technical foundation and user experience.
- P3: Implementation (3-6 weeks) - Build the MVP features in dependency order.
- P4: Testing and Launch (1-2 weeks) - Validate the MVP and prepare a controlled release.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- This is a draft execution plan generated from incomplete requirements. Answer clarification questions before implementation.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Security Reviewer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Identify users and goals is reviewed and accepted by the project lead.
- Define MVP scope is reviewed and accepted by the project lead.
- Design data model is reviewed and accepted by the project lead.

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

## Prompt Quality Evaluations
### Evaluation for EP1

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP2

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP3

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP4

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP5

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP6

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.
