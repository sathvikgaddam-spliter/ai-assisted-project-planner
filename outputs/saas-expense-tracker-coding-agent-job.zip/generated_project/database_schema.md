# Database Schema

## User

Suggested fields:
- id
- created_at
- updated_at
- status
- email
- display_name
- role

Relationships and constraints:
- Include a stable primary key.
- Track created_at and updated_at timestamps.
- Add indexes for owner, status, and lookup fields where applicable.

## Workspace

Suggested fields:
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

Relationships and constraints:
- Include a stable primary key.
- Track created_at and updated_at timestamps.
- Add indexes for owner, status, and lookup fields where applicable.

## Membership

Suggested fields:
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

Relationships and constraints:
- Include a stable primary key.
- Track created_at and updated_at timestamps.
- Add indexes for owner, status, and lookup fields where applicable.

## Subscription

Suggested fields:
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

Relationships and constraints:
- Include a stable primary key.
- Track created_at and updated_at timestamps.
- Add indexes for owner, status, and lookup fields where applicable.

## AuditLog

Suggested fields:
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

Relationships and constraints:
- Include a stable primary key.
- Track created_at and updated_at timestamps.
- Add indexes for owner, status, and lookup fields where applicable.
