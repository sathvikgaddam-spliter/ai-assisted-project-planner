# Data Model

## User

**Fields**
- id
- created_at
- updated_at
- status
- email
- display_name
- role

**Validation Rules**
- id is required and stable
- created_at and updated_at are maintained
- status uses an explicit allowed value
- owner or permission checks apply where user-owned

**Relationships**
- User records relate to users, workflows, or parent records as required by the MVP.

## Workspace

**Fields**
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

**Validation Rules**
- id is required and stable
- created_at and updated_at are maintained
- status uses an explicit allowed value
- owner or permission checks apply where user-owned

**Relationships**
- Workspace records relate to users, workflows, or parent records as required by the MVP.

## Membership

**Fields**
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

**Validation Rules**
- id is required and stable
- created_at and updated_at are maintained
- status uses an explicit allowed value
- owner or permission checks apply where user-owned

**Relationships**
- Membership records relate to users, workflows, or parent records as required by the MVP.

## Subscription

**Fields**
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

**Validation Rules**
- id is required and stable
- created_at and updated_at are maintained
- status uses an explicit allowed value
- owner or permission checks apply where user-owned

**Relationships**
- Subscription records relate to users, workflows, or parent records as required by the MVP.

## AuditLog

**Fields**
- id
- created_at
- updated_at
- status
- name
- description
- owner_id

**Validation Rules**
- id is required and stable
- created_at and updated_at are maintained
- status uses an explicit allowed value
- owner or permission checks apply where user-owned

**Relationships**
- AuditLog records relate to users, workflows, or parent records as required by the MVP.
