# API Contract

## Conventions

- JSON request and response bodies
- field-level validation errors
- 404 for missing resources
- authorization checks on user-owned records

## /api/users

- `GET /api/users` lists users.
- `POST /api/users` creates a User.
- `GET /api/users/{id}` returns one User.
- `PATCH /api/users/{id}` updates a User.
- `DELETE /api/users/{id}` archives or deletes a User.

## /api/workspaces

- `GET /api/workspaces` lists workspaces.
- `POST /api/workspaces` creates a Workspace.
- `GET /api/workspaces/{id}` returns one Workspace.
- `PATCH /api/workspaces/{id}` updates a Workspace.
- `DELETE /api/workspaces/{id}` archives or deletes a Workspace.

## /api/memberships

- `GET /api/memberships` lists memberships.
- `POST /api/memberships` creates a Membership.
- `GET /api/memberships/{id}` returns one Membership.
- `PATCH /api/memberships/{id}` updates a Membership.
- `DELETE /api/memberships/{id}` archives or deletes a Membership.

## /api/subscriptions

- `GET /api/subscriptions` lists subscriptions.
- `POST /api/subscriptions` creates a Subscription.
- `GET /api/subscriptions/{id}` returns one Subscription.
- `PATCH /api/subscriptions/{id}` updates a Subscription.
- `DELETE /api/subscriptions/{id}` archives or deletes a Subscription.

## /api/audit-logs

- `GET /api/audit-logs` lists audit-logs.
- `POST /api/audit-logs` creates a AuditLog.
- `GET /api/audit-logs/{id}` returns one AuditLog.
- `PATCH /api/audit-logs/{id}` updates a AuditLog.
- `DELETE /api/audit-logs/{id}` archives or deletes a AuditLog.

## Workflow APIs

- auth APIs
- workspace APIs
- membership APIs
- subscription APIs
