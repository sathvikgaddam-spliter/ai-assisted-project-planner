# Quickstart: SaaS application

## Local Setup

1. Install backend dependencies.
2. Install frontend dependencies.
3. Create local environment variables.
4. Apply migrations or initialize local persistence.
5. Start backend/API service.
6. Start frontend dev server.

## Validation

1. Run unit tests.
2. Run API/integration tests.
3. Run frontend tests.
4. Run end-to-end tests for the primary workflows.
5. Open the app locally and complete each MVP user story.

## Expected Result

The generated project runs locally and supports account setup, workspace management, subscription management, team collaboration.
