# Prompt Quality Report

## EP1

- Score: 100/100
- Quality score: 100/100
- Ready to use: True

### Passed Checks
- Objective
- Context
- Scope or Requirements
- Constraints
- Acceptance Criteria
- Assumptions or Dependencies
- Review/Validation Notes
- Expected Deliverables or Output Expectations

### Missing Sections
- No missing sections recorded.

### Warnings
- Draft prompt warning: requirements are incomplete and assumptions must be validated.

### Review Notes
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Strengths
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

### Issues
- No issues recorded.

### Improvement Suggestions
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

## EP2

- Score: 100/100
- Quality score: 100/100
- Ready to use: True

### Passed Checks
- Objective
- Context
- Scope or Requirements
- Constraints
- Acceptance Criteria
- Assumptions or Dependencies
- Review/Validation Notes
- Expected Deliverables or Output Expectations

### Missing Sections
- No missing sections recorded.

### Warnings
- Draft prompt warning: requirements are incomplete and assumptions must be validated.

### Review Notes
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Strengths
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

### Issues
- No issues recorded.

### Improvement Suggestions
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

## EP3

- Score: 100/100
- Quality score: 100/100
- Ready to use: True

### Passed Checks
- Objective
- Context
- Scope or Requirements
- Constraints
- Acceptance Criteria
- Assumptions or Dependencies
- Review/Validation Notes
- Expected Deliverables or Output Expectations

### Missing Sections
- No missing sections recorded.

### Warnings
- Draft prompt warning: requirements are incomplete and assumptions must be validated.

### Review Notes
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Strengths
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

### Issues
- No issues recorded.

### Improvement Suggestions
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

## EP4

- Score: 100/100
- Quality score: 100/100
- Ready to use: True

### Passed Checks
- Objective
- Context
- Scope or Requirements
- Constraints
- Acceptance Criteria
- Assumptions or Dependencies
- Review/Validation Notes
- Expected Deliverables or Output Expectations

### Missing Sections
- No missing sections recorded.

### Warnings
- Draft prompt warning: requirements are incomplete and assumptions must be validated.

### Review Notes
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Strengths
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

### Issues
- No issues recorded.

### Improvement Suggestions
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

## EP5

- Score: 100/100
- Quality score: 100/100
- Ready to use: True

### Passed Checks
- Objective
- Context
- Scope or Requirements
- Constraints
- Acceptance Criteria
- Assumptions or Dependencies
- Review/Validation Notes
- Expected Deliverables or Output Expectations

### Missing Sections
- No missing sections recorded.

### Warnings
- Draft prompt warning: requirements are incomplete and assumptions must be validated.

### Review Notes
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Strengths
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

### Issues
- No issues recorded.

### Improvement Suggestions
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

## EP6

- Score: 100/100
- Quality score: 100/100
- Ready to use: True

### Passed Checks
- Objective
- Context
- Scope or Requirements
- Constraints
- Acceptance Criteria
- Assumptions or Dependencies
- Review/Validation Notes
- Expected Deliverables or Output Expectations

### Missing Sections
- No missing sections recorded.

### Warnings
- Draft prompt warning: requirements are incomplete and assumptions must be validated.

### Review Notes
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Strengths
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

### Issues
- No issues recorded.

### Improvement Suggestions
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.
