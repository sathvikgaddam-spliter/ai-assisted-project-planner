# Draft Clarification Questions

- What type of project is this: software, analytics, business, academic, healthcare, or something else?
- Who are the target users or stakeholders?
- What concrete deliverable should the project produce?
- What timeline, resources, or constraints should the plan respect?
