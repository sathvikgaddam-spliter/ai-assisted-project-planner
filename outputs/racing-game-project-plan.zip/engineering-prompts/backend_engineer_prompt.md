# Backend Engineer implementation prompt

**Target Role:** Backend Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Implement backend services that support the planned workflows, validation rules, and task sequencing.

## Related Phases
- P1
- P2
- P3
- P4

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- This is a draft execution plan generated from incomplete requirements. Answer clarification questions before implementation.

## Acceptance Criteria
- The Backend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Identify users and goals is reviewed and accepted by the project lead.
- Define MVP scope is reviewed and accepted by the project lead.
- Design data model is reviewed and accepted by the project lead.

## Prompt
```text
You are a senior backend engineer responsible for building the application services and API layer.

## Project Context
Project name: Build a racing game
Project description: Build a racing game
Domain: software
Project type: game application
Complexity: medium
Summary: Draft incomplete plan: A medium complexity game application in the software domain. Requirements are incomplete and should be clarified before implementation.

## Your Role
Backend Engineer

## Goal
Implement backend services that support the planned workflows, validation rules, and task sequencing.

## Technical Scope
API contracts, service logic, validation, error handling, integrations, and backend test coverage.

Relevant tasks:
- T1: Identify users and goals - Document user segments, goals, and success criteria.
- T2: Define MVP scope - Prioritize core features and defer nonessential capabilities.
- T3: Design data model - Define entities, relationships, and persistence needs.
- T4: Design user workflows - Map primary screens or API flows for the MVP.
- T5: Build backend foundation - Implement core services, validation, and data access.
- T6: Build user-facing workflow - Implement the primary user workflow and connect it to backend services.
- T7: Run functional testing - Test critical workflows, validation rules, and failure paths.
- T8: Prepare launch checklist - Confirm deployment, monitoring, documentation, and rollback steps.

Risks to account for:
- Project scope may expand beyond the initial plan.
- Missing stakeholder input may lead to rework.

Recommendations to preserve:
- Validate assumptions before execution starts.
- Use milestones as decision gates before expanding scope.

Assumptions to keep visible:
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.

## Related Phases
- P1: Discovery and Requirements (1-2 weeks) - Define users, scope, core workflows, and MVP boundaries.
- P2: Architecture and Design (1-2 weeks) - Design the technical foundation and user experience.
- P3: Implementation (3-6 weeks) - Build the MVP features in dependency order.
- P4: Testing and Launch (1-2 weeks) - Validate the MVP and prepare a controlled release.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Target users was not specified and should be confirmed.
- Timeline was not specified and should be confirmed.
- This is a draft execution plan generated from incomplete requirements. Answer clarification questions before implementation.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Backend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Identify users and goals is reviewed and accepted by the project lead.
- Define MVP scope is reviewed and accepted by the project lead.
- Design data model is reviewed and accepted by the project lead.

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```
