# University Course Registration System

## Summary
A web-based system designed for universities to streamline course registration. It will provide functionalities for students to browse, select, and register for courses, view their schedules, and for administrators to manage course offerings, student data, and registration processes. The system will feature user authentication, a responsive user interface, and robust backend APIs for data management.

- Domain: software
- Project type: software application
- Complexity: medium
- Status: plan_generated

## Clarification Questions
- Who are the primary target users for this system (e.g., undergraduate students, graduate students, faculty advisors, specific administrative roles)? Please specify roles and their expected interactions.
- What is the desired timeline or target launch date for the initial version of the course registration system?
- Are there any existing university systems (e.g., student information system, authentication service, payment gateway) that this system needs to integrate with? If so, please provide details on APIs or integration methods.
- What are the specific non-functional requirements for the system, such as expected concurrent user load, performance benchmarks, accessibility standards (e.g., WCAG), and specific security compliance needs?
- What is the budget allocated for this project, and are there any specific technology preferences or constraints?

## Warnings
- Missing information regarding 'target users' could lead to incomplete user persona development and potentially misaligned UI/UX or feature prioritization.
- Missing information regarding 'timeline' prevents accurate scheduling and resource allocation, making 'estimated_duration' and 'estimated_effort' placeholders.

## Phases
### P1: Discovery & Planning
To define the project scope, gather detailed requirements, and establish the foundational technical architecture and database design.

Estimated duration: 3 weeks

Tasks:
- T1: Requirements Gathering & Analysis - Conduct workshops and interviews with stakeholders (students, faculty, administrators) to capture functional and non-functional requirements.
- T2: Use Case Definition & User Stories - Define key user roles (Student, Instructor, Administrator) and their interactions with the system, translating requirements into user stories. Dependencies: T1.
- T3: Technical Architecture Design - Design the high-level system architecture, including technology stack, deployment strategy, and integration points (if any). Dependencies: T1, T2.
- T4: Database Schema Design - Design the logical and physical database schema, including entities for Users, Courses, Sections, Registrations, Instructors, etc. Dependencies: T1, T2.

Deliverables:
- Requirements Specification Document
- Use Case Document / User Stories Backlog
- Technical Design Document
- Database Schema Diagram

### P2: Design
To create intuitive and responsive user interface and experience designs for both student and administrator roles.

Estimated duration: 2 weeks

Tasks:
- T5: Wireframing & User Flows - Create low-fidelity wireframes for key screens and define user interaction flows for core functionalities (e.g., course search, registration, admin management). Dependencies: T2.
- T6: UI/UX Mockup Creation - Develop high-fidelity mockups and a consistent design system (colors, typography, components) based on approved wireframes. Dependencies: T5.
- T7: Interactive Prototype Development - Build a clickable prototype to demonstrate core user journeys and gather early feedback on usability. Dependencies: T6.

Deliverables:
- Wireframes
- High-Fidelity UI/UX Mockups
- Design System
- Interactive Prototype

### P3: Development
To implement the backend APIs, database, and frontend user interfaces for all core functionalities.

Estimated duration: 8 weeks

Tasks:
- T8: Backend API Development - Authentication & Authorization - Implement user registration, login, session management, and role-based access control APIs. Dependencies: T3, T4.
- T9: Backend API Development - Course Management - Develop CRUD APIs for managing courses, sections, and instructors. Dependencies: T3, T4, T8.
- T10: Backend API Development - Student & Registration Management - Implement CRUD APIs for student profiles and course registration/deregistration processes. Dependencies: T3, T4, T8, T9.
- T11: Frontend Development - Student Dashboard & Course Catalog - Build the responsive user interface for students to browse courses, view details, register, and manage their schedule. Dependencies: T7, T8, T9, T10.
- T12: Frontend Development - Admin Dashboard & Management - Develop the responsive user interface for administrators to manage courses, students, instructors, and registrations. Dependencies: T7, T8, T9, T10.
- T13: Database Implementation & Seeding - Set up the database instance, apply the schema, and populate with initial test data. Dependencies: T4.

Deliverables:
- Functional Backend APIs
- Functional Frontend Modules (Student & Admin)
- Integrated Database

### P4: Testing & Quality Assurance
To thoroughly test the system for functionality, performance, security, and usability, ensuring it meets all defined requirements.

Estimated duration: 4 weeks

Tasks:
- T14: Unit & Integration Testing - Execute unit tests for individual code components and integration tests for interactions between modules and APIs. Dependencies: T8, T9, T10, T11, T12.
- T15: End-to-End Testing - Perform comprehensive end-to-end testing of all major user workflows from both student and administrator perspectives. Dependencies: T14.
- T16: Security Testing - Conduct security vulnerability assessments (e.g., OWASP Top 10) and penetration testing. Dependencies: T15.
- T17: User Acceptance Testing (UAT) - Engage key stakeholders (e.g., university staff, pilot students) to perform UAT and gather final feedback. Dependencies: T15, T16.

Deliverables:
- Test Plans & Test Cases
- Test Reports (Unit, Integration, E2E)
- Bug Tracking Log
- Security Assessment Report
- UAT Feedback & Sign-off

### P5: Deployment & Launch
To prepare the production environment, deploy the application, and make it available to end-users.

Estimated duration: 2 weeks

Tasks:
- T18: Infrastructure Setup & Configuration - Provision and configure production servers, database, networking, and other necessary infrastructure components. Dependencies: T3.
- T19: CI/CD Pipeline Setup - Configure Continuous Integration/Continuous Deployment pipelines for automated builds, tests, and deployments to production. Dependencies: T18.
- T20: Production Deployment - Deploy the final, tested application to the production environment. Dependencies: T17, T19.
- T21: Post-Deployment Verification & Monitoring Setup - Perform sanity checks on the live system and configure monitoring and alerting tools. Dependencies: T20.

Deliverables:
- Deployed Production System
- Deployment Documentation
- Monitoring & Alerting Configuration

### P6: Post-Launch Support & Maintenance
To provide ongoing support, monitor system performance, address issues, and plan for future enhancements.

Estimated duration: Ongoing

Tasks:
- T22: Bug Fixing & Incident Management - Address reported bugs and incidents, providing timely resolutions and updates. Dependencies: T21.
- T23: Performance Monitoring & Optimization - Continuously monitor system performance, identify bottlenecks, and implement optimizations. Dependencies: T21.
- T24: Feature Enhancements & Updates - Plan and implement minor feature enhancements and system updates based on user feedback and evolving requirements. Dependencies: T22.

Deliverables:
- Support Documentation
- Performance Reports
- Resolved Issue Log
- Feature Enhancement Backlog

## Milestones
- M1: Requirements & Architecture Approved (P1)
- M2: UI/UX Design Approved (P2)
- M3: Core Features Developed (P3)
- M4: System Ready for UAT (P4)
- M5: Production Launch (P5)

## Risks
- R1: Scope creep due to evolving requirements from multiple university stakeholders (students, faculty, administration). Mitigation: Implement strict change control processes. Prioritize features for an MVP and defer non-critical items to future phases. Regularly communicate scope boundaries to stakeholders.
- R2: Performance issues under high load during peak registration periods. Mitigation: Conduct load and stress testing during the QA phase. Design for scalability from the outset (e.g., microservices, cloud-native architecture). Implement caching mechanisms.
- R3: Security vulnerabilities leading to unauthorized access or data breaches. Mitigation: Follow security best practices (OWASP Top 10). Conduct regular security audits and penetration testing. Implement robust authentication and authorization mechanisms. Keep dependencies updated.
- R4: Lack of clarity on specific university policies or integration requirements (e.g., existing student information systems, payment gateways). Mitigation: Address clarification questions early in the Discovery phase. Engage relevant IT and administrative departments to understand existing systems and policies.

## Recommendations
- Project Scope: Define a Minimum Viable Product (MVP) for the initial launch to deliver core value quickly and iterate based on user feedback.
- Stakeholder Engagement: Establish a dedicated project steering committee with representatives from key university departments (e.g., Registrar's Office, IT, Student Affairs) to ensure alignment and timely decision-making.
- Technology & Architecture: Consider using a modern, scalable cloud-based infrastructure and development framework to support potential growth and ensure high availability.

## Assumptions
- A dedicated project team (Project Manager, Business Analyst, UI/UX Designer, Backend Developers, Frontend Developers, QA Engineer, DevOps Engineer) is available for the project duration.
- The project will utilize a standard web technology stack (e.g., modern JavaScript framework for frontend, Python/Node.js/Java for backend, PostgreSQL/MySQL for database).
- No complex integrations with existing university legacy systems (e.g., student information systems, payment gateways) are required in the initial phase, unless explicitly clarified.
- The university will provide necessary access to relevant personnel and existing documentation for requirements gathering and testing.
- Security requirements will adhere to standard web application best practices and university IT policies.

## Engineering Prompt Pack
### Frontend Engineer implementation prompt

**Target Role:** Frontend Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Implement the frontend experience for the planned project while preserving the validated project scope.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5
- P6

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A dedicated project team (Project Manager, Business Analyst, UI/UX Designer, Backend Developers, Frontend Developers, QA Engineer, DevOps Engineer) is available for the project duration.
- The project will utilize a standard web technology stack (e.g., modern JavaScript framework for frontend, Python/Node.js/Java for backend, PostgreSQL/MySQL for database).
- No complex integrations with existing university legacy systems (e.g., student information systems, payment gateways) are required in the initial phase, unless explicitly clarified.
- The university will provide necessary access to relevant personnel and existing documentation for requirements gathering and testing.
- Security requirements will adhere to standard web application best practices and university IT policies.
- Missing information regarding 'target users' could lead to incomplete user persona development and potentially misaligned UI/UX or feature prioritization.
- Missing information regarding 'timeline' prevents accurate scheduling and resource allocation, making 'estimated_duration' and 'estimated_effort' placeholders.

**Acceptance Criteria:**
- The Frontend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed Requirements Specification Document approved by stakeholders.
- List of core features prioritized.
- Comprehensive Use Case Document completed.

**Prompt:**
```text
You are a senior frontend engineer responsible for implementing the user-facing experience.

## Project Context
Project name: University Course Registration System
Project description: Build a university course registration system to allow students to register for courses and administrators to manage courses, students, and registrations.
Domain: software
Project type: software application
Complexity: medium
Summary: A web-based system designed for universities to streamline course registration. It will provide functionalities for students to browse, select, and register for courses, view their schedules, and for administrators to manage course offerings, student data, and registration processes. The system will feature user authentication, a responsive user interface, and robust backend APIs for data management.

## Your Role
Frontend Engineer

## Goal
Implement the frontend experience for the planned project while preserving the validated project scope.

## Technical Scope
UI workflows, client-side validation, accessibility, responsive behavior, and integration points with backend APIs.

Relevant tasks:
- T1: Requirements Gathering & Analysis - Conduct workshops and interviews with stakeholders (students, faculty, administrators) to capture functional and non-functional requirements.
- T2: Use Case Definition & User Stories - Define key user roles (Student, Instructor, Administrator) and their interactions with the system, translating requirements into user stories.
- T3: Technical Architecture Design - Design the high-level system architecture, including technology stack, deployment strategy, and integration points (if any).
- T4: Database Schema Design - Design the logical and physical database schema, including entities for Users, Courses, Sections, Registrations, Instructors, etc.
- T5: Wireframing & User Flows - Create low-fidelity wireframes for key screens and define user interaction flows for core functionalities (e.g., course search, registration, admin management).
- T6: UI/UX Mockup Creation - Develop high-fidelity mockups and a consistent design system (colors, typography, components) based on approved wireframes.
- T7: Interactive Prototype Development - Build a clickable prototype to demonstrate core user journeys and gather early feedback on usability.
- T8: Backend API Development - Authentication & Authorization - Implement user registration, login, session management, and role-based access control APIs.
- T9: Backend API Development - Course Management - Develop CRUD APIs for managing courses, sections, and instructors.
- T10: Backend API Development - Student & Registration Management - Implement CRUD APIs for student profiles and course registration/deregistration processes.
- T11: Frontend Development - Student Dashboard & Course Catalog - Build the responsive user interface for students to browse courses, view details, register, and manage their schedule.
- T12: Frontend Development - Admin Dashboard & Management - Develop the responsive user interface for administrators to manage courses, students, instructors, and registrations.
- T13: Database Implementation & Seeding - Set up the database instance, apply the schema, and populate with initial test data.
- T14: Unit & Integration Testing - Execute unit tests for individual code components and integration tests for interactions between modules and APIs.
- T15: End-to-End Testing - Perform comprehensive end-to-end testing of all major user workflows from both student and administrator perspectives.
- T16: Security Testing - Conduct security vulnerability assessments (e.g., OWASP Top 10) and penetration testing.
- T17: User Acceptance Testing (UAT) - Engage key stakeholders (e.g., university staff, pilot students) to perform UAT and gather final feedback.
- T18: Infrastructure Setup & Configuration - Provision and configure production servers, database, networking, and other necessary infrastructure components.
- T19: CI/CD Pipeline Setup - Configure Continuous Integration/Continuous Deployment pipelines for automated builds, tests, and deployments to production.
- T20: Production Deployment - Deploy the final, tested application to the production environment.
- T21: Post-Deployment Verification & Monitoring Setup - Perform sanity checks on the live system and configure monitoring and alerting tools.
- T22: Bug Fixing & Incident Management - Address reported bugs and incidents, providing timely resolutions and updates.
- T23: Performance Monitoring & Optimization - Continuously monitor system performance, identify bottlenecks, and implement optimizations.
- T24: Feature Enhancements & Updates - Plan and implement minor feature enhancements and system updates based on user feedback and evolving requirements.

Risks to account for:
- Scope creep due to evolving requirements from multiple university stakeholders (students, faculty, administration).
- Performance issues under high load during peak registration periods.
- Security vulnerabilities leading to unauthorized access or data breaches.
- Lack of clarity on specific university policies or integration requirements (e.g., existing student information systems, payment gateways).

Recommendations to preserve:
- Define a Minimum Viable Product (MVP) for the initial launch to deliver core value quickly and iterate based on user feedback.
- Establish a dedicated project steering committee with representatives from key university departments (e.g., Registrar's Office, IT, Student Affairs) to ensure alignment and timely decision-making.
- Consider using a modern, scalable cloud-based infrastructure and development framework to support potential growth and ensure high availability.

Assumptions to keep visible:
- A dedicated project team (Project Manager, Business Analyst, UI/UX Designer, Backend Developers, Frontend Developers, QA Engineer, DevOps Engineer) is available for the project duration.
- The project will utilize a standard web technology stack (e.g., modern JavaScript framework for frontend, Python/Node.js/Java for backend, PostgreSQL/MySQL for database).
- No complex integrations with existing university legacy systems (e.g., student information systems, payment gateways) are required in the initial phase, unless explicitly clarified.
- The university will provide necessary access to relevant personnel and existing documentation for requirements gathering and testing.
- Security requirements will adhere to standard web application best practices and university IT policies.

## Related Phases
- P1: Discovery & Planning (3 weeks) - To define the project scope, gather detailed requirements, and establish the foundational technical architecture and database design.
- P2: Design (2 weeks) - To create intuitive and responsive user interface and experience designs for both student and administrator roles.
- P3: Development (8 weeks) - To implement the backend APIs, database, and frontend user interfaces for all core functionalities.
- P4: Testing & Quality Assurance (4 weeks) - To thoroughly test the system for functionality, performance, security, and usability, ensuring it meets all defined requirements.
- P5: Deployment & Launch (2 weeks) - To prepare the production environment, deploy the application, and make it available to end-users.
- P6: Post-Launch Support & Maintenance (Ongoing) - To provide ongoing support, monitor system performance, address issues, and plan for future enhancements.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A dedicated project team (Project Manager, Business Analyst, UI/UX Designer, Backend Developers, Frontend Developers, QA Engineer, DevOps Engineer) is available for the project duration.
- The project will utilize a standard web technology stack (e.g., modern JavaScript framework for frontend, Python/Node.js/Java for backend, PostgreSQL/MySQL for database).
- No complex integrations with existing university legacy systems (e.g., student information systems, payment gateways) are required in the initial phase, unless explicitly clarified.
- The university will provide necessary access to relevant personnel and existing documentation for requirements gathering and testing.
- Security requirements will adhere to standard web application best practices and university IT policies.
- Missing information regarding 'target users' could lead to incomplete user persona development and potentially misaligned UI/UX or feature prioritization.
- Missing information regarding 'timeline' prevents accurate scheduling and resource allocation, making 'estimated_duration' and 'estimated_effort' placeholders.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Frontend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed Requirements Specification Document approved by stakeholders.
- List of core features prioritized.
- Comprehensive Use Case Document completed.

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### Backend Engineer implementation prompt

**Target Role:** Backend Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Implement backend services that support the planned workflows, validation rules, and task sequencing.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5
- P6

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A dedicated project team (Project Manager, Business Analyst, UI/UX Designer, Backend Developers, Frontend Developers, QA Engineer, DevOps Engineer) is available for the project duration.
- The project will utilize a standard web technology stack (e.g., modern JavaScript framework for frontend, Python/Node.js/Java for backend, PostgreSQL/MySQL for database).
- No complex integrations with existing university legacy systems (e.g., student information systems, payment gateways) are required in the initial phase, unless explicitly clarified.
- The university will provide necessary access to relevant personnel and existing documentation for requirements gathering and testing.
- Security requirements will adhere to standard web application best practices and university IT policies.
- Missing information regarding 'target users' could lead to incomplete user persona development and potentially misaligned UI/UX or feature prioritization.
- Missing information regarding 'timeline' prevents accurate scheduling and resource allocation, making 'estimated_duration' and 'estimated_effort' placeholders.

**Acceptance Criteria:**
- The Backend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed Requirements Specification Document approved by stakeholders.
- List of core features prioritized.
- Comprehensive Use Case Document completed.

**Prompt:**
```text
You are a senior backend engineer responsible for building the application services and API layer.

## Project Context
Project name: University Course Registration System
Project description: Build a university course registration system to allow students to register for courses and administrators to manage courses, students, and registrations.
Domain: software
Project type: software application
Complexity: medium
Summary: A web-based system designed for universities to streamline course registration. It will provide functionalities for students to browse, select, and register for courses, view their schedules, and for administrators to manage course offerings, student data, and registration processes. The system will feature user authentication, a responsive user interface, and robust backend APIs for data management.

## Your Role
Backend Engineer

## Goal
Implement backend services that support the planned workflows, validation rules, and task sequencing.

## Technical Scope
API contracts, service logic, validation, error handling, integrations, and backend test coverage.

Relevant tasks:
- T1: Requirements Gathering & Analysis - Conduct workshops and interviews with stakeholders (students, faculty, administrators) to capture functional and non-functional requirements.
- T2: Use Case Definition & User Stories - Define key user roles (Student, Instructor, Administrator) and their interactions with the system, translating requirements into user stories.
- T3: Technical Architecture Design - Design the high-level system architecture, including technology stack, deployment strategy, and integration points (if any).
- T4: Database Schema Design - Design the logical and physical database schema, including entities for Users, Courses, Sections, Registrations, Instructors, etc.
- T5: Wireframing & User Flows - Create low-fidelity wireframes for key screens and define user interaction flows for core functionalities (e.g., course search, registration, admin management).
- T6: UI/UX Mockup Creation - Develop high-fidelity mockups and a consistent design system (colors, typography, components) based on approved wireframes.
- T7: Interactive Prototype Development - Build a clickable prototype to demonstrate core user journeys and gather early feedback on usability.
- T8: Backend API Development - Authentication & Authorization - Implement user registration, login, session management, and role-based access control APIs.
- T9: Backend API Development - Course Management - Develop CRUD APIs for managing courses, sections, and instructors.
- T10: Backend API Development - Student & Registration Management - Implement CRUD APIs for student profiles and course registration/deregistration processes.
- T11: Frontend Development - Student Dashboard & Course Catalog - Build the responsive user interface for students to browse courses, view details, register, and manage their schedule.
- T12: Frontend Development - Admin Dashboard & Management - Develop the responsive user interface for administrators to manage courses, students, instructors, and registrations.
- T13: Database Implementation & Seeding - Set up the database instance, apply the schema, and populate with initial test data.
- T14: Unit & Integration Testing - Execute unit tests for individual code components and integration tests for interactions between modules and APIs.
- T15: End-to-End Testing - Perform comprehensive end-to-end testing of all major user workflows from both student and administrator perspectives.
- T16: Security Testing - Conduct security vulnerability assessments (e.g., OWASP Top 10) and penetration testing.
- T17: User Acceptance Testing (UAT) - Engage key stakeholders (e.g., university staff, pilot students) to perform UAT and gather final feedback.
- T18: Infrastructure Setup & Configuration - Provision and configure production servers, database, networking, and other necessary infrastructure components.
- T19: CI/CD Pipeline Setup - Configure Continuous Integration/Continuous Deployment pipelines for automated builds, tests, and deployments to production.
- T20: Production Deployment - Deploy the final, tested application to the production environment.
- T21: Post-Deployment Verification & Monitoring Setup - Perform sanity checks on the live system and configure monitoring and alerting tools.
- T22: Bug Fixing & Incident Management - Address reported bugs and incidents, providing timely resolutions and updates.
- T23: Performance Monitoring & Optimization - Continuously monitor system performance, identify bottlenecks, and implement optimizations.
- T24: Feature Enhancements & Updates - Plan and implement minor feature enhancements and system updates based on user feedback and evolving requirements.

Risks to account for:
- Scope creep due to evolving requirements from multiple university stakeholders (students, faculty, administration).
- Performance issues under high load during peak registration periods.
- Security vulnerabilities leading to unauthorized access or data breaches.
- Lack of clarity on specific university policies or integration requirements (e.g., existing student information systems, payment gateways).

Recommendations to preserve:
- Define a Minimum Viable Product (MVP) for the initial launch to deliver core value quickly and iterate based on user feedback.
- Establish a dedicated project steering committee with representatives from key university departments (e.g., Registrar's Office, IT, Student Affairs) to ensure alignment and timely decision-making.
- Consider using a modern, scalable cloud-based infrastructure and development framework to support potential growth and ensure high availability.

Assumptions to keep visible:
- A dedicated project team (Project Manager, Business Analyst, UI/UX Designer, Backend Developers, Frontend Developers, QA Engineer, DevOps Engineer) is available for the project duration.
- The project will utilize a standard web technology stack (e.g., modern JavaScript framework for frontend, Python/Node.js/Java for backend, PostgreSQL/MySQL for database).
- No complex integrations with existing university legacy systems (e.g., student information systems, payment gateways) are required in the initial phase, unless explicitly clarified.
- The university will provide necessary access to relevant personnel and existing documentation for requirements gathering and testing.
- Security requirements will adhere to standard web application best practices and university IT policies.

## Related Phases
- P1: Discovery & Planning (3 weeks) - To define the project scope, gather detailed requirements, and establish the foundational technical architecture and database design.
- P2: Design (2 weeks) - To create intuitive and responsive user interface and experience designs for both student and administrator roles.
- P3: Development (8 weeks) - To implement the backend APIs, database, and frontend user interfaces for all core functionalities.
- P4: Testing & Quality Assurance (4 weeks) - To thoroughly test the system for functionality, performance, security, and usability, ensuring it meets all defined requirements.
- P5: Deployment & Launch (2 weeks) - To prepare the production environment, deploy the application, and make it available to end-users.
- P6: Post-Launch Support & Maintenance (Ongoing) - To provide ongoing support, monitor system performance, address issues, and plan for future enhancements.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A dedicated project team (Project Manager, Business Analyst, UI/UX Designer, Backend Developers, Frontend Developers, QA Engineer, DevOps Engineer) is available for the project duration.
- The project will utilize a standard web technology stack (e.g., modern JavaScript framework for frontend, Python/Node.js/Java for backend, PostgreSQL/MySQL for database).
- No complex integrations with existing university legacy systems (e.g., student information systems, payment gateways) are required in the initial phase, unless explicitly clarified.
- The university will provide necessary access to relevant personnel and existing documentation for requirements gathering and testing.
- Security requirements will adhere to standard web application best practices and university IT policies.
- Missing information regarding 'target users' could lead to incomplete user persona development and potentially misaligned UI/UX or feature prioritization.
- Missing information regarding 'timeline' prevents accurate scheduling and resource allocation, making 'estimated_duration' and 'estimated_effort' placeholders.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Backend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed Requirements Specification Document approved by stakeholders.
- List of core features prioritized.
- Comprehensive Use Case Document completed.

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### Database Engineer implementation prompt

**Target Role:** Database Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Define storage structures that support the project requirements without inventing unsupported data sources.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5
- P6

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A dedicated project team (Project Manager, Business Analyst, UI/UX Designer, Backend Developers, Frontend Developers, QA Engineer, DevOps Engineer) is available for the project duration.
- The project will utilize a standard web technology stack (e.g., modern JavaScript framework for frontend, Python/Node.js/Java for backend, PostgreSQL/MySQL for database).
- No complex integrations with existing university legacy systems (e.g., student information systems, payment gateways) are required in the initial phase, unless explicitly clarified.
- The university will provide necessary access to relevant personnel and existing documentation for requirements gathering and testing.
- Security requirements will adhere to standard web application best practices and university IT policies.
- Missing information regarding 'target users' could lead to incomplete user persona development and potentially misaligned UI/UX or feature prioritization.
- Missing information regarding 'timeline' prevents accurate scheduling and resource allocation, making 'estimated_duration' and 'estimated_effort' placeholders.

**Acceptance Criteria:**
- The Database Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed Requirements Specification Document approved by stakeholders.
- List of core features prioritized.
- Comprehensive Use Case Document completed.

**Prompt:**
```text
You are a senior database engineer responsible for designing the data model and persistence approach.

## Project Context
Project name: University Course Registration System
Project description: Build a university course registration system to allow students to register for courses and administrators to manage courses, students, and registrations.
Domain: software
Project type: software application
Complexity: medium
Summary: A web-based system designed for universities to streamline course registration. It will provide functionalities for students to browse, select, and register for courses, view their schedules, and for administrators to manage course offerings, student data, and registration processes. The system will feature user authentication, a responsive user interface, and robust backend APIs for data management.

## Your Role
Database Engineer

## Goal
Define storage structures that support the project requirements without inventing unsupported data sources.

## Technical Scope
Entities, relationships, indexes, migrations, data quality checks, retention needs, and backup assumptions.

Relevant tasks:
- T1: Requirements Gathering & Analysis - Conduct workshops and interviews with stakeholders (students, faculty, administrators) to capture functional and non-functional requirements.
- T2: Use Case Definition & User Stories - Define key user roles (Student, Instructor, Administrator) and their interactions with the system, translating requirements into user stories.
- T3: Technical Architecture Design - Design the high-level system architecture, including technology stack, deployment strategy, and integration points (if any).
- T4: Database Schema Design - Design the logical and physical database schema, including entities for Users, Courses, Sections, Registrations, Instructors, etc.
- T5: Wireframing & User Flows - Create low-fidelity wireframes for key screens and define user interaction flows for core functionalities (e.g., course search, registration, admin management).
- T6: UI/UX Mockup Creation - Develop high-fidelity mockups and a consistent design system (colors, typography, components) based on approved wireframes.
- T7: Interactive Prototype Development - Build a clickable prototype to demonstrate core user journeys and gather early feedback on usability.
- T8: Backend API Development - Authentication & Authorization - Implement user registration, login, session management, and role-based access control APIs.
- T9: Backend API Development - Course Management - Develop CRUD APIs for managing courses, sections, and instructors.
- T10: Backend API Development - Student & Registration Management - Implement CRUD APIs for student profiles and course registration/deregistration processes.
- T11: Frontend Development - Student Dashboard & Course Catalog - Build the responsive user interface for students to browse courses, view details, register, and manage their schedule.
- T12: Frontend Development - Admin Dashboard & Management - Develop the responsive user interface for administrators to manage courses, students, instructors, and registrations.
- T13: Database Implementation & Seeding - Set up the database instance, apply the schema, and populate with initial test data.
- T14: Unit & Integration Testing - Execute unit tests for individual code components and integration tests for interactions between modules and APIs.
- T15: End-to-End Testing - Perform comprehensive end-to-end testing of all major user workflows from both student and administrator perspectives.
- T16: Security Testing - Conduct security vulnerability assessments (e.g., OWASP Top 10) and penetration testing.
- T17: User Acceptance Testing (UAT) - Engage key stakeholders (e.g., university staff, pilot students) to perform UAT and gather final feedback.
- T18: Infrastructure Setup & Configuration - Provision and configure production servers, database, networking, and other necessary infrastructure components.
- T19: CI/CD Pipeline Setup - Configure Continuous Integration/Continuous Deployment pipelines for automated builds, tests, and deployments to production.
- T20: Production Deployment - Deploy the final, tested application to the production environment.
- T21: Post-Deployment Verification & Monitoring Setup - Perform sanity checks on the live system and configure monitoring and alerting tools.
- T22: Bug Fixing & Incident Management - Address reported bugs and incidents, providing timely resolutions and updates.
- T23: Performance Monitoring & Optimization - Continuously monitor system performance, identify bottlenecks, and implement optimizations.
- T24: Feature Enhancements & Updates - Plan and implement minor feature enhancements and system updates based on user feedback and evolving requirements.

Risks to account for:
- Scope creep due to evolving requirements from multiple university stakeholders (students, faculty, administration).
- Performance issues under high load during peak registration periods.
- Security vulnerabilities leading to unauthorized access or data breaches.
- Lack of clarity on specific university policies or integration requirements (e.g., existing student information systems, payment gateways).

Recommendations to preserve:
- Define a Minimum Viable Product (MVP) for the initial launch to deliver core value quickly and iterate based on user feedback.
- Establish a dedicated project steering committee with representatives from key university departments (e.g., Registrar's Office, IT, Student Affairs) to ensure alignment and timely decision-making.
- Consider using a modern, scalable cloud-based infrastructure and development framework to support potential growth and ensure high availability.

Assumptions to keep visible:
- A dedicated project team (Project Manager, Business Analyst, UI/UX Designer, Backend Developers, Frontend Developers, QA Engineer, DevOps Engineer) is available for the project duration.
- The project will utilize a standard web technology stack (e.g., modern JavaScript framework for frontend, Python/Node.js/Java for backend, PostgreSQL/MySQL for database).
- No complex integrations with existing university legacy systems (e.g., student information systems, payment gateways) are required in the initial phase, unless explicitly clarified.
- The university will provide necessary access to relevant personnel and existing documentation for requirements gathering and testing.
- Security requirements will adhere to standard web application best practices and university IT policies.

## Related Phases
- P1: Discovery & Planning (3 weeks) - To define the project scope, gather detailed requirements, and establish the foundational technical architecture and database design.
- P2: Design (2 weeks) - To create intuitive and responsive user interface and experience designs for both student and administrator roles.
- P3: Development (8 weeks) - To implement the backend APIs, database, and frontend user interfaces for all core functionalities.
- P4: Testing & Quality Assurance (4 weeks) - To thoroughly test the system for functionality, performance, security, and usability, ensuring it meets all defined requirements.
- P5: Deployment & Launch (2 weeks) - To prepare the production environment, deploy the application, and make it available to end-users.
- P6: Post-Launch Support & Maintenance (Ongoing) - To provide ongoing support, monitor system performance, address issues, and plan for future enhancements.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A dedicated project team (Project Manager, Business Analyst, UI/UX Designer, Backend Developers, Frontend Developers, QA Engineer, DevOps Engineer) is available for the project duration.
- The project will utilize a standard web technology stack (e.g., modern JavaScript framework for frontend, Python/Node.js/Java for backend, PostgreSQL/MySQL for database).
- No complex integrations with existing university legacy systems (e.g., student information systems, payment gateways) are required in the initial phase, unless explicitly clarified.
- The university will provide necessary access to relevant personnel and existing documentation for requirements gathering and testing.
- Security requirements will adhere to standard web application best practices and university IT policies.
- Missing information regarding 'target users' could lead to incomplete user persona development and potentially misaligned UI/UX or feature prioritization.
- Missing information regarding 'timeline' prevents accurate scheduling and resource allocation, making 'estimated_duration' and 'estimated_effort' placeholders.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Database Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed Requirements Specification Document approved by stakeholders.
- List of core features prioritized.
- Comprehensive Use Case Document completed.

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### QA / Testing Engineer implementation prompt

**Target Role:** QA / Testing Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Create a practical test strategy for the project phases, risks, acceptance criteria, and release workflow.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5
- P6

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A dedicated project team (Project Manager, Business Analyst, UI/UX Designer, Backend Developers, Frontend Developers, QA Engineer, DevOps Engineer) is available for the project duration.
- The project will utilize a standard web technology stack (e.g., modern JavaScript framework for frontend, Python/Node.js/Java for backend, PostgreSQL/MySQL for database).
- No complex integrations with existing university legacy systems (e.g., student information systems, payment gateways) are required in the initial phase, unless explicitly clarified.
- The university will provide necessary access to relevant personnel and existing documentation for requirements gathering and testing.
- Security requirements will adhere to standard web application best practices and university IT policies.
- Missing information regarding 'target users' could lead to incomplete user persona development and potentially misaligned UI/UX or feature prioritization.
- Missing information regarding 'timeline' prevents accurate scheduling and resource allocation, making 'estimated_duration' and 'estimated_effort' placeholders.

**Acceptance Criteria:**
- The QA / Testing Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed Requirements Specification Document approved by stakeholders.
- List of core features prioritized.
- Comprehensive Use Case Document completed.

**Prompt:**
```text
You are a senior QA engineer responsible for validating the implementation against the plan.

## Project Context
Project name: University Course Registration System
Project description: Build a university course registration system to allow students to register for courses and administrators to manage courses, students, and registrations.
Domain: software
Project type: software application
Complexity: medium
Summary: A web-based system designed for universities to streamline course registration. It will provide functionalities for students to browse, select, and register for courses, view their schedules, and for administrators to manage course offerings, student data, and registration processes. The system will feature user authentication, a responsive user interface, and robust backend APIs for data management.

## Your Role
QA / Testing Engineer

## Goal
Create a practical test strategy for the project phases, risks, acceptance criteria, and release workflow.

## Technical Scope
Functional tests, regression tests, edge cases, acceptance criteria validation, risk-based testing, and defect reporting.

Relevant tasks:
- T1: Requirements Gathering & Analysis - Conduct workshops and interviews with stakeholders (students, faculty, administrators) to capture functional and non-functional requirements.
- T2: Use Case Definition & User Stories - Define key user roles (Student, Instructor, Administrator) and their interactions with the system, translating requirements into user stories.
- T3: Technical Architecture Design - Design the high-level system architecture, including technology stack, deployment strategy, and integration points (if any).
- T4: Database Schema Design - Design the logical and physical database schema, including entities for Users, Courses, Sections, Registrations, Instructors, etc.
- T5: Wireframing & User Flows - Create low-fidelity wireframes for key screens and define user interaction flows for core functionalities (e.g., course search, registration, admin management).
- T6: UI/UX Mockup Creation - Develop high-fidelity mockups and a consistent design system (colors, typography, components) based on approved wireframes.
- T7: Interactive Prototype Development - Build a clickable prototype to demonstrate core user journeys and gather early feedback on usability.
- T8: Backend API Development - Authentication & Authorization - Implement user registration, login, session management, and role-based access control APIs.
- T9: Backend API Development - Course Management - Develop CRUD APIs for managing courses, sections, and instructors.
- T10: Backend API Development - Student & Registration Management - Implement CRUD APIs for student profiles and course registration/deregistration processes.
- T11: Frontend Development - Student Dashboard & Course Catalog - Build the responsive user interface for students to browse courses, view details, register, and manage their schedule.
- T12: Frontend Development - Admin Dashboard & Management - Develop the responsive user interface for administrators to manage courses, students, instructors, and registrations.
- T13: Database Implementation & Seeding - Set up the database instance, apply the schema, and populate with initial test data.
- T14: Unit & Integration Testing - Execute unit tests for individual code components and integration tests for interactions between modules and APIs.
- T15: End-to-End Testing - Perform comprehensive end-to-end testing of all major user workflows from both student and administrator perspectives.
- T16: Security Testing - Conduct security vulnerability assessments (e.g., OWASP Top 10) and penetration testing.
- T17: User Acceptance Testing (UAT) - Engage key stakeholders (e.g., university staff, pilot students) to perform UAT and gather final feedback.
- T18: Infrastructure Setup & Configuration - Provision and configure production servers, database, networking, and other necessary infrastructure components.
- T19: CI/CD Pipeline Setup - Configure Continuous Integration/Continuous Deployment pipelines for automated builds, tests, and deployments to production.
- T20: Production Deployment - Deploy the final, tested application to the production environment.
- T21: Post-Deployment Verification & Monitoring Setup - Perform sanity checks on the live system and configure monitoring and alerting tools.
- T22: Bug Fixing & Incident Management - Address reported bugs and incidents, providing timely resolutions and updates.
- T23: Performance Monitoring & Optimization - Continuously monitor system performance, identify bottlenecks, and implement optimizations.
- T24: Feature Enhancements & Updates - Plan and implement minor feature enhancements and system updates based on user feedback and evolving requirements.

Risks to account for:
- Scope creep due to evolving requirements from multiple university stakeholders (students, faculty, administration).
- Performance issues under high load during peak registration periods.
- Security vulnerabilities leading to unauthorized access or data breaches.
- Lack of clarity on specific university policies or integration requirements (e.g., existing student information systems, payment gateways).

Recommendations to preserve:
- Define a Minimum Viable Product (MVP) for the initial launch to deliver core value quickly and iterate based on user feedback.
- Establish a dedicated project steering committee with representatives from key university departments (e.g., Registrar's Office, IT, Student Affairs) to ensure alignment and timely decision-making.
- Consider using a modern, scalable cloud-based infrastructure and development framework to support potential growth and ensure high availability.

Assumptions to keep visible:
- A dedicated project team (Project Manager, Business Analyst, UI/UX Designer, Backend Developers, Frontend Developers, QA Engineer, DevOps Engineer) is available for the project duration.
- The project will utilize a standard web technology stack (e.g., modern JavaScript framework for frontend, Python/Node.js/Java for backend, PostgreSQL/MySQL for database).
- No complex integrations with existing university legacy systems (e.g., student information systems, payment gateways) are required in the initial phase, unless explicitly clarified.
- The university will provide necessary access to relevant personnel and existing documentation for requirements gathering and testing.
- Security requirements will adhere to standard web application best practices and university IT policies.

## Related Phases
- P1: Discovery & Planning (3 weeks) - To define the project scope, gather detailed requirements, and establish the foundational technical architecture and database design.
- P2: Design (2 weeks) - To create intuitive and responsive user interface and experience designs for both student and administrator roles.
- P3: Development (8 weeks) - To implement the backend APIs, database, and frontend user interfaces for all core functionalities.
- P4: Testing & Quality Assurance (4 weeks) - To thoroughly test the system for functionality, performance, security, and usability, ensuring it meets all defined requirements.
- P5: Deployment & Launch (2 weeks) - To prepare the production environment, deploy the application, and make it available to end-users.
- P6: Post-Launch Support & Maintenance (Ongoing) - To provide ongoing support, monitor system performance, address issues, and plan for future enhancements.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A dedicated project team (Project Manager, Business Analyst, UI/UX Designer, Backend Developers, Frontend Developers, QA Engineer, DevOps Engineer) is available for the project duration.
- The project will utilize a standard web technology stack (e.g., modern JavaScript framework for frontend, Python/Node.js/Java for backend, PostgreSQL/MySQL for database).
- No complex integrations with existing university legacy systems (e.g., student information systems, payment gateways) are required in the initial phase, unless explicitly clarified.
- The university will provide necessary access to relevant personnel and existing documentation for requirements gathering and testing.
- Security requirements will adhere to standard web application best practices and university IT policies.
- Missing information regarding 'target users' could lead to incomplete user persona development and potentially misaligned UI/UX or feature prioritization.
- Missing information regarding 'timeline' prevents accurate scheduling and resource allocation, making 'estimated_duration' and 'estimated_effort' placeholders.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The QA / Testing Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed Requirements Specification Document approved by stakeholders.
- List of core features prioritized.
- Comprehensive Use Case Document completed.

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### DevOps Engineer implementation prompt

**Target Role:** DevOps Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Plan environment, build, release, monitoring, and rollback work without deploying anything automatically.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5
- P6

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A dedicated project team (Project Manager, Business Analyst, UI/UX Designer, Backend Developers, Frontend Developers, QA Engineer, DevOps Engineer) is available for the project duration.
- The project will utilize a standard web technology stack (e.g., modern JavaScript framework for frontend, Python/Node.js/Java for backend, PostgreSQL/MySQL for database).
- No complex integrations with existing university legacy systems (e.g., student information systems, payment gateways) are required in the initial phase, unless explicitly clarified.
- The university will provide necessary access to relevant personnel and existing documentation for requirements gathering and testing.
- Security requirements will adhere to standard web application best practices and university IT policies.
- Missing information regarding 'target users' could lead to incomplete user persona development and potentially misaligned UI/UX or feature prioritization.
- Missing information regarding 'timeline' prevents accurate scheduling and resource allocation, making 'estimated_duration' and 'estimated_effort' placeholders.

**Acceptance Criteria:**
- The DevOps Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed Requirements Specification Document approved by stakeholders.
- List of core features prioritized.
- Comprehensive Use Case Document completed.

**Prompt:**
```text
You are a senior DevOps engineer responsible for deployment readiness and operational workflow.

## Project Context
Project name: University Course Registration System
Project description: Build a university course registration system to allow students to register for courses and administrators to manage courses, students, and registrations.
Domain: software
Project type: software application
Complexity: medium
Summary: A web-based system designed for universities to streamline course registration. It will provide functionalities for students to browse, select, and register for courses, view their schedules, and for administrators to manage course offerings, student data, and registration processes. The system will feature user authentication, a responsive user interface, and robust backend APIs for data management.

## Your Role
DevOps Engineer

## Goal
Plan environment, build, release, monitoring, and rollback work without deploying anything automatically.

## Technical Scope
Local development setup, CI checks, configuration, deployment plan, observability, release checklist, and rollback notes.

Relevant tasks:
- T1: Requirements Gathering & Analysis - Conduct workshops and interviews with stakeholders (students, faculty, administrators) to capture functional and non-functional requirements.
- T2: Use Case Definition & User Stories - Define key user roles (Student, Instructor, Administrator) and their interactions with the system, translating requirements into user stories.
- T3: Technical Architecture Design - Design the high-level system architecture, including technology stack, deployment strategy, and integration points (if any).
- T4: Database Schema Design - Design the logical and physical database schema, including entities for Users, Courses, Sections, Registrations, Instructors, etc.
- T5: Wireframing & User Flows - Create low-fidelity wireframes for key screens and define user interaction flows for core functionalities (e.g., course search, registration, admin management).
- T6: UI/UX Mockup Creation - Develop high-fidelity mockups and a consistent design system (colors, typography, components) based on approved wireframes.
- T7: Interactive Prototype Development - Build a clickable prototype to demonstrate core user journeys and gather early feedback on usability.
- T8: Backend API Development - Authentication & Authorization - Implement user registration, login, session management, and role-based access control APIs.
- T9: Backend API Development - Course Management - Develop CRUD APIs for managing courses, sections, and instructors.
- T10: Backend API Development - Student & Registration Management - Implement CRUD APIs for student profiles and course registration/deregistration processes.
- T11: Frontend Development - Student Dashboard & Course Catalog - Build the responsive user interface for students to browse courses, view details, register, and manage their schedule.
- T12: Frontend Development - Admin Dashboard & Management - Develop the responsive user interface for administrators to manage courses, students, instructors, and registrations.
- T13: Database Implementation & Seeding - Set up the database instance, apply the schema, and populate with initial test data.
- T14: Unit & Integration Testing - Execute unit tests for individual code components and integration tests for interactions between modules and APIs.
- T15: End-to-End Testing - Perform comprehensive end-to-end testing of all major user workflows from both student and administrator perspectives.
- T16: Security Testing - Conduct security vulnerability assessments (e.g., OWASP Top 10) and penetration testing.
- T17: User Acceptance Testing (UAT) - Engage key stakeholders (e.g., university staff, pilot students) to perform UAT and gather final feedback.
- T18: Infrastructure Setup & Configuration - Provision and configure production servers, database, networking, and other necessary infrastructure components.
- T19: CI/CD Pipeline Setup - Configure Continuous Integration/Continuous Deployment pipelines for automated builds, tests, and deployments to production.
- T20: Production Deployment - Deploy the final, tested application to the production environment.
- T21: Post-Deployment Verification & Monitoring Setup - Perform sanity checks on the live system and configure monitoring and alerting tools.
- T22: Bug Fixing & Incident Management - Address reported bugs and incidents, providing timely resolutions and updates.
- T23: Performance Monitoring & Optimization - Continuously monitor system performance, identify bottlenecks, and implement optimizations.
- T24: Feature Enhancements & Updates - Plan and implement minor feature enhancements and system updates based on user feedback and evolving requirements.

Risks to account for:
- Scope creep due to evolving requirements from multiple university stakeholders (students, faculty, administration).
- Performance issues under high load during peak registration periods.
- Security vulnerabilities leading to unauthorized access or data breaches.
- Lack of clarity on specific university policies or integration requirements (e.g., existing student information systems, payment gateways).

Recommendations to preserve:
- Define a Minimum Viable Product (MVP) for the initial launch to deliver core value quickly and iterate based on user feedback.
- Establish a dedicated project steering committee with representatives from key university departments (e.g., Registrar's Office, IT, Student Affairs) to ensure alignment and timely decision-making.
- Consider using a modern, scalable cloud-based infrastructure and development framework to support potential growth and ensure high availability.

Assumptions to keep visible:
- A dedicated project team (Project Manager, Business Analyst, UI/UX Designer, Backend Developers, Frontend Developers, QA Engineer, DevOps Engineer) is available for the project duration.
- The project will utilize a standard web technology stack (e.g., modern JavaScript framework for frontend, Python/Node.js/Java for backend, PostgreSQL/MySQL for database).
- No complex integrations with existing university legacy systems (e.g., student information systems, payment gateways) are required in the initial phase, unless explicitly clarified.
- The university will provide necessary access to relevant personnel and existing documentation for requirements gathering and testing.
- Security requirements will adhere to standard web application best practices and university IT policies.

## Related Phases
- P1: Discovery & Planning (3 weeks) - To define the project scope, gather detailed requirements, and establish the foundational technical architecture and database design.
- P2: Design (2 weeks) - To create intuitive and responsive user interface and experience designs for both student and administrator roles.
- P3: Development (8 weeks) - To implement the backend APIs, database, and frontend user interfaces for all core functionalities.
- P4: Testing & Quality Assurance (4 weeks) - To thoroughly test the system for functionality, performance, security, and usability, ensuring it meets all defined requirements.
- P5: Deployment & Launch (2 weeks) - To prepare the production environment, deploy the application, and make it available to end-users.
- P6: Post-Launch Support & Maintenance (Ongoing) - To provide ongoing support, monitor system performance, address issues, and plan for future enhancements.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A dedicated project team (Project Manager, Business Analyst, UI/UX Designer, Backend Developers, Frontend Developers, QA Engineer, DevOps Engineer) is available for the project duration.
- The project will utilize a standard web technology stack (e.g., modern JavaScript framework for frontend, Python/Node.js/Java for backend, PostgreSQL/MySQL for database).
- No complex integrations with existing university legacy systems (e.g., student information systems, payment gateways) are required in the initial phase, unless explicitly clarified.
- The university will provide necessary access to relevant personnel and existing documentation for requirements gathering and testing.
- Security requirements will adhere to standard web application best practices and university IT policies.
- Missing information regarding 'target users' could lead to incomplete user persona development and potentially misaligned UI/UX or feature prioritization.
- Missing information regarding 'timeline' prevents accurate scheduling and resource allocation, making 'estimated_duration' and 'estimated_effort' placeholders.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The DevOps Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed Requirements Specification Document approved by stakeholders.
- List of core features prioritized.
- Comprehensive Use Case Document completed.

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### Security Reviewer implementation prompt

**Target Role:** Security Reviewer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Review implementation plans for security, privacy, access control, data handling, and compliance risks.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5
- P6

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A dedicated project team (Project Manager, Business Analyst, UI/UX Designer, Backend Developers, Frontend Developers, QA Engineer, DevOps Engineer) is available for the project duration.
- The project will utilize a standard web technology stack (e.g., modern JavaScript framework for frontend, Python/Node.js/Java for backend, PostgreSQL/MySQL for database).
- No complex integrations with existing university legacy systems (e.g., student information systems, payment gateways) are required in the initial phase, unless explicitly clarified.
- The university will provide necessary access to relevant personnel and existing documentation for requirements gathering and testing.
- Security requirements will adhere to standard web application best practices and university IT policies.
- Missing information regarding 'target users' could lead to incomplete user persona development and potentially misaligned UI/UX or feature prioritization.
- Missing information regarding 'timeline' prevents accurate scheduling and resource allocation, making 'estimated_duration' and 'estimated_effort' placeholders.

**Acceptance Criteria:**
- The Security Reviewer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed Requirements Specification Document approved by stakeholders.
- List of core features prioritized.
- Comprehensive Use Case Document completed.

**Prompt:**
```text
You are a senior security engineer responsible for reviewing the plan for security and privacy risks.

## Project Context
Project name: University Course Registration System
Project description: Build a university course registration system to allow students to register for courses and administrators to manage courses, students, and registrations.
Domain: software
Project type: software application
Complexity: medium
Summary: A web-based system designed for universities to streamline course registration. It will provide functionalities for students to browse, select, and register for courses, view their schedules, and for administrators to manage course offerings, student data, and registration processes. The system will feature user authentication, a responsive user interface, and robust backend APIs for data management.

## Your Role
Security Reviewer

## Goal
Review implementation plans for security, privacy, access control, data handling, and compliance risks.

## Technical Scope
Threat modeling, authentication and authorization concerns, sensitive data handling, dependency risk, and secure defaults.

Relevant tasks:
- T1: Requirements Gathering & Analysis - Conduct workshops and interviews with stakeholders (students, faculty, administrators) to capture functional and non-functional requirements.
- T2: Use Case Definition & User Stories - Define key user roles (Student, Instructor, Administrator) and their interactions with the system, translating requirements into user stories.
- T3: Technical Architecture Design - Design the high-level system architecture, including technology stack, deployment strategy, and integration points (if any).
- T4: Database Schema Design - Design the logical and physical database schema, including entities for Users, Courses, Sections, Registrations, Instructors, etc.
- T5: Wireframing & User Flows - Create low-fidelity wireframes for key screens and define user interaction flows for core functionalities (e.g., course search, registration, admin management).
- T6: UI/UX Mockup Creation - Develop high-fidelity mockups and a consistent design system (colors, typography, components) based on approved wireframes.
- T7: Interactive Prototype Development - Build a clickable prototype to demonstrate core user journeys and gather early feedback on usability.
- T8: Backend API Development - Authentication & Authorization - Implement user registration, login, session management, and role-based access control APIs.
- T9: Backend API Development - Course Management - Develop CRUD APIs for managing courses, sections, and instructors.
- T10: Backend API Development - Student & Registration Management - Implement CRUD APIs for student profiles and course registration/deregistration processes.
- T11: Frontend Development - Student Dashboard & Course Catalog - Build the responsive user interface for students to browse courses, view details, register, and manage their schedule.
- T12: Frontend Development - Admin Dashboard & Management - Develop the responsive user interface for administrators to manage courses, students, instructors, and registrations.
- T13: Database Implementation & Seeding - Set up the database instance, apply the schema, and populate with initial test data.
- T14: Unit & Integration Testing - Execute unit tests for individual code components and integration tests for interactions between modules and APIs.
- T15: End-to-End Testing - Perform comprehensive end-to-end testing of all major user workflows from both student and administrator perspectives.
- T16: Security Testing - Conduct security vulnerability assessments (e.g., OWASP Top 10) and penetration testing.
- T17: User Acceptance Testing (UAT) - Engage key stakeholders (e.g., university staff, pilot students) to perform UAT and gather final feedback.
- T18: Infrastructure Setup & Configuration - Provision and configure production servers, database, networking, and other necessary infrastructure components.
- T19: CI/CD Pipeline Setup - Configure Continuous Integration/Continuous Deployment pipelines for automated builds, tests, and deployments to production.
- T20: Production Deployment - Deploy the final, tested application to the production environment.
- T21: Post-Deployment Verification & Monitoring Setup - Perform sanity checks on the live system and configure monitoring and alerting tools.
- T22: Bug Fixing & Incident Management - Address reported bugs and incidents, providing timely resolutions and updates.
- T23: Performance Monitoring & Optimization - Continuously monitor system performance, identify bottlenecks, and implement optimizations.
- T24: Feature Enhancements & Updates - Plan and implement minor feature enhancements and system updates based on user feedback and evolving requirements.

Risks to account for:
- Scope creep due to evolving requirements from multiple university stakeholders (students, faculty, administration).
- Performance issues under high load during peak registration periods.
- Security vulnerabilities leading to unauthorized access or data breaches.
- Lack of clarity on specific university policies or integration requirements (e.g., existing student information systems, payment gateways).

Recommendations to preserve:
- Define a Minimum Viable Product (MVP) for the initial launch to deliver core value quickly and iterate based on user feedback.
- Establish a dedicated project steering committee with representatives from key university departments (e.g., Registrar's Office, IT, Student Affairs) to ensure alignment and timely decision-making.
- Consider using a modern, scalable cloud-based infrastructure and development framework to support potential growth and ensure high availability.

Assumptions to keep visible:
- A dedicated project team (Project Manager, Business Analyst, UI/UX Designer, Backend Developers, Frontend Developers, QA Engineer, DevOps Engineer) is available for the project duration.
- The project will utilize a standard web technology stack (e.g., modern JavaScript framework for frontend, Python/Node.js/Java for backend, PostgreSQL/MySQL for database).
- No complex integrations with existing university legacy systems (e.g., student information systems, payment gateways) are required in the initial phase, unless explicitly clarified.
- The university will provide necessary access to relevant personnel and existing documentation for requirements gathering and testing.
- Security requirements will adhere to standard web application best practices and university IT policies.

## Related Phases
- P1: Discovery & Planning (3 weeks) - To define the project scope, gather detailed requirements, and establish the foundational technical architecture and database design.
- P2: Design (2 weeks) - To create intuitive and responsive user interface and experience designs for both student and administrator roles.
- P3: Development (8 weeks) - To implement the backend APIs, database, and frontend user interfaces for all core functionalities.
- P4: Testing & Quality Assurance (4 weeks) - To thoroughly test the system for functionality, performance, security, and usability, ensuring it meets all defined requirements.
- P5: Deployment & Launch (2 weeks) - To prepare the production environment, deploy the application, and make it available to end-users.
- P6: Post-Launch Support & Maintenance (Ongoing) - To provide ongoing support, monitor system performance, address issues, and plan for future enhancements.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A dedicated project team (Project Manager, Business Analyst, UI/UX Designer, Backend Developers, Frontend Developers, QA Engineer, DevOps Engineer) is available for the project duration.
- The project will utilize a standard web technology stack (e.g., modern JavaScript framework for frontend, Python/Node.js/Java for backend, PostgreSQL/MySQL for database).
- No complex integrations with existing university legacy systems (e.g., student information systems, payment gateways) are required in the initial phase, unless explicitly clarified.
- The university will provide necessary access to relevant personnel and existing documentation for requirements gathering and testing.
- Security requirements will adhere to standard web application best practices and university IT policies.
- Missing information regarding 'target users' could lead to incomplete user persona development and potentially misaligned UI/UX or feature prioritization.
- Missing information regarding 'timeline' prevents accurate scheduling and resource allocation, making 'estimated_duration' and 'estimated_effort' placeholders.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Security Reviewer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Detailed Requirements Specification Document approved by stakeholders.
- List of core features prioritized.
- Comprehensive Use Case Document completed.

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

## Prompt Quality Evaluations
### Evaluation for EP1

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP2

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP3

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP4

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP5

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP6

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.
