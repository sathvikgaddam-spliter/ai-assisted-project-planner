# Frontend Specification

## Pages and Screens
- Landing or dashboard screen
- Authentication or onboarding screen
- responsive UI
- forms
- dashboard views
- navigation
- Settings or profile screen

## Components
- Authentication component
- Dashboard component
- Crud workflows component
- Notifications component
- Shared form controls
- Loading, empty, and error states

## User Flows
1. user onboarding
2. core feature usage
3. content or data management
4. reporting

## States
- loading
- empty
- validation error
- success
- permission denied
