# MVP Scope

## In Scope
- authentication
- dashboard
- CRUD workflows
- notifications

## Out of Scope
- Advanced enterprise administration unless explicitly requested.
- Production payment processing without a reviewed integration plan.
- Native mobile applications unless the detected type requires mobile delivery.
- Automated deployment without engineer review.

## MVP Success Criteria
- Users can complete user onboarding in a tested flow.
- Users can complete core feature usage in a tested flow.
- Users can complete content or data management in a tested flow.
- Users can complete reporting in a tested flow.
