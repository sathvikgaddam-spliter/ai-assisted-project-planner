# API Specification

## Authentication
Use authenticated routes for user-owned data and admin-only routes for administrative actions.

## Required API Capabilities
- CRUD APIs
- authentication APIs
- validation
- authorization

## User Endpoints

- `GET /api/users`: list users; supports pagination and filtering.
- `POST /api/users`: create a User; validates request body and ownership.
- `GET /api/users/{id}`: fetch one User; returns 404 when unavailable.
- `PATCH /api/users/{id}`: update a User; enforces authorization.
- `DELETE /api/users/{id}`: archive or delete a User; requires authorization.

## Account Endpoints

- `GET /api/accounts`: list accounts; supports pagination and filtering.
- `POST /api/accounts`: create a Account; validates request body and ownership.
- `GET /api/accounts/{id}`: fetch one Account; returns 404 when unavailable.
- `PATCH /api/accounts/{id}`: update a Account; enforces authorization.
- `DELETE /api/accounts/{id}`: archive or delete a Account; requires authorization.

## Item Endpoints

- `GET /api/items`: list items; supports pagination and filtering.
- `POST /api/items`: create a Item; validates request body and ownership.
- `GET /api/items/{id}`: fetch one Item; returns 404 when unavailable.
- `PATCH /api/items/{id}`: update a Item; enforces authorization.
- `DELETE /api/items/{id}`: archive or delete a Item; requires authorization.

## Activity Endpoints

- `GET /api/activitys`: list activitys; supports pagination and filtering.
- `POST /api/activitys`: create a Activity; validates request body and ownership.
- `GET /api/activitys/{id}`: fetch one Activity; returns 404 when unavailable.
- `PATCH /api/activitys/{id}`: update a Activity; enforces authorization.
- `DELETE /api/activitys/{id}`: archive or delete a Activity; requires authorization.

## Notification Endpoints

- `GET /api/notifications`: list notifications; supports pagination and filtering.
- `POST /api/notifications`: create a Notification; validates request body and ownership.
- `GET /api/notifications/{id}`: fetch one Notification; returns 404 when unavailable.
- `PATCH /api/notifications/{id}`: update a Notification; enforces authorization.
- `DELETE /api/notifications/{id}`: archive or delete a Notification; requires authorization.

## Request/Response Expectations
- Use JSON request bodies.
- Return validation errors with field-level messages.
- Return consistent success envelopes for created and updated records.
