# Reddit-Style Backend Platform Development

## Summary
This project aims to build a scalable backend system for a Reddit-style platform, focusing on core features like user management, content submission, interaction (voting, comments), and community organization. The plan outlines phases from discovery to deployment, highlighting key tasks, deliverables, and potential risks.

- Domain: software
- Project type: software application
- Complexity: medium
- Status: plan_generated

## Warnings
- Missing information: target users. This may impact feature prioritization and design decisions.
- Missing information: timeline. Project durations and effort estimates are placeholders and require further definition.

## Phases
### P1: Discovery & Planning
Define detailed requirements, architecture, and technology stack for the backend platform.

Estimated duration: To be determined

Tasks:
- T1: Requirements Gathering - Gather and document functional and non-functional requirements for the backend, including user stories for core features.
- T2: Technology Stack Selection - Evaluate and select the appropriate programming languages, frameworks, databases, and cloud services for the backend. Dependencies: T1.
- T3: High-Level Architecture Design - Design the overall system architecture, including microservices/monolith approach, data flow, and external integrations. Dependencies: T2.
- T4: API Design Specification - Design the RESTful API endpoints, request/response formats, and authentication mechanisms. Dependencies: T1, T3.

Deliverables:
- Requirements Document
- Technology Stack Decision Document
- High-Level Architecture Diagram
- API Specification Document

### P2: Database Design & Setup
Design and implement the database schema and initial setup for the backend.

Estimated duration: To be determined

Tasks:
- T5: Database Schema Design - Design the relational or NoSQL database schema to support user data, posts, comments, votes, and communities. Dependencies: T1, T4.
- T6: Database Setup and Configuration - Provision and configure the chosen database instance(s) in the development environment. Dependencies: T5.
- T7: ORM/Database Access Layer Implementation - Implement the Object-Relational Mapping (ORM) or data access layer to interact with the database. Dependencies: T6.

Deliverables:
- Database Schema
- Configured Database Instance
- Data Access Layer Code

### P3: Core API Development
Implement the core backend functionalities as defined in the API specification.

Estimated duration: To be determined

Tasks:
- T8: User Authentication & Authorization Module - Develop endpoints for user registration, login, session management, and role-based access control. Dependencies: T7.
- T9: Post Management Module - Implement API endpoints for creating, reading, updating, and deleting posts, including content storage and retrieval. Dependencies: T7.
- T10: Commenting System Module - Develop functionalities for users to add, view, edit, and delete comments on posts, including nested comments. Dependencies: T7, T9.
- T11: Voting System Module - Implement upvote/downvote functionality for posts and comments, including vote counting and user vote tracking. Dependencies: T7, T9, T10.
- T12: Sub-community/Subreddit Management Module - Develop APIs for creating, joining, and managing sub-communities, including post submission to specific communities. Dependencies: T7.

Deliverables:
- Functional API Endpoints for User Management
- Functional API Endpoints for Post Management
- Functional API Endpoints for Commenting
- Functional API Endpoints for Voting
- Functional API Endpoints for Community Management

### P4: Testing & Quality Assurance
Ensure the backend is robust, secure, and performs as expected through comprehensive testing.

Estimated duration: To be determined

Tasks:
- T13: Unit Testing - Write and execute unit tests for all individual components and functions of the backend. Dependencies: T8, T9, T10, T11, T12.
- T14: Integration Testing - Perform integration tests to verify that different modules and external services interact correctly. Dependencies: T13.
- T15: Performance Testing - Conduct load and stress tests to evaluate the backend's performance under various user loads. Dependencies: T14.
- T16: Security Testing - Perform security audits and penetration testing to identify and mitigate vulnerabilities. Dependencies: T14.

Deliverables:
- Unit Test Reports
- Integration Test Reports
- Performance Test Results
- Security Audit Report
- Resolved Bug List

### P5: Deployment & Monitoring Setup
Prepare the backend for production deployment and establish monitoring and logging systems.

Estimated duration: To be determined

Tasks:
- T17: Deployment Infrastructure Setup - Set up the production environment, including servers, load balancers, CI/CD pipelines, and containerization (if applicable). Dependencies: T16.
- T18: Initial Deployment - Deploy the backend application to the production environment. Dependencies: T17.
- T19: Monitoring & Logging Setup - Configure monitoring tools, alerts, and centralized logging for the deployed backend. Dependencies: T18.

Deliverables:
- Deployed Backend Service
- CI/CD Pipeline
- Monitoring Dashboards
- Logging System

## Milestones
- M1: Requirements & Architecture Approved (P1)
- M2: Database Schema Finalized (P2)
- M3: Core API Functionality Complete (P3)
- M4: Backend System Tested & Stable (P4)
- M5: Production Deployment Ready (P5)

## Risks
- R1: Scope creep due to evolving requirements or desire for additional 'Reddit-like' features not initially defined. Mitigation: Establish a clear scope document with defined core features. Implement a strict change request process for any new features. Prioritize features based on MVP (Minimum Viable Product) goals.
- R2: Performance issues under high user load, especially with complex queries for feeds, comments, and voting. Mitigation: Conduct regular performance testing throughout development. Optimize database queries and API endpoints. Implement caching strategies and consider scalable database solutions from the outset.
- R3: Security vulnerabilities in user authentication, data handling, or API endpoints. Mitigation: Follow security best practices (e.g., OWASP Top 10). Conduct regular code reviews and security audits. Use established and well-vetted authentication libraries/frameworks. Implement input validation and output encoding.
- R4: Scalability challenges as the user base grows, leading to increased infrastructure costs or degraded user experience. Mitigation: Design for scalability from the beginning (e.g., microservices, stateless APIs). Utilize cloud-native services that offer auto-scaling. Implement robust monitoring to identify bottlenecks early and plan for horizontal scaling.
- R5: Integration challenges with a separately developed frontend application. Mitigation: Maintain a clear and well-documented API specification. Conduct regular sync-ups between backend and frontend teams. Use tools like Postman/Swagger UI for API testing and documentation sharing.

## Recommendations
- Project Definition: Conduct detailed user research and persona development.
- Methodology: Adopt an Agile development methodology (e.g., Scrum or Kanban).
- Timeline & Resources: Define a clear project timeline and allocate dedicated resources.
- Technology: Consider using a robust cloud platform (e.g., AWS, Azure, GCP) for hosting and managed services.

## Assumptions
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.

## Engineering Prompt Pack
### Frontend Engineer implementation prompt

**Target Role:** Frontend Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Implement the frontend experience for the planned project while preserving the validated project scope.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.
- Missing information: target users. This may impact feature prioritization and design decisions.
- Missing information: timeline. Project durations and effort estimates are placeholders and require further definition.

**Acceptance Criteria:**
- The Frontend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Comprehensive requirements document approved
- Key user stories defined
- Technology stack decision documented with rationale

**Prompt:**
```text
You are a senior frontend engineer responsible for implementing the user-facing experience.

## Project Context
Project name: Reddit-Style Backend Platform Development
Project description: Develop a robust and scalable backend platform mimicking core functionalities of Reddit, including user authentication, post creation, commenting, voting, and sub-community management.
Domain: software
Project type: software application
Complexity: medium
Summary: This project aims to build a scalable backend system for a Reddit-style platform, focusing on core features like user management, content submission, interaction (voting, comments), and community organization. The plan outlines phases from discovery to deployment, highlighting key tasks, deliverables, and potential risks.

## Your Role
Frontend Engineer

## Goal
Implement the frontend experience for the planned project while preserving the validated project scope.

## Technical Scope
UI workflows, client-side validation, accessibility, responsive behavior, and integration points with backend APIs.

Relevant tasks:
- T1: Requirements Gathering - Gather and document functional and non-functional requirements for the backend, including user stories for core features.
- T2: Technology Stack Selection - Evaluate and select the appropriate programming languages, frameworks, databases, and cloud services for the backend.
- T3: High-Level Architecture Design - Design the overall system architecture, including microservices/monolith approach, data flow, and external integrations.
- T4: API Design Specification - Design the RESTful API endpoints, request/response formats, and authentication mechanisms.
- T5: Database Schema Design - Design the relational or NoSQL database schema to support user data, posts, comments, votes, and communities.
- T6: Database Setup and Configuration - Provision and configure the chosen database instance(s) in the development environment.
- T7: ORM/Database Access Layer Implementation - Implement the Object-Relational Mapping (ORM) or data access layer to interact with the database.
- T8: User Authentication & Authorization Module - Develop endpoints for user registration, login, session management, and role-based access control.
- T9: Post Management Module - Implement API endpoints for creating, reading, updating, and deleting posts, including content storage and retrieval.
- T10: Commenting System Module - Develop functionalities for users to add, view, edit, and delete comments on posts, including nested comments.
- T11: Voting System Module - Implement upvote/downvote functionality for posts and comments, including vote counting and user vote tracking.
- T12: Sub-community/Subreddit Management Module - Develop APIs for creating, joining, and managing sub-communities, including post submission to specific communities.
- T13: Unit Testing - Write and execute unit tests for all individual components and functions of the backend.
- T14: Integration Testing - Perform integration tests to verify that different modules and external services interact correctly.
- T15: Performance Testing - Conduct load and stress tests to evaluate the backend's performance under various user loads.
- T16: Security Testing - Perform security audits and penetration testing to identify and mitigate vulnerabilities.
- T17: Deployment Infrastructure Setup - Set up the production environment, including servers, load balancers, CI/CD pipelines, and containerization (if applicable).
- T18: Initial Deployment - Deploy the backend application to the production environment.
- T19: Monitoring & Logging Setup - Configure monitoring tools, alerts, and centralized logging for the deployed backend.

Risks to account for:
- Scope creep due to evolving requirements or desire for additional 'Reddit-like' features not initially defined.
- Performance issues under high user load, especially with complex queries for feeds, comments, and voting.
- Security vulnerabilities in user authentication, data handling, or API endpoints.
- Scalability challenges as the user base grows, leading to increased infrastructure costs or degraded user experience.
- Integration challenges with a separately developed frontend application.

Recommendations to preserve:
- Conduct detailed user research and persona development.
- Adopt an Agile development methodology (e.g., Scrum or Kanban).
- Define a clear project timeline and allocate dedicated resources.
- Consider using a robust cloud platform (e.g., AWS, Azure, GCP) for hosting and managed services.

Assumptions to keep visible:
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.

## Related Phases
- P1: Discovery & Planning (To be determined) - Define detailed requirements, architecture, and technology stack for the backend platform.
- P2: Database Design & Setup (To be determined) - Design and implement the database schema and initial setup for the backend.
- P3: Core API Development (To be determined) - Implement the core backend functionalities as defined in the API specification.
- P4: Testing & Quality Assurance (To be determined) - Ensure the backend is robust, secure, and performs as expected through comprehensive testing.
- P5: Deployment & Monitoring Setup (To be determined) - Prepare the backend for production deployment and establish monitoring and logging systems.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.
- Missing information: target users. This may impact feature prioritization and design decisions.
- Missing information: timeline. Project durations and effort estimates are placeholders and require further definition.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Frontend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Comprehensive requirements document approved
- Key user stories defined
- Technology stack decision documented with rationale

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### Backend Engineer implementation prompt

**Target Role:** Backend Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Implement backend services that support the planned workflows, validation rules, and task sequencing.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.
- Missing information: target users. This may impact feature prioritization and design decisions.
- Missing information: timeline. Project durations and effort estimates are placeholders and require further definition.

**Acceptance Criteria:**
- The Backend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Comprehensive requirements document approved
- Key user stories defined
- Technology stack decision documented with rationale

**Prompt:**
```text
You are a senior backend engineer responsible for building the application services and API layer.

## Project Context
Project name: Reddit-Style Backend Platform Development
Project description: Develop a robust and scalable backend platform mimicking core functionalities of Reddit, including user authentication, post creation, commenting, voting, and sub-community management.
Domain: software
Project type: software application
Complexity: medium
Summary: This project aims to build a scalable backend system for a Reddit-style platform, focusing on core features like user management, content submission, interaction (voting, comments), and community organization. The plan outlines phases from discovery to deployment, highlighting key tasks, deliverables, and potential risks.

## Your Role
Backend Engineer

## Goal
Implement backend services that support the planned workflows, validation rules, and task sequencing.

## Technical Scope
API contracts, service logic, validation, error handling, integrations, and backend test coverage.

Relevant tasks:
- T1: Requirements Gathering - Gather and document functional and non-functional requirements for the backend, including user stories for core features.
- T2: Technology Stack Selection - Evaluate and select the appropriate programming languages, frameworks, databases, and cloud services for the backend.
- T3: High-Level Architecture Design - Design the overall system architecture, including microservices/monolith approach, data flow, and external integrations.
- T4: API Design Specification - Design the RESTful API endpoints, request/response formats, and authentication mechanisms.
- T5: Database Schema Design - Design the relational or NoSQL database schema to support user data, posts, comments, votes, and communities.
- T6: Database Setup and Configuration - Provision and configure the chosen database instance(s) in the development environment.
- T7: ORM/Database Access Layer Implementation - Implement the Object-Relational Mapping (ORM) or data access layer to interact with the database.
- T8: User Authentication & Authorization Module - Develop endpoints for user registration, login, session management, and role-based access control.
- T9: Post Management Module - Implement API endpoints for creating, reading, updating, and deleting posts, including content storage and retrieval.
- T10: Commenting System Module - Develop functionalities for users to add, view, edit, and delete comments on posts, including nested comments.
- T11: Voting System Module - Implement upvote/downvote functionality for posts and comments, including vote counting and user vote tracking.
- T12: Sub-community/Subreddit Management Module - Develop APIs for creating, joining, and managing sub-communities, including post submission to specific communities.
- T13: Unit Testing - Write and execute unit tests for all individual components and functions of the backend.
- T14: Integration Testing - Perform integration tests to verify that different modules and external services interact correctly.
- T15: Performance Testing - Conduct load and stress tests to evaluate the backend's performance under various user loads.
- T16: Security Testing - Perform security audits and penetration testing to identify and mitigate vulnerabilities.
- T17: Deployment Infrastructure Setup - Set up the production environment, including servers, load balancers, CI/CD pipelines, and containerization (if applicable).
- T18: Initial Deployment - Deploy the backend application to the production environment.
- T19: Monitoring & Logging Setup - Configure monitoring tools, alerts, and centralized logging for the deployed backend.

Risks to account for:
- Scope creep due to evolving requirements or desire for additional 'Reddit-like' features not initially defined.
- Performance issues under high user load, especially with complex queries for feeds, comments, and voting.
- Security vulnerabilities in user authentication, data handling, or API endpoints.
- Scalability challenges as the user base grows, leading to increased infrastructure costs or degraded user experience.
- Integration challenges with a separately developed frontend application.

Recommendations to preserve:
- Conduct detailed user research and persona development.
- Adopt an Agile development methodology (e.g., Scrum or Kanban).
- Define a clear project timeline and allocate dedicated resources.
- Consider using a robust cloud platform (e.g., AWS, Azure, GCP) for hosting and managed services.

Assumptions to keep visible:
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.

## Related Phases
- P1: Discovery & Planning (To be determined) - Define detailed requirements, architecture, and technology stack for the backend platform.
- P2: Database Design & Setup (To be determined) - Design and implement the database schema and initial setup for the backend.
- P3: Core API Development (To be determined) - Implement the core backend functionalities as defined in the API specification.
- P4: Testing & Quality Assurance (To be determined) - Ensure the backend is robust, secure, and performs as expected through comprehensive testing.
- P5: Deployment & Monitoring Setup (To be determined) - Prepare the backend for production deployment and establish monitoring and logging systems.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.
- Missing information: target users. This may impact feature prioritization and design decisions.
- Missing information: timeline. Project durations and effort estimates are placeholders and require further definition.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Backend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Comprehensive requirements document approved
- Key user stories defined
- Technology stack decision documented with rationale

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### Database Engineer implementation prompt

**Target Role:** Database Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Define storage structures that support the project requirements without inventing unsupported data sources.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.
- Missing information: target users. This may impact feature prioritization and design decisions.
- Missing information: timeline. Project durations and effort estimates are placeholders and require further definition.

**Acceptance Criteria:**
- The Database Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Comprehensive requirements document approved
- Key user stories defined
- Technology stack decision documented with rationale

**Prompt:**
```text
You are a senior database engineer responsible for designing the data model and persistence approach.

## Project Context
Project name: Reddit-Style Backend Platform Development
Project description: Develop a robust and scalable backend platform mimicking core functionalities of Reddit, including user authentication, post creation, commenting, voting, and sub-community management.
Domain: software
Project type: software application
Complexity: medium
Summary: This project aims to build a scalable backend system for a Reddit-style platform, focusing on core features like user management, content submission, interaction (voting, comments), and community organization. The plan outlines phases from discovery to deployment, highlighting key tasks, deliverables, and potential risks.

## Your Role
Database Engineer

## Goal
Define storage structures that support the project requirements without inventing unsupported data sources.

## Technical Scope
Entities, relationships, indexes, migrations, data quality checks, retention needs, and backup assumptions.

Relevant tasks:
- T1: Requirements Gathering - Gather and document functional and non-functional requirements for the backend, including user stories for core features.
- T2: Technology Stack Selection - Evaluate and select the appropriate programming languages, frameworks, databases, and cloud services for the backend.
- T3: High-Level Architecture Design - Design the overall system architecture, including microservices/monolith approach, data flow, and external integrations.
- T4: API Design Specification - Design the RESTful API endpoints, request/response formats, and authentication mechanisms.
- T5: Database Schema Design - Design the relational or NoSQL database schema to support user data, posts, comments, votes, and communities.
- T6: Database Setup and Configuration - Provision and configure the chosen database instance(s) in the development environment.
- T7: ORM/Database Access Layer Implementation - Implement the Object-Relational Mapping (ORM) or data access layer to interact with the database.
- T8: User Authentication & Authorization Module - Develop endpoints for user registration, login, session management, and role-based access control.
- T9: Post Management Module - Implement API endpoints for creating, reading, updating, and deleting posts, including content storage and retrieval.
- T10: Commenting System Module - Develop functionalities for users to add, view, edit, and delete comments on posts, including nested comments.
- T11: Voting System Module - Implement upvote/downvote functionality for posts and comments, including vote counting and user vote tracking.
- T12: Sub-community/Subreddit Management Module - Develop APIs for creating, joining, and managing sub-communities, including post submission to specific communities.
- T13: Unit Testing - Write and execute unit tests for all individual components and functions of the backend.
- T14: Integration Testing - Perform integration tests to verify that different modules and external services interact correctly.
- T15: Performance Testing - Conduct load and stress tests to evaluate the backend's performance under various user loads.
- T16: Security Testing - Perform security audits and penetration testing to identify and mitigate vulnerabilities.
- T17: Deployment Infrastructure Setup - Set up the production environment, including servers, load balancers, CI/CD pipelines, and containerization (if applicable).
- T18: Initial Deployment - Deploy the backend application to the production environment.
- T19: Monitoring & Logging Setup - Configure monitoring tools, alerts, and centralized logging for the deployed backend.

Risks to account for:
- Scope creep due to evolving requirements or desire for additional 'Reddit-like' features not initially defined.
- Performance issues under high user load, especially with complex queries for feeds, comments, and voting.
- Security vulnerabilities in user authentication, data handling, or API endpoints.
- Scalability challenges as the user base grows, leading to increased infrastructure costs or degraded user experience.
- Integration challenges with a separately developed frontend application.

Recommendations to preserve:
- Conduct detailed user research and persona development.
- Adopt an Agile development methodology (e.g., Scrum or Kanban).
- Define a clear project timeline and allocate dedicated resources.
- Consider using a robust cloud platform (e.g., AWS, Azure, GCP) for hosting and managed services.

Assumptions to keep visible:
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.

## Related Phases
- P1: Discovery & Planning (To be determined) - Define detailed requirements, architecture, and technology stack for the backend platform.
- P2: Database Design & Setup (To be determined) - Design and implement the database schema and initial setup for the backend.
- P3: Core API Development (To be determined) - Implement the core backend functionalities as defined in the API specification.
- P4: Testing & Quality Assurance (To be determined) - Ensure the backend is robust, secure, and performs as expected through comprehensive testing.
- P5: Deployment & Monitoring Setup (To be determined) - Prepare the backend for production deployment and establish monitoring and logging systems.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.
- Missing information: target users. This may impact feature prioritization and design decisions.
- Missing information: timeline. Project durations and effort estimates are placeholders and require further definition.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Database Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Comprehensive requirements document approved
- Key user stories defined
- Technology stack decision documented with rationale

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### QA / Testing Engineer implementation prompt

**Target Role:** QA / Testing Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Create a practical test strategy for the project phases, risks, acceptance criteria, and release workflow.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.
- Missing information: target users. This may impact feature prioritization and design decisions.
- Missing information: timeline. Project durations and effort estimates are placeholders and require further definition.

**Acceptance Criteria:**
- The QA / Testing Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Comprehensive requirements document approved
- Key user stories defined
- Technology stack decision documented with rationale

**Prompt:**
```text
You are a senior QA engineer responsible for validating the implementation against the plan.

## Project Context
Project name: Reddit-Style Backend Platform Development
Project description: Develop a robust and scalable backend platform mimicking core functionalities of Reddit, including user authentication, post creation, commenting, voting, and sub-community management.
Domain: software
Project type: software application
Complexity: medium
Summary: This project aims to build a scalable backend system for a Reddit-style platform, focusing on core features like user management, content submission, interaction (voting, comments), and community organization. The plan outlines phases from discovery to deployment, highlighting key tasks, deliverables, and potential risks.

## Your Role
QA / Testing Engineer

## Goal
Create a practical test strategy for the project phases, risks, acceptance criteria, and release workflow.

## Technical Scope
Functional tests, regression tests, edge cases, acceptance criteria validation, risk-based testing, and defect reporting.

Relevant tasks:
- T1: Requirements Gathering - Gather and document functional and non-functional requirements for the backend, including user stories for core features.
- T2: Technology Stack Selection - Evaluate and select the appropriate programming languages, frameworks, databases, and cloud services for the backend.
- T3: High-Level Architecture Design - Design the overall system architecture, including microservices/monolith approach, data flow, and external integrations.
- T4: API Design Specification - Design the RESTful API endpoints, request/response formats, and authentication mechanisms.
- T5: Database Schema Design - Design the relational or NoSQL database schema to support user data, posts, comments, votes, and communities.
- T6: Database Setup and Configuration - Provision and configure the chosen database instance(s) in the development environment.
- T7: ORM/Database Access Layer Implementation - Implement the Object-Relational Mapping (ORM) or data access layer to interact with the database.
- T8: User Authentication & Authorization Module - Develop endpoints for user registration, login, session management, and role-based access control.
- T9: Post Management Module - Implement API endpoints for creating, reading, updating, and deleting posts, including content storage and retrieval.
- T10: Commenting System Module - Develop functionalities for users to add, view, edit, and delete comments on posts, including nested comments.
- T11: Voting System Module - Implement upvote/downvote functionality for posts and comments, including vote counting and user vote tracking.
- T12: Sub-community/Subreddit Management Module - Develop APIs for creating, joining, and managing sub-communities, including post submission to specific communities.
- T13: Unit Testing - Write and execute unit tests for all individual components and functions of the backend.
- T14: Integration Testing - Perform integration tests to verify that different modules and external services interact correctly.
- T15: Performance Testing - Conduct load and stress tests to evaluate the backend's performance under various user loads.
- T16: Security Testing - Perform security audits and penetration testing to identify and mitigate vulnerabilities.
- T17: Deployment Infrastructure Setup - Set up the production environment, including servers, load balancers, CI/CD pipelines, and containerization (if applicable).
- T18: Initial Deployment - Deploy the backend application to the production environment.
- T19: Monitoring & Logging Setup - Configure monitoring tools, alerts, and centralized logging for the deployed backend.

Risks to account for:
- Scope creep due to evolving requirements or desire for additional 'Reddit-like' features not initially defined.
- Performance issues under high user load, especially with complex queries for feeds, comments, and voting.
- Security vulnerabilities in user authentication, data handling, or API endpoints.
- Scalability challenges as the user base grows, leading to increased infrastructure costs or degraded user experience.
- Integration challenges with a separately developed frontend application.

Recommendations to preserve:
- Conduct detailed user research and persona development.
- Adopt an Agile development methodology (e.g., Scrum or Kanban).
- Define a clear project timeline and allocate dedicated resources.
- Consider using a robust cloud platform (e.g., AWS, Azure, GCP) for hosting and managed services.

Assumptions to keep visible:
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.

## Related Phases
- P1: Discovery & Planning (To be determined) - Define detailed requirements, architecture, and technology stack for the backend platform.
- P2: Database Design & Setup (To be determined) - Design and implement the database schema and initial setup for the backend.
- P3: Core API Development (To be determined) - Implement the core backend functionalities as defined in the API specification.
- P4: Testing & Quality Assurance (To be determined) - Ensure the backend is robust, secure, and performs as expected through comprehensive testing.
- P5: Deployment & Monitoring Setup (To be determined) - Prepare the backend for production deployment and establish monitoring and logging systems.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.
- Missing information: target users. This may impact feature prioritization and design decisions.
- Missing information: timeline. Project durations and effort estimates are placeholders and require further definition.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The QA / Testing Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Comprehensive requirements document approved
- Key user stories defined
- Technology stack decision documented with rationale

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### DevOps Engineer implementation prompt

**Target Role:** DevOps Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Plan environment, build, release, monitoring, and rollback work without deploying anything automatically.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.
- Missing information: target users. This may impact feature prioritization and design decisions.
- Missing information: timeline. Project durations and effort estimates are placeholders and require further definition.

**Acceptance Criteria:**
- The DevOps Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Comprehensive requirements document approved
- Key user stories defined
- Technology stack decision documented with rationale

**Prompt:**
```text
You are a senior DevOps engineer responsible for deployment readiness and operational workflow.

## Project Context
Project name: Reddit-Style Backend Platform Development
Project description: Develop a robust and scalable backend platform mimicking core functionalities of Reddit, including user authentication, post creation, commenting, voting, and sub-community management.
Domain: software
Project type: software application
Complexity: medium
Summary: This project aims to build a scalable backend system for a Reddit-style platform, focusing on core features like user management, content submission, interaction (voting, comments), and community organization. The plan outlines phases from discovery to deployment, highlighting key tasks, deliverables, and potential risks.

## Your Role
DevOps Engineer

## Goal
Plan environment, build, release, monitoring, and rollback work without deploying anything automatically.

## Technical Scope
Local development setup, CI checks, configuration, deployment plan, observability, release checklist, and rollback notes.

Relevant tasks:
- T1: Requirements Gathering - Gather and document functional and non-functional requirements for the backend, including user stories for core features.
- T2: Technology Stack Selection - Evaluate and select the appropriate programming languages, frameworks, databases, and cloud services for the backend.
- T3: High-Level Architecture Design - Design the overall system architecture, including microservices/monolith approach, data flow, and external integrations.
- T4: API Design Specification - Design the RESTful API endpoints, request/response formats, and authentication mechanisms.
- T5: Database Schema Design - Design the relational or NoSQL database schema to support user data, posts, comments, votes, and communities.
- T6: Database Setup and Configuration - Provision and configure the chosen database instance(s) in the development environment.
- T7: ORM/Database Access Layer Implementation - Implement the Object-Relational Mapping (ORM) or data access layer to interact with the database.
- T8: User Authentication & Authorization Module - Develop endpoints for user registration, login, session management, and role-based access control.
- T9: Post Management Module - Implement API endpoints for creating, reading, updating, and deleting posts, including content storage and retrieval.
- T10: Commenting System Module - Develop functionalities for users to add, view, edit, and delete comments on posts, including nested comments.
- T11: Voting System Module - Implement upvote/downvote functionality for posts and comments, including vote counting and user vote tracking.
- T12: Sub-community/Subreddit Management Module - Develop APIs for creating, joining, and managing sub-communities, including post submission to specific communities.
- T13: Unit Testing - Write and execute unit tests for all individual components and functions of the backend.
- T14: Integration Testing - Perform integration tests to verify that different modules and external services interact correctly.
- T15: Performance Testing - Conduct load and stress tests to evaluate the backend's performance under various user loads.
- T16: Security Testing - Perform security audits and penetration testing to identify and mitigate vulnerabilities.
- T17: Deployment Infrastructure Setup - Set up the production environment, including servers, load balancers, CI/CD pipelines, and containerization (if applicable).
- T18: Initial Deployment - Deploy the backend application to the production environment.
- T19: Monitoring & Logging Setup - Configure monitoring tools, alerts, and centralized logging for the deployed backend.

Risks to account for:
- Scope creep due to evolving requirements or desire for additional 'Reddit-like' features not initially defined.
- Performance issues under high user load, especially with complex queries for feeds, comments, and voting.
- Security vulnerabilities in user authentication, data handling, or API endpoints.
- Scalability challenges as the user base grows, leading to increased infrastructure costs or degraded user experience.
- Integration challenges with a separately developed frontend application.

Recommendations to preserve:
- Conduct detailed user research and persona development.
- Adopt an Agile development methodology (e.g., Scrum or Kanban).
- Define a clear project timeline and allocate dedicated resources.
- Consider using a robust cloud platform (e.g., AWS, Azure, GCP) for hosting and managed services.

Assumptions to keep visible:
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.

## Related Phases
- P1: Discovery & Planning (To be determined) - Define detailed requirements, architecture, and technology stack for the backend platform.
- P2: Database Design & Setup (To be determined) - Design and implement the database schema and initial setup for the backend.
- P3: Core API Development (To be determined) - Implement the core backend functionalities as defined in the API specification.
- P4: Testing & Quality Assurance (To be determined) - Ensure the backend is robust, secure, and performs as expected through comprehensive testing.
- P5: Deployment & Monitoring Setup (To be determined) - Prepare the backend for production deployment and establish monitoring and logging systems.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.
- Missing information: target users. This may impact feature prioritization and design decisions.
- Missing information: timeline. Project durations and effort estimates are placeholders and require further definition.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The DevOps Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Comprehensive requirements document approved
- Key user stories defined
- Technology stack decision documented with rationale

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### Security Reviewer implementation prompt

**Target Role:** Security Reviewer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Review implementation plans for security, privacy, access control, data handling, and compliance risks.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.
- Missing information: target users. This may impact feature prioritization and design decisions.
- Missing information: timeline. Project durations and effort estimates are placeholders and require further definition.

**Acceptance Criteria:**
- The Security Reviewer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Comprehensive requirements document approved
- Key user stories defined
- Technology stack decision documented with rationale

**Prompt:**
```text
You are a senior security engineer responsible for reviewing the plan for security and privacy risks.

## Project Context
Project name: Reddit-Style Backend Platform Development
Project description: Develop a robust and scalable backend platform mimicking core functionalities of Reddit, including user authentication, post creation, commenting, voting, and sub-community management.
Domain: software
Project type: software application
Complexity: medium
Summary: This project aims to build a scalable backend system for a Reddit-style platform, focusing on core features like user management, content submission, interaction (voting, comments), and community organization. The plan outlines phases from discovery to deployment, highlighting key tasks, deliverables, and potential risks.

## Your Role
Security Reviewer

## Goal
Review implementation plans for security, privacy, access control, data handling, and compliance risks.

## Technical Scope
Threat modeling, authentication and authorization concerns, sensitive data handling, dependency risk, and secure defaults.

Relevant tasks:
- T1: Requirements Gathering - Gather and document functional and non-functional requirements for the backend, including user stories for core features.
- T2: Technology Stack Selection - Evaluate and select the appropriate programming languages, frameworks, databases, and cloud services for the backend.
- T3: High-Level Architecture Design - Design the overall system architecture, including microservices/monolith approach, data flow, and external integrations.
- T4: API Design Specification - Design the RESTful API endpoints, request/response formats, and authentication mechanisms.
- T5: Database Schema Design - Design the relational or NoSQL database schema to support user data, posts, comments, votes, and communities.
- T6: Database Setup and Configuration - Provision and configure the chosen database instance(s) in the development environment.
- T7: ORM/Database Access Layer Implementation - Implement the Object-Relational Mapping (ORM) or data access layer to interact with the database.
- T8: User Authentication & Authorization Module - Develop endpoints for user registration, login, session management, and role-based access control.
- T9: Post Management Module - Implement API endpoints for creating, reading, updating, and deleting posts, including content storage and retrieval.
- T10: Commenting System Module - Develop functionalities for users to add, view, edit, and delete comments on posts, including nested comments.
- T11: Voting System Module - Implement upvote/downvote functionality for posts and comments, including vote counting and user vote tracking.
- T12: Sub-community/Subreddit Management Module - Develop APIs for creating, joining, and managing sub-communities, including post submission to specific communities.
- T13: Unit Testing - Write and execute unit tests for all individual components and functions of the backend.
- T14: Integration Testing - Perform integration tests to verify that different modules and external services interact correctly.
- T15: Performance Testing - Conduct load and stress tests to evaluate the backend's performance under various user loads.
- T16: Security Testing - Perform security audits and penetration testing to identify and mitigate vulnerabilities.
- T17: Deployment Infrastructure Setup - Set up the production environment, including servers, load balancers, CI/CD pipelines, and containerization (if applicable).
- T18: Initial Deployment - Deploy the backend application to the production environment.
- T19: Monitoring & Logging Setup - Configure monitoring tools, alerts, and centralized logging for the deployed backend.

Risks to account for:
- Scope creep due to evolving requirements or desire for additional 'Reddit-like' features not initially defined.
- Performance issues under high user load, especially with complex queries for feeds, comments, and voting.
- Security vulnerabilities in user authentication, data handling, or API endpoints.
- Scalability challenges as the user base grows, leading to increased infrastructure costs or degraded user experience.
- Integration challenges with a separately developed frontend application.

Recommendations to preserve:
- Conduct detailed user research and persona development.
- Adopt an Agile development methodology (e.g., Scrum or Kanban).
- Define a clear project timeline and allocate dedicated resources.
- Consider using a robust cloud platform (e.g., AWS, Azure, GCP) for hosting and managed services.

Assumptions to keep visible:
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.

## Related Phases
- P1: Discovery & Planning (To be determined) - Define detailed requirements, architecture, and technology stack for the backend platform.
- P2: Database Design & Setup (To be determined) - Design and implement the database schema and initial setup for the backend.
- P3: Core API Development (To be determined) - Implement the core backend functionalities as defined in the API specification.
- P4: Testing & Quality Assurance (To be determined) - Ensure the backend is robust, secure, and performs as expected through comprehensive testing.
- P5: Deployment & Monitoring Setup (To be determined) - Prepare the backend for production deployment and establish monitoring and logging systems.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.
- Missing information: target users. This may impact feature prioritization and design decisions.
- Missing information: timeline. Project durations and effort estimates are placeholders and require further definition.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Security Reviewer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Comprehensive requirements document approved
- Key user stories defined
- Technology stack decision documented with rationale

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

## Prompt Quality Evaluations
### Evaluation for EP1

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP2

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP3

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP4

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP5

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP6

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.
