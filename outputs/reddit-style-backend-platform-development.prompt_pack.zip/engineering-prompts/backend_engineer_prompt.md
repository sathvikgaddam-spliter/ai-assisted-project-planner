# Backend Engineer implementation prompt

**Target Role:** Backend Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Implement backend services that support the planned workflows, validation rules, and task sequencing.

## Related Phases
- P1
- P2
- P3
- P4
- P5

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.
- Missing information: target users. This may impact feature prioritization and design decisions.
- Missing information: timeline. Project durations and effort estimates are placeholders and require further definition.

## Acceptance Criteria
- The Backend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Comprehensive requirements document approved
- Key user stories defined
- Technology stack decision documented with rationale

## Prompt
```text
You are a senior backend engineer responsible for building the application services and API layer.

## Project Context
Project name: Reddit-Style Backend Platform Development
Project description: Develop a robust and scalable backend platform mimicking core functionalities of Reddit, including user authentication, post creation, commenting, voting, and sub-community management.
Domain: software
Project type: software application
Complexity: medium
Summary: This project aims to build a scalable backend system for a Reddit-style platform, focusing on core features like user management, content submission, interaction (voting, comments), and community organization. The plan outlines phases from discovery to deployment, highlighting key tasks, deliverables, and potential risks.

## Your Role
Backend Engineer

## Goal
Implement backend services that support the planned workflows, validation rules, and task sequencing.

## Technical Scope
API contracts, service logic, validation, error handling, integrations, and backend test coverage.

Relevant tasks:
- T1: Requirements Gathering - Gather and document functional and non-functional requirements for the backend, including user stories for core features.
- T2: Technology Stack Selection - Evaluate and select the appropriate programming languages, frameworks, databases, and cloud services for the backend.
- T3: High-Level Architecture Design - Design the overall system architecture, including microservices/monolith approach, data flow, and external integrations.
- T4: API Design Specification - Design the RESTful API endpoints, request/response formats, and authentication mechanisms.
- T5: Database Schema Design - Design the relational or NoSQL database schema to support user data, posts, comments, votes, and communities.
- T6: Database Setup and Configuration - Provision and configure the chosen database instance(s) in the development environment.
- T7: ORM/Database Access Layer Implementation - Implement the Object-Relational Mapping (ORM) or data access layer to interact with the database.
- T8: User Authentication & Authorization Module - Develop endpoints for user registration, login, session management, and role-based access control.
- T9: Post Management Module - Implement API endpoints for creating, reading, updating, and deleting posts, including content storage and retrieval.
- T10: Commenting System Module - Develop functionalities for users to add, view, edit, and delete comments on posts, including nested comments.
- T11: Voting System Module - Implement upvote/downvote functionality for posts and comments, including vote counting and user vote tracking.
- T12: Sub-community/Subreddit Management Module - Develop APIs for creating, joining, and managing sub-communities, including post submission to specific communities.
- T13: Unit Testing - Write and execute unit tests for all individual components and functions of the backend.
- T14: Integration Testing - Perform integration tests to verify that different modules and external services interact correctly.
- T15: Performance Testing - Conduct load and stress tests to evaluate the backend's performance under various user loads.
- T16: Security Testing - Perform security audits and penetration testing to identify and mitigate vulnerabilities.
- T17: Deployment Infrastructure Setup - Set up the production environment, including servers, load balancers, CI/CD pipelines, and containerization (if applicable).
- T18: Initial Deployment - Deploy the backend application to the production environment.
- T19: Monitoring & Logging Setup - Configure monitoring tools, alerts, and centralized logging for the deployed backend.

Risks to account for:
- Scope creep due to evolving requirements or desire for additional 'Reddit-like' features not initially defined.
- Performance issues under high user load, especially with complex queries for feeds, comments, and voting.
- Security vulnerabilities in user authentication, data handling, or API endpoints.
- Scalability challenges as the user base grows, leading to increased infrastructure costs or degraded user experience.
- Integration challenges with a separately developed frontend application.

Recommendations to preserve:
- Conduct detailed user research and persona development.
- Adopt an Agile development methodology (e.g., Scrum or Kanban).
- Define a clear project timeline and allocate dedicated resources.
- Consider using a robust cloud platform (e.g., AWS, Azure, GCP) for hosting and managed services.

Assumptions to keep visible:
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.

## Related Phases
- P1: Discovery & Planning (To be determined) - Define detailed requirements, architecture, and technology stack for the backend platform.
- P2: Database Design & Setup (To be determined) - Design and implement the database schema and initial setup for the backend.
- P3: Core API Development (To be determined) - Implement the core backend functionalities as defined in the API specification.
- P4: Testing & Quality Assurance (To be determined) - Ensure the backend is robust, secure, and performs as expected through comprehensive testing.
- P5: Deployment & Monitoring Setup (To be determined) - Prepare the backend for production deployment and establish monitoring and logging systems.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- A frontend application will be developed separately and will consume the APIs provided by this backend.
- The project will have access to a skilled development team with expertise in the chosen technology stack.
- Necessary infrastructure (cloud accounts, development tools) will be provisioned as needed.
- The 'reddit style' implies core features like posts, comments, voting, and sub-communities, but not advanced features like live chat, rich media embedding, or complex moderation tools unless explicitly defined.
- The project will adhere to standard software development lifecycle practices, including version control and code reviews.
- Missing information: target users. This may impact feature prioritization and design decisions.
- Missing information: timeline. Project durations and effort estimates are placeholders and require further definition.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Backend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Comprehensive requirements document approved
- Key user stories defined
- Technology stack decision documented with rationale

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```
