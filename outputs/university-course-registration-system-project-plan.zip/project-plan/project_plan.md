# University Course Registration System

## Summary
A comprehensive project plan for developing a university course registration system, covering phases from requirements gathering to post-launch support. The system will include user authentication, course browsing, student registration, administrative course management, and notification features, built as a generic web application with responsive UI and robust backend APIs.

- Domain: software
- Project type: software application
- Complexity: medium
- Status: plan_generated

## Warnings
- A specific project timeline has not been provided and will need to be defined and agreed upon during the Planning & Requirements Gathering phase (P1). The estimated durations provided are indicative and subject to refinement.
- Detailed budget information is not available and will need to be established.

## Phases
### P1: Planning & Requirements Gathering
Define the project scope, gather detailed functional and non-functional requirements, and establish the initial technical architecture and project plan.

Estimated duration: 3 weeks

Tasks:
- T1.1: Stakeholder Interviews & Needs Analysis - Conduct interviews with students, faculty, and university administrators to understand their needs, pain points, and desired functionalities for the course registration system.
- T1.2: Functional Requirements Specification - Document detailed functional requirements including user onboarding, course browsing, registration workflows (add/drop), schedule viewing, course management, student management, and notification triggers. Dependencies: T1.1.
- T1.3: Non-Functional Requirements Specification - Define non-functional requirements such as performance (e.g., concurrent users during registration), security, scalability, usability, and accessibility. Dependencies: T1.1.
- T1.4: Technology Stack Selection & Initial Architecture - Evaluate and select appropriate technologies for frontend, backend, database, and deployment. Outline the high-level system architecture. Dependencies: T1.2, T1.3.
- T1.5: Project Plan Finalization - Refine the project timeline, resource allocation, and detailed task breakdown based on gathered requirements and architectural decisions. Dependencies: T1.4.

Deliverables:
- Requirements Document (FRD & NFRD)
- Initial Data Model Sketch
- Technology Stack Decision
- High-Level System Architecture
- Detailed Project Plan

### P2: Design
Translate approved requirements into detailed technical designs, including database schema, API specifications, and user interface/experience designs.

Estimated duration: 4 weeks

Tasks:
- T2.1: Database Schema Design - Design the relational database schema for entities like User (Student, Faculty, Admin), Course, Section, Registration, Department, Semester, Prerequisite, and Notification. Dependencies: T1.2.
- T2.2: Backend API Design - Design RESTful APIs for authentication, user management, course CRUD, registration CRUD, schedule retrieval, and notification management, including request/response formats and error handling. Dependencies: T1.2, T2.1.
- T2.3: UI/UX Design & Prototyping - Create wireframes, mockups, and interactive prototypes for key user interfaces, including student dashboard, course catalog, registration forms, admin panels, and notification views, ensuring responsive design. Dependencies: T1.2.
- T2.4: Security Design - Develop a comprehensive security design covering authentication, authorization (role-based access control), data encryption, input validation, and protection against common web vulnerabilities. Dependencies: T1.3, T2.2.

Deliverables:
- Detailed Database Schema (ERD & DDL)
- API Specification Document
- UI/UX Wireframes & Mockups
- Interactive Prototypes
- Security Design Document

### P3: Development
Implement the backend APIs and frontend user interfaces based on the approved designs, integrating the various system components.

Estimated duration: 10 weeks

Tasks:
- T3.1: Backend Core Services Development (Authentication & User Management) - Implement authentication APIs (login, registration, password reset) and user management APIs (CRUD for Student, Faculty, Admin accounts) with role-based authorization. Dependencies: T2.2, T2.4.
- T3.2: Backend Course & Registration Management Development - Implement CRUD APIs for Courses, Sections, and Registration. Include logic for prerequisites, capacity checks, waitlists, and academic calendar constraints. Dependencies: T2.2, T2.1.
- T3.3: Backend Notification & Reporting Development - Implement APIs for generating and managing notifications (e.g., registration confirmation, waitlist updates) and basic reporting (e.g., course rosters, enrollment statistics). Dependencies: T2.2.
- T3.4: Frontend User Onboarding & Dashboard Development - Develop the frontend for user registration, login, and the student/admin dashboards, displaying relevant information and navigation. Dependencies: T2.3, T3.1.
- T3.5: Frontend Course Catalog & Registration Workflow Development - Develop the frontend for browsing courses, viewing course details, adding/dropping courses, and managing student schedules. Dependencies: T2.3, T3.2.
- T3.6: Frontend Admin & Faculty Management Panels Development - Develop the frontend interfaces for administrators to manage courses, students, and faculty, and for faculty to manage their assigned courses. Dependencies: T2.3, T3.2.
- T3.7: System Integration - Integrate the frontend and backend components, ensuring seamless communication and data flow between them. Dependencies: T3.1, T3.2, T3.3, T3.4, T3.5, T3.6.

Deliverables:
- Functional Backend APIs
- Functional Frontend UI
- Integrated System Modules
- Developer Documentation

### P4: Testing & Quality Assurance
Rigorously test the system to identify and resolve defects, ensure it meets all requirements, and prepare for user acceptance testing.

Estimated duration: 4 weeks

Tasks:
- T4.1: Unit Testing - Develop and execute unit tests for individual backend functions and frontend components to ensure they work as expected. Dependencies: T3.7.
- T4.2: Integration Testing - Develop and execute integration tests to verify the interaction between different modules and services (e.g., frontend-backend communication, database interactions). Dependencies: T3.7, T4.1.
- T4.3: End-to-End (E2E) Testing - Develop and execute E2E tests simulating real user workflows (e.g., student registers for a course, admin creates a new course) to ensure the entire system functions correctly. Dependencies: T3.7, T4.2.
- T4.4: Performance Testing - Conduct load and stress testing to ensure the system can handle expected user concurrency and data volumes, especially during peak registration periods. Dependencies: T3.7, T1.3.
- T4.5: Security Testing - Perform vulnerability scanning, penetration testing, and security audits to identify and mitigate potential security flaws. Dependencies: T3.7, T2.4.
- T4.6: User Acceptance Testing (UAT) - Facilitate UAT with a group of actual students, faculty, and administrators to validate the system against their real-world needs and gather feedback. Dependencies: T4.3, T4.4, T4.5.
- T4.7: Bug Fixing & Regression Testing - Address all identified bugs and issues from various testing phases and perform regression testing to ensure fixes do not introduce new problems. Dependencies: T4.1, T4.2, T4.3, T4.4, T4.5, T4.6.

Deliverables:
- Test Plans & Test Cases
- Test Reports (Unit, Integration, E2E, Performance, Security)
- Bug Tracking Log
- UAT Feedback & Sign-off

### P5: Deployment & Launch
Deploy the fully tested system to the production environment and make it available to university users.

Estimated duration: 2 weeks

Tasks:
- T5.1: Infrastructure Setup & Configuration - Set up and configure production servers, databases, networking, and security components in the chosen cloud environment. Dependencies: T1.4, T4.7.
- T5.2: Deployment Pipeline Setup - Establish a continuous integration/continuous deployment (CI/CD) pipeline for automated and reliable deployments. Dependencies: T5.1.
- T5.3: Data Migration (if applicable) - Migrate existing student, faculty, and course data from legacy systems into the new database, if required. Dependencies: T2.1, T4.7.
- T5.4: Go-Live & System Monitoring - Execute the final deployment to production, make the system publicly accessible, and initiate intensive monitoring. Dependencies: T5.2, T5.3.

Deliverables:
- Deployed Production Environment
- Operational System
- Monitoring Dashboards
- Deployment Runbook

### P6: Post-Launch Support & Iteration
Provide ongoing support, monitor system performance, address issues, and plan for future enhancements based on user feedback.

Estimated duration: Ongoing

Tasks:
- T6.1: System Monitoring & Incident Response - Continuously monitor system health, performance, and security. Respond to and resolve any incidents or outages promptly. Dependencies: T5.4.
- T6.2: Bug Fixes & Minor Enhancements - Address any post-launch bugs and implement minor enhancements or adjustments based on immediate user feedback. Dependencies: T6.1.
- T6.3: User Feedback Collection & Analysis - Establish channels for collecting user feedback (e.g., support tickets, surveys) and regularly analyze it to identify areas for improvement. Dependencies: T5.4.
- T6.4: Backlog Grooming & Future Planning - Regularly review the product backlog, prioritize new features and improvements based on feedback and strategic goals for future iterations (e.g., V2). Dependencies: T6.3.

Deliverables:
- Monitoring Reports
- Bug Fix Releases
- User Feedback Reports
- Updated Product Backlog & Roadmap

## Milestones
- M1: Requirements Approved (P1)
- M2: Design Approved (P2)
- M3: Core Features Developed (P3)
- M4: System Tested & Ready for UAT (P4)
- M5: Production Launch (P5)

## Risks
- R1: Scope creep due to evolving stakeholder requirements, leading to project delays and budget overruns. Mitigation: Implement strict change control processes, clearly define scope in P1, and prioritize features for MVP vs. future iterations.
- R2: Performance issues during peak registration periods (e.g., system slowdowns, crashes) due to high concurrent user load. Mitigation: Conduct thorough performance testing (T4.4), optimize database queries, implement caching, and ensure scalable infrastructure design (P2, P5).
- R3: Security vulnerabilities leading to data breaches or unauthorized access to student/course information. Mitigation: Implement robust security design (T2.4), conduct regular security testing (T4.5), follow secure coding practices, and perform security audits.
- R4: Lack of clear or conflicting requirements from different university departments/stakeholders. Mitigation: Facilitate structured requirements gathering (T1.1, T1.2), ensure all key stakeholders are involved and sign off on requirements, and use a dedicated Business Analyst.
- R5: Integration challenges with existing university systems (e.g., student information system, payment gateway) if required in future iterations. Mitigation: Design APIs with extensibility in mind (T2.2), conduct early research into potential integration points, and plan for phased integration if necessary.

## Recommendations
- Methodology: Adopt an Agile development methodology (e.g., Scrum or Kanban) to allow for iterative development, continuous feedback, and flexibility in adapting to evolving requirements.
- Technology: Utilize a modern, cloud-native technology stack for scalability, reliability, and ease of maintenance.
- Quality Assurance: Implement a comprehensive automated testing strategy covering unit, integration, and end-to-end tests from the early stages of development.
- User Experience: Prioritize a user-centric design approach with continuous feedback loops from students, faculty, and administrators.

## Assumptions
- The primary target users are university students, faculty members, and administrative staff.
- The system will be deployed to a cloud-based infrastructure (e.g., AWS, Azure, GCP).
- Availability of subject matter experts (SMEs) from the university for requirements clarification and UAT.
- The project will initially focus on core course registration functionalities, with advanced features (e.g., payment integration, complex reporting) considered for future phases.
- The university has existing academic calendar data that can be used or integrated.

## Engineering Prompt Pack
### Frontend Engineer implementation prompt

**Target Role:** Frontend Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Implement the frontend experience for the planned project while preserving the validated project scope.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5
- P6

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The primary target users are university students, faculty members, and administrative staff.
- The system will be deployed to a cloud-based infrastructure (e.g., AWS, Azure, GCP).
- Availability of subject matter experts (SMEs) from the university for requirements clarification and UAT.
- The project will initially focus on core course registration functionalities, with advanced features (e.g., payment integration, complex reporting) considered for future phases.
- The university has existing academic calendar data that can be used or integrated.
- A specific project timeline has not been provided and will need to be defined and agreed upon during the Planning & Requirements Gathering phase (P1). The estimated durations provided are indicative and subject to refinement.
- Detailed budget information is not available and will need to be established.

**Acceptance Criteria:**
- The Frontend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Interview notes compiled and summarized
- Initial user stories drafted for key roles (Student, Faculty, Administrator)
- Detailed Functional Requirements Document (FRD) approved by stakeholders

**Prompt:**
```text
You are a senior frontend engineer responsible for implementing the user-facing experience.

## Project Context
Project name: University Course Registration System
Project description: Build a web-based application to enable university students to register for courses, view their schedules, and manage their enrollments. The system will also allow university administrators and faculty to manage courses, student information, and registration processes.
Domain: software
Project type: software application
Complexity: medium
Summary: A comprehensive project plan for developing a university course registration system, covering phases from requirements gathering to post-launch support. The system will include user authentication, course browsing, student registration, administrative course management, and notification features, built as a generic web application with responsive UI and robust backend APIs.

## Your Role
Frontend Engineer

## Goal
Implement the frontend experience for the planned project while preserving the validated project scope.

## Technical Scope
UI workflows, client-side validation, accessibility, responsive behavior, and integration points with backend APIs.

Relevant tasks:
- T1.1: Stakeholder Interviews & Needs Analysis - Conduct interviews with students, faculty, and university administrators to understand their needs, pain points, and desired functionalities for the course registration system.
- T1.2: Functional Requirements Specification - Document detailed functional requirements including user onboarding, course browsing, registration workflows (add/drop), schedule viewing, course management, student management, and notification triggers.
- T1.3: Non-Functional Requirements Specification - Define non-functional requirements such as performance (e.g., concurrent users during registration), security, scalability, usability, and accessibility.
- T1.4: Technology Stack Selection & Initial Architecture - Evaluate and select appropriate technologies for frontend, backend, database, and deployment. Outline the high-level system architecture.
- T1.5: Project Plan Finalization - Refine the project timeline, resource allocation, and detailed task breakdown based on gathered requirements and architectural decisions.
- T2.1: Database Schema Design - Design the relational database schema for entities like User (Student, Faculty, Admin), Course, Section, Registration, Department, Semester, Prerequisite, and Notification.
- T2.2: Backend API Design - Design RESTful APIs for authentication, user management, course CRUD, registration CRUD, schedule retrieval, and notification management, including request/response formats and error handling.
- T2.3: UI/UX Design & Prototyping - Create wireframes, mockups, and interactive prototypes for key user interfaces, including student dashboard, course catalog, registration forms, admin panels, and notification views, ensuring responsive design.
- T2.4: Security Design - Develop a comprehensive security design covering authentication, authorization (role-based access control), data encryption, input validation, and protection against common web vulnerabilities.
- T3.1: Backend Core Services Development (Authentication & User Management) - Implement authentication APIs (login, registration, password reset) and user management APIs (CRUD for Student, Faculty, Admin accounts) with role-based authorization.
- T3.2: Backend Course & Registration Management Development - Implement CRUD APIs for Courses, Sections, and Registration. Include logic for prerequisites, capacity checks, waitlists, and academic calendar constraints.
- T3.3: Backend Notification & Reporting Development - Implement APIs for generating and managing notifications (e.g., registration confirmation, waitlist updates) and basic reporting (e.g., course rosters, enrollment statistics).
- T3.4: Frontend User Onboarding & Dashboard Development - Develop the frontend for user registration, login, and the student/admin dashboards, displaying relevant information and navigation.
- T3.5: Frontend Course Catalog & Registration Workflow Development - Develop the frontend for browsing courses, viewing course details, adding/dropping courses, and managing student schedules.
- T3.6: Frontend Admin & Faculty Management Panels Development - Develop the frontend interfaces for administrators to manage courses, students, and faculty, and for faculty to manage their assigned courses.
- T3.7: System Integration - Integrate the frontend and backend components, ensuring seamless communication and data flow between them.
- T4.1: Unit Testing - Develop and execute unit tests for individual backend functions and frontend components to ensure they work as expected.
- T4.2: Integration Testing - Develop and execute integration tests to verify the interaction between different modules and services (e.g., frontend-backend communication, database interactions).
- T4.3: End-to-End (E2E) Testing - Develop and execute E2E tests simulating real user workflows (e.g., student registers for a course, admin creates a new course) to ensure the entire system functions correctly.
- T4.4: Performance Testing - Conduct load and stress testing to ensure the system can handle expected user concurrency and data volumes, especially during peak registration periods.
- T4.5: Security Testing - Perform vulnerability scanning, penetration testing, and security audits to identify and mitigate potential security flaws.
- T4.6: User Acceptance Testing (UAT) - Facilitate UAT with a group of actual students, faculty, and administrators to validate the system against their real-world needs and gather feedback.
- T4.7: Bug Fixing & Regression Testing - Address all identified bugs and issues from various testing phases and perform regression testing to ensure fixes do not introduce new problems.
- T5.1: Infrastructure Setup & Configuration - Set up and configure production servers, databases, networking, and security components in the chosen cloud environment.
- T5.2: Deployment Pipeline Setup - Establish a continuous integration/continuous deployment (CI/CD) pipeline for automated and reliable deployments.
- T5.3: Data Migration (if applicable) - Migrate existing student, faculty, and course data from legacy systems into the new database, if required.
- T5.4: Go-Live & System Monitoring - Execute the final deployment to production, make the system publicly accessible, and initiate intensive monitoring.
- T6.1: System Monitoring & Incident Response - Continuously monitor system health, performance, and security. Respond to and resolve any incidents or outages promptly.
- T6.2: Bug Fixes & Minor Enhancements - Address any post-launch bugs and implement minor enhancements or adjustments based on immediate user feedback.
- T6.3: User Feedback Collection & Analysis - Establish channels for collecting user feedback (e.g., support tickets, surveys) and regularly analyze it to identify areas for improvement.
- T6.4: Backlog Grooming & Future Planning - Regularly review the product backlog, prioritize new features and improvements based on feedback and strategic goals for future iterations (e.g., V2).

Risks to account for:
- Scope creep due to evolving stakeholder requirements, leading to project delays and budget overruns.
- Performance issues during peak registration periods (e.g., system slowdowns, crashes) due to high concurrent user load.
- Security vulnerabilities leading to data breaches or unauthorized access to student/course information.
- Lack of clear or conflicting requirements from different university departments/stakeholders.
- Integration challenges with existing university systems (e.g., student information system, payment gateway) if required in future iterations.

Recommendations to preserve:
- Adopt an Agile development methodology (e.g., Scrum or Kanban) to allow for iterative development, continuous feedback, and flexibility in adapting to evolving requirements.
- Utilize a modern, cloud-native technology stack for scalability, reliability, and ease of maintenance.
- Implement a comprehensive automated testing strategy covering unit, integration, and end-to-end tests from the early stages of development.
- Prioritize a user-centric design approach with continuous feedback loops from students, faculty, and administrators.

Assumptions to keep visible:
- The primary target users are university students, faculty members, and administrative staff.
- The system will be deployed to a cloud-based infrastructure (e.g., AWS, Azure, GCP).
- Availability of subject matter experts (SMEs) from the university for requirements clarification and UAT.
- The project will initially focus on core course registration functionalities, with advanced features (e.g., payment integration, complex reporting) considered for future phases.
- The university has existing academic calendar data that can be used or integrated.

## Related Phases
- P1: Planning & Requirements Gathering (3 weeks) - Define the project scope, gather detailed functional and non-functional requirements, and establish the initial technical architecture and project plan.
- P2: Design (4 weeks) - Translate approved requirements into detailed technical designs, including database schema, API specifications, and user interface/experience designs.
- P3: Development (10 weeks) - Implement the backend APIs and frontend user interfaces based on the approved designs, integrating the various system components.
- P4: Testing & Quality Assurance (4 weeks) - Rigorously test the system to identify and resolve defects, ensure it meets all requirements, and prepare for user acceptance testing.
- P5: Deployment & Launch (2 weeks) - Deploy the fully tested system to the production environment and make it available to university users.
- P6: Post-Launch Support & Iteration (Ongoing) - Provide ongoing support, monitor system performance, address issues, and plan for future enhancements based on user feedback.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The primary target users are university students, faculty members, and administrative staff.
- The system will be deployed to a cloud-based infrastructure (e.g., AWS, Azure, GCP).
- Availability of subject matter experts (SMEs) from the university for requirements clarification and UAT.
- The project will initially focus on core course registration functionalities, with advanced features (e.g., payment integration, complex reporting) considered for future phases.
- The university has existing academic calendar data that can be used or integrated.
- A specific project timeline has not been provided and will need to be defined and agreed upon during the Planning & Requirements Gathering phase (P1). The estimated durations provided are indicative and subject to refinement.
- Detailed budget information is not available and will need to be established.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Frontend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Interview notes compiled and summarized
- Initial user stories drafted for key roles (Student, Faculty, Administrator)
- Detailed Functional Requirements Document (FRD) approved by stakeholders

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### Backend Engineer implementation prompt

**Target Role:** Backend Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Implement backend services that support the planned workflows, validation rules, and task sequencing.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5
- P6

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The primary target users are university students, faculty members, and administrative staff.
- The system will be deployed to a cloud-based infrastructure (e.g., AWS, Azure, GCP).
- Availability of subject matter experts (SMEs) from the university for requirements clarification and UAT.
- The project will initially focus on core course registration functionalities, with advanced features (e.g., payment integration, complex reporting) considered for future phases.
- The university has existing academic calendar data that can be used or integrated.
- A specific project timeline has not been provided and will need to be defined and agreed upon during the Planning & Requirements Gathering phase (P1). The estimated durations provided are indicative and subject to refinement.
- Detailed budget information is not available and will need to be established.

**Acceptance Criteria:**
- The Backend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Interview notes compiled and summarized
- Initial user stories drafted for key roles (Student, Faculty, Administrator)
- Detailed Functional Requirements Document (FRD) approved by stakeholders

**Prompt:**
```text
You are a senior backend engineer responsible for building the application services and API layer.

## Project Context
Project name: University Course Registration System
Project description: Build a web-based application to enable university students to register for courses, view their schedules, and manage their enrollments. The system will also allow university administrators and faculty to manage courses, student information, and registration processes.
Domain: software
Project type: software application
Complexity: medium
Summary: A comprehensive project plan for developing a university course registration system, covering phases from requirements gathering to post-launch support. The system will include user authentication, course browsing, student registration, administrative course management, and notification features, built as a generic web application with responsive UI and robust backend APIs.

## Your Role
Backend Engineer

## Goal
Implement backend services that support the planned workflows, validation rules, and task sequencing.

## Technical Scope
API contracts, service logic, validation, error handling, integrations, and backend test coverage.

Relevant tasks:
- T1.1: Stakeholder Interviews & Needs Analysis - Conduct interviews with students, faculty, and university administrators to understand their needs, pain points, and desired functionalities for the course registration system.
- T1.2: Functional Requirements Specification - Document detailed functional requirements including user onboarding, course browsing, registration workflows (add/drop), schedule viewing, course management, student management, and notification triggers.
- T1.3: Non-Functional Requirements Specification - Define non-functional requirements such as performance (e.g., concurrent users during registration), security, scalability, usability, and accessibility.
- T1.4: Technology Stack Selection & Initial Architecture - Evaluate and select appropriate technologies for frontend, backend, database, and deployment. Outline the high-level system architecture.
- T1.5: Project Plan Finalization - Refine the project timeline, resource allocation, and detailed task breakdown based on gathered requirements and architectural decisions.
- T2.1: Database Schema Design - Design the relational database schema for entities like User (Student, Faculty, Admin), Course, Section, Registration, Department, Semester, Prerequisite, and Notification.
- T2.2: Backend API Design - Design RESTful APIs for authentication, user management, course CRUD, registration CRUD, schedule retrieval, and notification management, including request/response formats and error handling.
- T2.3: UI/UX Design & Prototyping - Create wireframes, mockups, and interactive prototypes for key user interfaces, including student dashboard, course catalog, registration forms, admin panels, and notification views, ensuring responsive design.
- T2.4: Security Design - Develop a comprehensive security design covering authentication, authorization (role-based access control), data encryption, input validation, and protection against common web vulnerabilities.
- T3.1: Backend Core Services Development (Authentication & User Management) - Implement authentication APIs (login, registration, password reset) and user management APIs (CRUD for Student, Faculty, Admin accounts) with role-based authorization.
- T3.2: Backend Course & Registration Management Development - Implement CRUD APIs for Courses, Sections, and Registration. Include logic for prerequisites, capacity checks, waitlists, and academic calendar constraints.
- T3.3: Backend Notification & Reporting Development - Implement APIs for generating and managing notifications (e.g., registration confirmation, waitlist updates) and basic reporting (e.g., course rosters, enrollment statistics).
- T3.4: Frontend User Onboarding & Dashboard Development - Develop the frontend for user registration, login, and the student/admin dashboards, displaying relevant information and navigation.
- T3.5: Frontend Course Catalog & Registration Workflow Development - Develop the frontend for browsing courses, viewing course details, adding/dropping courses, and managing student schedules.
- T3.6: Frontend Admin & Faculty Management Panels Development - Develop the frontend interfaces for administrators to manage courses, students, and faculty, and for faculty to manage their assigned courses.
- T3.7: System Integration - Integrate the frontend and backend components, ensuring seamless communication and data flow between them.
- T4.1: Unit Testing - Develop and execute unit tests for individual backend functions and frontend components to ensure they work as expected.
- T4.2: Integration Testing - Develop and execute integration tests to verify the interaction between different modules and services (e.g., frontend-backend communication, database interactions).
- T4.3: End-to-End (E2E) Testing - Develop and execute E2E tests simulating real user workflows (e.g., student registers for a course, admin creates a new course) to ensure the entire system functions correctly.
- T4.4: Performance Testing - Conduct load and stress testing to ensure the system can handle expected user concurrency and data volumes, especially during peak registration periods.
- T4.5: Security Testing - Perform vulnerability scanning, penetration testing, and security audits to identify and mitigate potential security flaws.
- T4.6: User Acceptance Testing (UAT) - Facilitate UAT with a group of actual students, faculty, and administrators to validate the system against their real-world needs and gather feedback.
- T4.7: Bug Fixing & Regression Testing - Address all identified bugs and issues from various testing phases and perform regression testing to ensure fixes do not introduce new problems.
- T5.1: Infrastructure Setup & Configuration - Set up and configure production servers, databases, networking, and security components in the chosen cloud environment.
- T5.2: Deployment Pipeline Setup - Establish a continuous integration/continuous deployment (CI/CD) pipeline for automated and reliable deployments.
- T5.3: Data Migration (if applicable) - Migrate existing student, faculty, and course data from legacy systems into the new database, if required.
- T5.4: Go-Live & System Monitoring - Execute the final deployment to production, make the system publicly accessible, and initiate intensive monitoring.
- T6.1: System Monitoring & Incident Response - Continuously monitor system health, performance, and security. Respond to and resolve any incidents or outages promptly.
- T6.2: Bug Fixes & Minor Enhancements - Address any post-launch bugs and implement minor enhancements or adjustments based on immediate user feedback.
- T6.3: User Feedback Collection & Analysis - Establish channels for collecting user feedback (e.g., support tickets, surveys) and regularly analyze it to identify areas for improvement.
- T6.4: Backlog Grooming & Future Planning - Regularly review the product backlog, prioritize new features and improvements based on feedback and strategic goals for future iterations (e.g., V2).

Risks to account for:
- Scope creep due to evolving stakeholder requirements, leading to project delays and budget overruns.
- Performance issues during peak registration periods (e.g., system slowdowns, crashes) due to high concurrent user load.
- Security vulnerabilities leading to data breaches or unauthorized access to student/course information.
- Lack of clear or conflicting requirements from different university departments/stakeholders.
- Integration challenges with existing university systems (e.g., student information system, payment gateway) if required in future iterations.

Recommendations to preserve:
- Adopt an Agile development methodology (e.g., Scrum or Kanban) to allow for iterative development, continuous feedback, and flexibility in adapting to evolving requirements.
- Utilize a modern, cloud-native technology stack for scalability, reliability, and ease of maintenance.
- Implement a comprehensive automated testing strategy covering unit, integration, and end-to-end tests from the early stages of development.
- Prioritize a user-centric design approach with continuous feedback loops from students, faculty, and administrators.

Assumptions to keep visible:
- The primary target users are university students, faculty members, and administrative staff.
- The system will be deployed to a cloud-based infrastructure (e.g., AWS, Azure, GCP).
- Availability of subject matter experts (SMEs) from the university for requirements clarification and UAT.
- The project will initially focus on core course registration functionalities, with advanced features (e.g., payment integration, complex reporting) considered for future phases.
- The university has existing academic calendar data that can be used or integrated.

## Related Phases
- P1: Planning & Requirements Gathering (3 weeks) - Define the project scope, gather detailed functional and non-functional requirements, and establish the initial technical architecture and project plan.
- P2: Design (4 weeks) - Translate approved requirements into detailed technical designs, including database schema, API specifications, and user interface/experience designs.
- P3: Development (10 weeks) - Implement the backend APIs and frontend user interfaces based on the approved designs, integrating the various system components.
- P4: Testing & Quality Assurance (4 weeks) - Rigorously test the system to identify and resolve defects, ensure it meets all requirements, and prepare for user acceptance testing.
- P5: Deployment & Launch (2 weeks) - Deploy the fully tested system to the production environment and make it available to university users.
- P6: Post-Launch Support & Iteration (Ongoing) - Provide ongoing support, monitor system performance, address issues, and plan for future enhancements based on user feedback.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The primary target users are university students, faculty members, and administrative staff.
- The system will be deployed to a cloud-based infrastructure (e.g., AWS, Azure, GCP).
- Availability of subject matter experts (SMEs) from the university for requirements clarification and UAT.
- The project will initially focus on core course registration functionalities, with advanced features (e.g., payment integration, complex reporting) considered for future phases.
- The university has existing academic calendar data that can be used or integrated.
- A specific project timeline has not been provided and will need to be defined and agreed upon during the Planning & Requirements Gathering phase (P1). The estimated durations provided are indicative and subject to refinement.
- Detailed budget information is not available and will need to be established.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Backend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Interview notes compiled and summarized
- Initial user stories drafted for key roles (Student, Faculty, Administrator)
- Detailed Functional Requirements Document (FRD) approved by stakeholders

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### Database Engineer implementation prompt

**Target Role:** Database Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Define storage structures that support the project requirements without inventing unsupported data sources.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5
- P6

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The primary target users are university students, faculty members, and administrative staff.
- The system will be deployed to a cloud-based infrastructure (e.g., AWS, Azure, GCP).
- Availability of subject matter experts (SMEs) from the university for requirements clarification and UAT.
- The project will initially focus on core course registration functionalities, with advanced features (e.g., payment integration, complex reporting) considered for future phases.
- The university has existing academic calendar data that can be used or integrated.
- A specific project timeline has not been provided and will need to be defined and agreed upon during the Planning & Requirements Gathering phase (P1). The estimated durations provided are indicative and subject to refinement.
- Detailed budget information is not available and will need to be established.

**Acceptance Criteria:**
- The Database Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Interview notes compiled and summarized
- Initial user stories drafted for key roles (Student, Faculty, Administrator)
- Detailed Functional Requirements Document (FRD) approved by stakeholders

**Prompt:**
```text
You are a senior database engineer responsible for designing the data model and persistence approach.

## Project Context
Project name: University Course Registration System
Project description: Build a web-based application to enable university students to register for courses, view their schedules, and manage their enrollments. The system will also allow university administrators and faculty to manage courses, student information, and registration processes.
Domain: software
Project type: software application
Complexity: medium
Summary: A comprehensive project plan for developing a university course registration system, covering phases from requirements gathering to post-launch support. The system will include user authentication, course browsing, student registration, administrative course management, and notification features, built as a generic web application with responsive UI and robust backend APIs.

## Your Role
Database Engineer

## Goal
Define storage structures that support the project requirements without inventing unsupported data sources.

## Technical Scope
Entities, relationships, indexes, migrations, data quality checks, retention needs, and backup assumptions.

Relevant tasks:
- T1.1: Stakeholder Interviews & Needs Analysis - Conduct interviews with students, faculty, and university administrators to understand their needs, pain points, and desired functionalities for the course registration system.
- T1.2: Functional Requirements Specification - Document detailed functional requirements including user onboarding, course browsing, registration workflows (add/drop), schedule viewing, course management, student management, and notification triggers.
- T1.3: Non-Functional Requirements Specification - Define non-functional requirements such as performance (e.g., concurrent users during registration), security, scalability, usability, and accessibility.
- T1.4: Technology Stack Selection & Initial Architecture - Evaluate and select appropriate technologies for frontend, backend, database, and deployment. Outline the high-level system architecture.
- T1.5: Project Plan Finalization - Refine the project timeline, resource allocation, and detailed task breakdown based on gathered requirements and architectural decisions.
- T2.1: Database Schema Design - Design the relational database schema for entities like User (Student, Faculty, Admin), Course, Section, Registration, Department, Semester, Prerequisite, and Notification.
- T2.2: Backend API Design - Design RESTful APIs for authentication, user management, course CRUD, registration CRUD, schedule retrieval, and notification management, including request/response formats and error handling.
- T2.3: UI/UX Design & Prototyping - Create wireframes, mockups, and interactive prototypes for key user interfaces, including student dashboard, course catalog, registration forms, admin panels, and notification views, ensuring responsive design.
- T2.4: Security Design - Develop a comprehensive security design covering authentication, authorization (role-based access control), data encryption, input validation, and protection against common web vulnerabilities.
- T3.1: Backend Core Services Development (Authentication & User Management) - Implement authentication APIs (login, registration, password reset) and user management APIs (CRUD for Student, Faculty, Admin accounts) with role-based authorization.
- T3.2: Backend Course & Registration Management Development - Implement CRUD APIs for Courses, Sections, and Registration. Include logic for prerequisites, capacity checks, waitlists, and academic calendar constraints.
- T3.3: Backend Notification & Reporting Development - Implement APIs for generating and managing notifications (e.g., registration confirmation, waitlist updates) and basic reporting (e.g., course rosters, enrollment statistics).
- T3.4: Frontend User Onboarding & Dashboard Development - Develop the frontend for user registration, login, and the student/admin dashboards, displaying relevant information and navigation.
- T3.5: Frontend Course Catalog & Registration Workflow Development - Develop the frontend for browsing courses, viewing course details, adding/dropping courses, and managing student schedules.
- T3.6: Frontend Admin & Faculty Management Panels Development - Develop the frontend interfaces for administrators to manage courses, students, and faculty, and for faculty to manage their assigned courses.
- T3.7: System Integration - Integrate the frontend and backend components, ensuring seamless communication and data flow between them.
- T4.1: Unit Testing - Develop and execute unit tests for individual backend functions and frontend components to ensure they work as expected.
- T4.2: Integration Testing - Develop and execute integration tests to verify the interaction between different modules and services (e.g., frontend-backend communication, database interactions).
- T4.3: End-to-End (E2E) Testing - Develop and execute E2E tests simulating real user workflows (e.g., student registers for a course, admin creates a new course) to ensure the entire system functions correctly.
- T4.4: Performance Testing - Conduct load and stress testing to ensure the system can handle expected user concurrency and data volumes, especially during peak registration periods.
- T4.5: Security Testing - Perform vulnerability scanning, penetration testing, and security audits to identify and mitigate potential security flaws.
- T4.6: User Acceptance Testing (UAT) - Facilitate UAT with a group of actual students, faculty, and administrators to validate the system against their real-world needs and gather feedback.
- T4.7: Bug Fixing & Regression Testing - Address all identified bugs and issues from various testing phases and perform regression testing to ensure fixes do not introduce new problems.
- T5.1: Infrastructure Setup & Configuration - Set up and configure production servers, databases, networking, and security components in the chosen cloud environment.
- T5.2: Deployment Pipeline Setup - Establish a continuous integration/continuous deployment (CI/CD) pipeline for automated and reliable deployments.
- T5.3: Data Migration (if applicable) - Migrate existing student, faculty, and course data from legacy systems into the new database, if required.
- T5.4: Go-Live & System Monitoring - Execute the final deployment to production, make the system publicly accessible, and initiate intensive monitoring.
- T6.1: System Monitoring & Incident Response - Continuously monitor system health, performance, and security. Respond to and resolve any incidents or outages promptly.
- T6.2: Bug Fixes & Minor Enhancements - Address any post-launch bugs and implement minor enhancements or adjustments based on immediate user feedback.
- T6.3: User Feedback Collection & Analysis - Establish channels for collecting user feedback (e.g., support tickets, surveys) and regularly analyze it to identify areas for improvement.
- T6.4: Backlog Grooming & Future Planning - Regularly review the product backlog, prioritize new features and improvements based on feedback and strategic goals for future iterations (e.g., V2).

Risks to account for:
- Scope creep due to evolving stakeholder requirements, leading to project delays and budget overruns.
- Performance issues during peak registration periods (e.g., system slowdowns, crashes) due to high concurrent user load.
- Security vulnerabilities leading to data breaches or unauthorized access to student/course information.
- Lack of clear or conflicting requirements from different university departments/stakeholders.
- Integration challenges with existing university systems (e.g., student information system, payment gateway) if required in future iterations.

Recommendations to preserve:
- Adopt an Agile development methodology (e.g., Scrum or Kanban) to allow for iterative development, continuous feedback, and flexibility in adapting to evolving requirements.
- Utilize a modern, cloud-native technology stack for scalability, reliability, and ease of maintenance.
- Implement a comprehensive automated testing strategy covering unit, integration, and end-to-end tests from the early stages of development.
- Prioritize a user-centric design approach with continuous feedback loops from students, faculty, and administrators.

Assumptions to keep visible:
- The primary target users are university students, faculty members, and administrative staff.
- The system will be deployed to a cloud-based infrastructure (e.g., AWS, Azure, GCP).
- Availability of subject matter experts (SMEs) from the university for requirements clarification and UAT.
- The project will initially focus on core course registration functionalities, with advanced features (e.g., payment integration, complex reporting) considered for future phases.
- The university has existing academic calendar data that can be used or integrated.

## Related Phases
- P1: Planning & Requirements Gathering (3 weeks) - Define the project scope, gather detailed functional and non-functional requirements, and establish the initial technical architecture and project plan.
- P2: Design (4 weeks) - Translate approved requirements into detailed technical designs, including database schema, API specifications, and user interface/experience designs.
- P3: Development (10 weeks) - Implement the backend APIs and frontend user interfaces based on the approved designs, integrating the various system components.
- P4: Testing & Quality Assurance (4 weeks) - Rigorously test the system to identify and resolve defects, ensure it meets all requirements, and prepare for user acceptance testing.
- P5: Deployment & Launch (2 weeks) - Deploy the fully tested system to the production environment and make it available to university users.
- P6: Post-Launch Support & Iteration (Ongoing) - Provide ongoing support, monitor system performance, address issues, and plan for future enhancements based on user feedback.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The primary target users are university students, faculty members, and administrative staff.
- The system will be deployed to a cloud-based infrastructure (e.g., AWS, Azure, GCP).
- Availability of subject matter experts (SMEs) from the university for requirements clarification and UAT.
- The project will initially focus on core course registration functionalities, with advanced features (e.g., payment integration, complex reporting) considered for future phases.
- The university has existing academic calendar data that can be used or integrated.
- A specific project timeline has not been provided and will need to be defined and agreed upon during the Planning & Requirements Gathering phase (P1). The estimated durations provided are indicative and subject to refinement.
- Detailed budget information is not available and will need to be established.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Database Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Interview notes compiled and summarized
- Initial user stories drafted for key roles (Student, Faculty, Administrator)
- Detailed Functional Requirements Document (FRD) approved by stakeholders

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### QA / Testing Engineer implementation prompt

**Target Role:** QA / Testing Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Create a practical test strategy for the project phases, risks, acceptance criteria, and release workflow.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5
- P6

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The primary target users are university students, faculty members, and administrative staff.
- The system will be deployed to a cloud-based infrastructure (e.g., AWS, Azure, GCP).
- Availability of subject matter experts (SMEs) from the university for requirements clarification and UAT.
- The project will initially focus on core course registration functionalities, with advanced features (e.g., payment integration, complex reporting) considered for future phases.
- The university has existing academic calendar data that can be used or integrated.
- A specific project timeline has not been provided and will need to be defined and agreed upon during the Planning & Requirements Gathering phase (P1). The estimated durations provided are indicative and subject to refinement.
- Detailed budget information is not available and will need to be established.

**Acceptance Criteria:**
- The QA / Testing Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Interview notes compiled and summarized
- Initial user stories drafted for key roles (Student, Faculty, Administrator)
- Detailed Functional Requirements Document (FRD) approved by stakeholders

**Prompt:**
```text
You are a senior QA engineer responsible for validating the implementation against the plan.

## Project Context
Project name: University Course Registration System
Project description: Build a web-based application to enable university students to register for courses, view their schedules, and manage their enrollments. The system will also allow university administrators and faculty to manage courses, student information, and registration processes.
Domain: software
Project type: software application
Complexity: medium
Summary: A comprehensive project plan for developing a university course registration system, covering phases from requirements gathering to post-launch support. The system will include user authentication, course browsing, student registration, administrative course management, and notification features, built as a generic web application with responsive UI and robust backend APIs.

## Your Role
QA / Testing Engineer

## Goal
Create a practical test strategy for the project phases, risks, acceptance criteria, and release workflow.

## Technical Scope
Functional tests, regression tests, edge cases, acceptance criteria validation, risk-based testing, and defect reporting.

Relevant tasks:
- T1.1: Stakeholder Interviews & Needs Analysis - Conduct interviews with students, faculty, and university administrators to understand their needs, pain points, and desired functionalities for the course registration system.
- T1.2: Functional Requirements Specification - Document detailed functional requirements including user onboarding, course browsing, registration workflows (add/drop), schedule viewing, course management, student management, and notification triggers.
- T1.3: Non-Functional Requirements Specification - Define non-functional requirements such as performance (e.g., concurrent users during registration), security, scalability, usability, and accessibility.
- T1.4: Technology Stack Selection & Initial Architecture - Evaluate and select appropriate technologies for frontend, backend, database, and deployment. Outline the high-level system architecture.
- T1.5: Project Plan Finalization - Refine the project timeline, resource allocation, and detailed task breakdown based on gathered requirements and architectural decisions.
- T2.1: Database Schema Design - Design the relational database schema for entities like User (Student, Faculty, Admin), Course, Section, Registration, Department, Semester, Prerequisite, and Notification.
- T2.2: Backend API Design - Design RESTful APIs for authentication, user management, course CRUD, registration CRUD, schedule retrieval, and notification management, including request/response formats and error handling.
- T2.3: UI/UX Design & Prototyping - Create wireframes, mockups, and interactive prototypes for key user interfaces, including student dashboard, course catalog, registration forms, admin panels, and notification views, ensuring responsive design.
- T2.4: Security Design - Develop a comprehensive security design covering authentication, authorization (role-based access control), data encryption, input validation, and protection against common web vulnerabilities.
- T3.1: Backend Core Services Development (Authentication & User Management) - Implement authentication APIs (login, registration, password reset) and user management APIs (CRUD for Student, Faculty, Admin accounts) with role-based authorization.
- T3.2: Backend Course & Registration Management Development - Implement CRUD APIs for Courses, Sections, and Registration. Include logic for prerequisites, capacity checks, waitlists, and academic calendar constraints.
- T3.3: Backend Notification & Reporting Development - Implement APIs for generating and managing notifications (e.g., registration confirmation, waitlist updates) and basic reporting (e.g., course rosters, enrollment statistics).
- T3.4: Frontend User Onboarding & Dashboard Development - Develop the frontend for user registration, login, and the student/admin dashboards, displaying relevant information and navigation.
- T3.5: Frontend Course Catalog & Registration Workflow Development - Develop the frontend for browsing courses, viewing course details, adding/dropping courses, and managing student schedules.
- T3.6: Frontend Admin & Faculty Management Panels Development - Develop the frontend interfaces for administrators to manage courses, students, and faculty, and for faculty to manage their assigned courses.
- T3.7: System Integration - Integrate the frontend and backend components, ensuring seamless communication and data flow between them.
- T4.1: Unit Testing - Develop and execute unit tests for individual backend functions and frontend components to ensure they work as expected.
- T4.2: Integration Testing - Develop and execute integration tests to verify the interaction between different modules and services (e.g., frontend-backend communication, database interactions).
- T4.3: End-to-End (E2E) Testing - Develop and execute E2E tests simulating real user workflows (e.g., student registers for a course, admin creates a new course) to ensure the entire system functions correctly.
- T4.4: Performance Testing - Conduct load and stress testing to ensure the system can handle expected user concurrency and data volumes, especially during peak registration periods.
- T4.5: Security Testing - Perform vulnerability scanning, penetration testing, and security audits to identify and mitigate potential security flaws.
- T4.6: User Acceptance Testing (UAT) - Facilitate UAT with a group of actual students, faculty, and administrators to validate the system against their real-world needs and gather feedback.
- T4.7: Bug Fixing & Regression Testing - Address all identified bugs and issues from various testing phases and perform regression testing to ensure fixes do not introduce new problems.
- T5.1: Infrastructure Setup & Configuration - Set up and configure production servers, databases, networking, and security components in the chosen cloud environment.
- T5.2: Deployment Pipeline Setup - Establish a continuous integration/continuous deployment (CI/CD) pipeline for automated and reliable deployments.
- T5.3: Data Migration (if applicable) - Migrate existing student, faculty, and course data from legacy systems into the new database, if required.
- T5.4: Go-Live & System Monitoring - Execute the final deployment to production, make the system publicly accessible, and initiate intensive monitoring.
- T6.1: System Monitoring & Incident Response - Continuously monitor system health, performance, and security. Respond to and resolve any incidents or outages promptly.
- T6.2: Bug Fixes & Minor Enhancements - Address any post-launch bugs and implement minor enhancements or adjustments based on immediate user feedback.
- T6.3: User Feedback Collection & Analysis - Establish channels for collecting user feedback (e.g., support tickets, surveys) and regularly analyze it to identify areas for improvement.
- T6.4: Backlog Grooming & Future Planning - Regularly review the product backlog, prioritize new features and improvements based on feedback and strategic goals for future iterations (e.g., V2).

Risks to account for:
- Scope creep due to evolving stakeholder requirements, leading to project delays and budget overruns.
- Performance issues during peak registration periods (e.g., system slowdowns, crashes) due to high concurrent user load.
- Security vulnerabilities leading to data breaches or unauthorized access to student/course information.
- Lack of clear or conflicting requirements from different university departments/stakeholders.
- Integration challenges with existing university systems (e.g., student information system, payment gateway) if required in future iterations.

Recommendations to preserve:
- Adopt an Agile development methodology (e.g., Scrum or Kanban) to allow for iterative development, continuous feedback, and flexibility in adapting to evolving requirements.
- Utilize a modern, cloud-native technology stack for scalability, reliability, and ease of maintenance.
- Implement a comprehensive automated testing strategy covering unit, integration, and end-to-end tests from the early stages of development.
- Prioritize a user-centric design approach with continuous feedback loops from students, faculty, and administrators.

Assumptions to keep visible:
- The primary target users are university students, faculty members, and administrative staff.
- The system will be deployed to a cloud-based infrastructure (e.g., AWS, Azure, GCP).
- Availability of subject matter experts (SMEs) from the university for requirements clarification and UAT.
- The project will initially focus on core course registration functionalities, with advanced features (e.g., payment integration, complex reporting) considered for future phases.
- The university has existing academic calendar data that can be used or integrated.

## Related Phases
- P1: Planning & Requirements Gathering (3 weeks) - Define the project scope, gather detailed functional and non-functional requirements, and establish the initial technical architecture and project plan.
- P2: Design (4 weeks) - Translate approved requirements into detailed technical designs, including database schema, API specifications, and user interface/experience designs.
- P3: Development (10 weeks) - Implement the backend APIs and frontend user interfaces based on the approved designs, integrating the various system components.
- P4: Testing & Quality Assurance (4 weeks) - Rigorously test the system to identify and resolve defects, ensure it meets all requirements, and prepare for user acceptance testing.
- P5: Deployment & Launch (2 weeks) - Deploy the fully tested system to the production environment and make it available to university users.
- P6: Post-Launch Support & Iteration (Ongoing) - Provide ongoing support, monitor system performance, address issues, and plan for future enhancements based on user feedback.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The primary target users are university students, faculty members, and administrative staff.
- The system will be deployed to a cloud-based infrastructure (e.g., AWS, Azure, GCP).
- Availability of subject matter experts (SMEs) from the university for requirements clarification and UAT.
- The project will initially focus on core course registration functionalities, with advanced features (e.g., payment integration, complex reporting) considered for future phases.
- The university has existing academic calendar data that can be used or integrated.
- A specific project timeline has not been provided and will need to be defined and agreed upon during the Planning & Requirements Gathering phase (P1). The estimated durations provided are indicative and subject to refinement.
- Detailed budget information is not available and will need to be established.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The QA / Testing Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Interview notes compiled and summarized
- Initial user stories drafted for key roles (Student, Faculty, Administrator)
- Detailed Functional Requirements Document (FRD) approved by stakeholders

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### DevOps Engineer implementation prompt

**Target Role:** DevOps Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Plan environment, build, release, monitoring, and rollback work without deploying anything automatically.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5
- P6

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The primary target users are university students, faculty members, and administrative staff.
- The system will be deployed to a cloud-based infrastructure (e.g., AWS, Azure, GCP).
- Availability of subject matter experts (SMEs) from the university for requirements clarification and UAT.
- The project will initially focus on core course registration functionalities, with advanced features (e.g., payment integration, complex reporting) considered for future phases.
- The university has existing academic calendar data that can be used or integrated.
- A specific project timeline has not been provided and will need to be defined and agreed upon during the Planning & Requirements Gathering phase (P1). The estimated durations provided are indicative and subject to refinement.
- Detailed budget information is not available and will need to be established.

**Acceptance Criteria:**
- The DevOps Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Interview notes compiled and summarized
- Initial user stories drafted for key roles (Student, Faculty, Administrator)
- Detailed Functional Requirements Document (FRD) approved by stakeholders

**Prompt:**
```text
You are a senior DevOps engineer responsible for deployment readiness and operational workflow.

## Project Context
Project name: University Course Registration System
Project description: Build a web-based application to enable university students to register for courses, view their schedules, and manage their enrollments. The system will also allow university administrators and faculty to manage courses, student information, and registration processes.
Domain: software
Project type: software application
Complexity: medium
Summary: A comprehensive project plan for developing a university course registration system, covering phases from requirements gathering to post-launch support. The system will include user authentication, course browsing, student registration, administrative course management, and notification features, built as a generic web application with responsive UI and robust backend APIs.

## Your Role
DevOps Engineer

## Goal
Plan environment, build, release, monitoring, and rollback work without deploying anything automatically.

## Technical Scope
Local development setup, CI checks, configuration, deployment plan, observability, release checklist, and rollback notes.

Relevant tasks:
- T1.1: Stakeholder Interviews & Needs Analysis - Conduct interviews with students, faculty, and university administrators to understand their needs, pain points, and desired functionalities for the course registration system.
- T1.2: Functional Requirements Specification - Document detailed functional requirements including user onboarding, course browsing, registration workflows (add/drop), schedule viewing, course management, student management, and notification triggers.
- T1.3: Non-Functional Requirements Specification - Define non-functional requirements such as performance (e.g., concurrent users during registration), security, scalability, usability, and accessibility.
- T1.4: Technology Stack Selection & Initial Architecture - Evaluate and select appropriate technologies for frontend, backend, database, and deployment. Outline the high-level system architecture.
- T1.5: Project Plan Finalization - Refine the project timeline, resource allocation, and detailed task breakdown based on gathered requirements and architectural decisions.
- T2.1: Database Schema Design - Design the relational database schema for entities like User (Student, Faculty, Admin), Course, Section, Registration, Department, Semester, Prerequisite, and Notification.
- T2.2: Backend API Design - Design RESTful APIs for authentication, user management, course CRUD, registration CRUD, schedule retrieval, and notification management, including request/response formats and error handling.
- T2.3: UI/UX Design & Prototyping - Create wireframes, mockups, and interactive prototypes for key user interfaces, including student dashboard, course catalog, registration forms, admin panels, and notification views, ensuring responsive design.
- T2.4: Security Design - Develop a comprehensive security design covering authentication, authorization (role-based access control), data encryption, input validation, and protection against common web vulnerabilities.
- T3.1: Backend Core Services Development (Authentication & User Management) - Implement authentication APIs (login, registration, password reset) and user management APIs (CRUD for Student, Faculty, Admin accounts) with role-based authorization.
- T3.2: Backend Course & Registration Management Development - Implement CRUD APIs for Courses, Sections, and Registration. Include logic for prerequisites, capacity checks, waitlists, and academic calendar constraints.
- T3.3: Backend Notification & Reporting Development - Implement APIs for generating and managing notifications (e.g., registration confirmation, waitlist updates) and basic reporting (e.g., course rosters, enrollment statistics).
- T3.4: Frontend User Onboarding & Dashboard Development - Develop the frontend for user registration, login, and the student/admin dashboards, displaying relevant information and navigation.
- T3.5: Frontend Course Catalog & Registration Workflow Development - Develop the frontend for browsing courses, viewing course details, adding/dropping courses, and managing student schedules.
- T3.6: Frontend Admin & Faculty Management Panels Development - Develop the frontend interfaces for administrators to manage courses, students, and faculty, and for faculty to manage their assigned courses.
- T3.7: System Integration - Integrate the frontend and backend components, ensuring seamless communication and data flow between them.
- T4.1: Unit Testing - Develop and execute unit tests for individual backend functions and frontend components to ensure they work as expected.
- T4.2: Integration Testing - Develop and execute integration tests to verify the interaction between different modules and services (e.g., frontend-backend communication, database interactions).
- T4.3: End-to-End (E2E) Testing - Develop and execute E2E tests simulating real user workflows (e.g., student registers for a course, admin creates a new course) to ensure the entire system functions correctly.
- T4.4: Performance Testing - Conduct load and stress testing to ensure the system can handle expected user concurrency and data volumes, especially during peak registration periods.
- T4.5: Security Testing - Perform vulnerability scanning, penetration testing, and security audits to identify and mitigate potential security flaws.
- T4.6: User Acceptance Testing (UAT) - Facilitate UAT with a group of actual students, faculty, and administrators to validate the system against their real-world needs and gather feedback.
- T4.7: Bug Fixing & Regression Testing - Address all identified bugs and issues from various testing phases and perform regression testing to ensure fixes do not introduce new problems.
- T5.1: Infrastructure Setup & Configuration - Set up and configure production servers, databases, networking, and security components in the chosen cloud environment.
- T5.2: Deployment Pipeline Setup - Establish a continuous integration/continuous deployment (CI/CD) pipeline for automated and reliable deployments.
- T5.3: Data Migration (if applicable) - Migrate existing student, faculty, and course data from legacy systems into the new database, if required.
- T5.4: Go-Live & System Monitoring - Execute the final deployment to production, make the system publicly accessible, and initiate intensive monitoring.
- T6.1: System Monitoring & Incident Response - Continuously monitor system health, performance, and security. Respond to and resolve any incidents or outages promptly.
- T6.2: Bug Fixes & Minor Enhancements - Address any post-launch bugs and implement minor enhancements or adjustments based on immediate user feedback.
- T6.3: User Feedback Collection & Analysis - Establish channels for collecting user feedback (e.g., support tickets, surveys) and regularly analyze it to identify areas for improvement.
- T6.4: Backlog Grooming & Future Planning - Regularly review the product backlog, prioritize new features and improvements based on feedback and strategic goals for future iterations (e.g., V2).

Risks to account for:
- Scope creep due to evolving stakeholder requirements, leading to project delays and budget overruns.
- Performance issues during peak registration periods (e.g., system slowdowns, crashes) due to high concurrent user load.
- Security vulnerabilities leading to data breaches or unauthorized access to student/course information.
- Lack of clear or conflicting requirements from different university departments/stakeholders.
- Integration challenges with existing university systems (e.g., student information system, payment gateway) if required in future iterations.

Recommendations to preserve:
- Adopt an Agile development methodology (e.g., Scrum or Kanban) to allow for iterative development, continuous feedback, and flexibility in adapting to evolving requirements.
- Utilize a modern, cloud-native technology stack for scalability, reliability, and ease of maintenance.
- Implement a comprehensive automated testing strategy covering unit, integration, and end-to-end tests from the early stages of development.
- Prioritize a user-centric design approach with continuous feedback loops from students, faculty, and administrators.

Assumptions to keep visible:
- The primary target users are university students, faculty members, and administrative staff.
- The system will be deployed to a cloud-based infrastructure (e.g., AWS, Azure, GCP).
- Availability of subject matter experts (SMEs) from the university for requirements clarification and UAT.
- The project will initially focus on core course registration functionalities, with advanced features (e.g., payment integration, complex reporting) considered for future phases.
- The university has existing academic calendar data that can be used or integrated.

## Related Phases
- P1: Planning & Requirements Gathering (3 weeks) - Define the project scope, gather detailed functional and non-functional requirements, and establish the initial technical architecture and project plan.
- P2: Design (4 weeks) - Translate approved requirements into detailed technical designs, including database schema, API specifications, and user interface/experience designs.
- P3: Development (10 weeks) - Implement the backend APIs and frontend user interfaces based on the approved designs, integrating the various system components.
- P4: Testing & Quality Assurance (4 weeks) - Rigorously test the system to identify and resolve defects, ensure it meets all requirements, and prepare for user acceptance testing.
- P5: Deployment & Launch (2 weeks) - Deploy the fully tested system to the production environment and make it available to university users.
- P6: Post-Launch Support & Iteration (Ongoing) - Provide ongoing support, monitor system performance, address issues, and plan for future enhancements based on user feedback.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The primary target users are university students, faculty members, and administrative staff.
- The system will be deployed to a cloud-based infrastructure (e.g., AWS, Azure, GCP).
- Availability of subject matter experts (SMEs) from the university for requirements clarification and UAT.
- The project will initially focus on core course registration functionalities, with advanced features (e.g., payment integration, complex reporting) considered for future phases.
- The university has existing academic calendar data that can be used or integrated.
- A specific project timeline has not been provided and will need to be defined and agreed upon during the Planning & Requirements Gathering phase (P1). The estimated durations provided are indicative and subject to refinement.
- Detailed budget information is not available and will need to be established.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The DevOps Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Interview notes compiled and summarized
- Initial user stories drafted for key roles (Student, Faculty, Administrator)
- Detailed Functional Requirements Document (FRD) approved by stakeholders

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

### Security Reviewer implementation prompt

**Target Role:** Security Reviewer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Review implementation plans for security, privacy, access control, data handling, and compliance risks.

**Related Phases:**
- P1
- P2
- P3
- P4
- P5
- P6

**Constraints:**
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The primary target users are university students, faculty members, and administrative staff.
- The system will be deployed to a cloud-based infrastructure (e.g., AWS, Azure, GCP).
- Availability of subject matter experts (SMEs) from the university for requirements clarification and UAT.
- The project will initially focus on core course registration functionalities, with advanced features (e.g., payment integration, complex reporting) considered for future phases.
- The university has existing academic calendar data that can be used or integrated.
- A specific project timeline has not been provided and will need to be defined and agreed upon during the Planning & Requirements Gathering phase (P1). The estimated durations provided are indicative and subject to refinement.
- Detailed budget information is not available and will need to be established.

**Acceptance Criteria:**
- The Security Reviewer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Interview notes compiled and summarized
- Initial user stories drafted for key roles (Student, Faculty, Administrator)
- Detailed Functional Requirements Document (FRD) approved by stakeholders

**Prompt:**
```text
You are a senior security engineer responsible for reviewing the plan for security and privacy risks.

## Project Context
Project name: University Course Registration System
Project description: Build a web-based application to enable university students to register for courses, view their schedules, and manage their enrollments. The system will also allow university administrators and faculty to manage courses, student information, and registration processes.
Domain: software
Project type: software application
Complexity: medium
Summary: A comprehensive project plan for developing a university course registration system, covering phases from requirements gathering to post-launch support. The system will include user authentication, course browsing, student registration, administrative course management, and notification features, built as a generic web application with responsive UI and robust backend APIs.

## Your Role
Security Reviewer

## Goal
Review implementation plans for security, privacy, access control, data handling, and compliance risks.

## Technical Scope
Threat modeling, authentication and authorization concerns, sensitive data handling, dependency risk, and secure defaults.

Relevant tasks:
- T1.1: Stakeholder Interviews & Needs Analysis - Conduct interviews with students, faculty, and university administrators to understand their needs, pain points, and desired functionalities for the course registration system.
- T1.2: Functional Requirements Specification - Document detailed functional requirements including user onboarding, course browsing, registration workflows (add/drop), schedule viewing, course management, student management, and notification triggers.
- T1.3: Non-Functional Requirements Specification - Define non-functional requirements such as performance (e.g., concurrent users during registration), security, scalability, usability, and accessibility.
- T1.4: Technology Stack Selection & Initial Architecture - Evaluate and select appropriate technologies for frontend, backend, database, and deployment. Outline the high-level system architecture.
- T1.5: Project Plan Finalization - Refine the project timeline, resource allocation, and detailed task breakdown based on gathered requirements and architectural decisions.
- T2.1: Database Schema Design - Design the relational database schema for entities like User (Student, Faculty, Admin), Course, Section, Registration, Department, Semester, Prerequisite, and Notification.
- T2.2: Backend API Design - Design RESTful APIs for authentication, user management, course CRUD, registration CRUD, schedule retrieval, and notification management, including request/response formats and error handling.
- T2.3: UI/UX Design & Prototyping - Create wireframes, mockups, and interactive prototypes for key user interfaces, including student dashboard, course catalog, registration forms, admin panels, and notification views, ensuring responsive design.
- T2.4: Security Design - Develop a comprehensive security design covering authentication, authorization (role-based access control), data encryption, input validation, and protection against common web vulnerabilities.
- T3.1: Backend Core Services Development (Authentication & User Management) - Implement authentication APIs (login, registration, password reset) and user management APIs (CRUD for Student, Faculty, Admin accounts) with role-based authorization.
- T3.2: Backend Course & Registration Management Development - Implement CRUD APIs for Courses, Sections, and Registration. Include logic for prerequisites, capacity checks, waitlists, and academic calendar constraints.
- T3.3: Backend Notification & Reporting Development - Implement APIs for generating and managing notifications (e.g., registration confirmation, waitlist updates) and basic reporting (e.g., course rosters, enrollment statistics).
- T3.4: Frontend User Onboarding & Dashboard Development - Develop the frontend for user registration, login, and the student/admin dashboards, displaying relevant information and navigation.
- T3.5: Frontend Course Catalog & Registration Workflow Development - Develop the frontend for browsing courses, viewing course details, adding/dropping courses, and managing student schedules.
- T3.6: Frontend Admin & Faculty Management Panels Development - Develop the frontend interfaces for administrators to manage courses, students, and faculty, and for faculty to manage their assigned courses.
- T3.7: System Integration - Integrate the frontend and backend components, ensuring seamless communication and data flow between them.
- T4.1: Unit Testing - Develop and execute unit tests for individual backend functions and frontend components to ensure they work as expected.
- T4.2: Integration Testing - Develop and execute integration tests to verify the interaction between different modules and services (e.g., frontend-backend communication, database interactions).
- T4.3: End-to-End (E2E) Testing - Develop and execute E2E tests simulating real user workflows (e.g., student registers for a course, admin creates a new course) to ensure the entire system functions correctly.
- T4.4: Performance Testing - Conduct load and stress testing to ensure the system can handle expected user concurrency and data volumes, especially during peak registration periods.
- T4.5: Security Testing - Perform vulnerability scanning, penetration testing, and security audits to identify and mitigate potential security flaws.
- T4.6: User Acceptance Testing (UAT) - Facilitate UAT with a group of actual students, faculty, and administrators to validate the system against their real-world needs and gather feedback.
- T4.7: Bug Fixing & Regression Testing - Address all identified bugs and issues from various testing phases and perform regression testing to ensure fixes do not introduce new problems.
- T5.1: Infrastructure Setup & Configuration - Set up and configure production servers, databases, networking, and security components in the chosen cloud environment.
- T5.2: Deployment Pipeline Setup - Establish a continuous integration/continuous deployment (CI/CD) pipeline for automated and reliable deployments.
- T5.3: Data Migration (if applicable) - Migrate existing student, faculty, and course data from legacy systems into the new database, if required.
- T5.4: Go-Live & System Monitoring - Execute the final deployment to production, make the system publicly accessible, and initiate intensive monitoring.
- T6.1: System Monitoring & Incident Response - Continuously monitor system health, performance, and security. Respond to and resolve any incidents or outages promptly.
- T6.2: Bug Fixes & Minor Enhancements - Address any post-launch bugs and implement minor enhancements or adjustments based on immediate user feedback.
- T6.3: User Feedback Collection & Analysis - Establish channels for collecting user feedback (e.g., support tickets, surveys) and regularly analyze it to identify areas for improvement.
- T6.4: Backlog Grooming & Future Planning - Regularly review the product backlog, prioritize new features and improvements based on feedback and strategic goals for future iterations (e.g., V2).

Risks to account for:
- Scope creep due to evolving stakeholder requirements, leading to project delays and budget overruns.
- Performance issues during peak registration periods (e.g., system slowdowns, crashes) due to high concurrent user load.
- Security vulnerabilities leading to data breaches or unauthorized access to student/course information.
- Lack of clear or conflicting requirements from different university departments/stakeholders.
- Integration challenges with existing university systems (e.g., student information system, payment gateway) if required in future iterations.

Recommendations to preserve:
- Adopt an Agile development methodology (e.g., Scrum or Kanban) to allow for iterative development, continuous feedback, and flexibility in adapting to evolving requirements.
- Utilize a modern, cloud-native technology stack for scalability, reliability, and ease of maintenance.
- Implement a comprehensive automated testing strategy covering unit, integration, and end-to-end tests from the early stages of development.
- Prioritize a user-centric design approach with continuous feedback loops from students, faculty, and administrators.

Assumptions to keep visible:
- The primary target users are university students, faculty members, and administrative staff.
- The system will be deployed to a cloud-based infrastructure (e.g., AWS, Azure, GCP).
- Availability of subject matter experts (SMEs) from the university for requirements clarification and UAT.
- The project will initially focus on core course registration functionalities, with advanced features (e.g., payment integration, complex reporting) considered for future phases.
- The university has existing academic calendar data that can be used or integrated.

## Related Phases
- P1: Planning & Requirements Gathering (3 weeks) - Define the project scope, gather detailed functional and non-functional requirements, and establish the initial technical architecture and project plan.
- P2: Design (4 weeks) - Translate approved requirements into detailed technical designs, including database schema, API specifications, and user interface/experience designs.
- P3: Development (10 weeks) - Implement the backend APIs and frontend user interfaces based on the approved designs, integrating the various system components.
- P4: Testing & Quality Assurance (4 weeks) - Rigorously test the system to identify and resolve defects, ensure it meets all requirements, and prepare for user acceptance testing.
- P5: Deployment & Launch (2 weeks) - Deploy the fully tested system to the production environment and make it available to university users.
- P6: Post-Launch Support & Iteration (Ongoing) - Provide ongoing support, monitor system performance, address issues, and plan for future enhancements based on user feedback.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- The primary target users are university students, faculty members, and administrative staff.
- The system will be deployed to a cloud-based infrastructure (e.g., AWS, Azure, GCP).
- Availability of subject matter experts (SMEs) from the university for requirements clarification and UAT.
- The project will initially focus on core course registration functionalities, with advanced features (e.g., payment integration, complex reporting) considered for future phases.
- The university has existing academic calendar data that can be used or integrated.
- A specific project timeline has not been provided and will need to be defined and agreed upon during the Planning & Requirements Gathering phase (P1). The estimated durations provided are indicative and subject to refinement.
- Detailed budget information is not available and will need to be established.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Security Reviewer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Interview notes compiled and summarized
- Initial user stories drafted for key roles (Student, Faculty, Administrator)
- Detailed Functional Requirements Document (FRD) approved by stakeholders

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```

## Prompt Quality Evaluations
### Evaluation for EP1

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP2

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP3

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP4

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP5

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.

### Evaluation for EP6

- Score: 100/100
- Ready to use: True

**Strengths:**
- Prompt starts with senior role framing.
- Prompt includes all required structure sections.
- Prompt has enough detail for engineering use.
- Prompt names the target role.
- Prompt identifies target AI coding tools.
- Prompt is tied to related plan phases.
- Prompt purpose is reflected in the prompt text.
- Prompt includes project-specific metadata.
- Prompt includes technical scope.
- Prompt includes meaningful constraints.
- Prompt references risk handling.
- Prompt references implementation tasks.
- Prompt preserves the product boundary.
- Prompt includes an Expected Output section.
- Prompt is positioned for external AI coding tools.
- Prompt keeps engineer review in the workflow.
- Prompt describes the expected deliverable type.
- Prompt includes an Acceptance Criteria section.
- Prompt includes meaningful acceptance criteria.
- Prompt includes multiple acceptance criteria.
- Acceptance criteria include validation or review expectations.

**Issues:**
- No issues recorded.

**Improvement Suggestions:**
- Engineer review recommended before production implementation.
- Validate assumptions and answer clarification questions before production implementation.
