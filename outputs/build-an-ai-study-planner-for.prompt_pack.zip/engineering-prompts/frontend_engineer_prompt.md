# Frontend Engineer implementation prompt

**Target Role:** Frontend Engineer  
**Target Tool:** Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt  
**Purpose:** Implement the frontend experience for the planned project while preserving the validated project scope.

## Related Phases
- P1
- P2
- P3

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Timeline was not specified and should be confirmed.
- This is a draft execution plan generated from incomplete requirements. Answer clarification questions before implementation.

## Acceptance Criteria
- The Frontend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Refine research question is reviewed and accepted by the project lead.
- Define methodology is reviewed and accepted by the project lead.
- Conduct literature review is reviewed and accepted by the project lead.

## Prompt
```text
You are a senior frontend engineer responsible for implementing the user-facing experience.

## Project Context
Project name: Build an AI study planner for
Project description: Build an AI study planner for students
Domain: academic
Project type: research workflow
Complexity: medium
Summary: Draft incomplete plan: A medium complexity research workflow in the academic domain. Requirements are incomplete and should be clarified before implementation.

## Your Role
Frontend Engineer

## Goal
Implement the frontend experience for the planned project while preserving the validated project scope.

## Technical Scope
UI workflows, client-side validation, accessibility, responsive behavior, and integration points with backend APIs.

Relevant tasks:
- T1: Refine research question - Turn the topic into a focused research question.
- T2: Define methodology - Choose research method, data needs, and evaluation approach.
- T3: Conduct literature review - Summarize relevant sources and identify gaps.
- T4: Plan data collection - Define participants, datasets, instruments, and ethics needs.
- T5: Analyze evidence - Apply the selected method and document results.
- T6: Write final deliverable - Prepare paper, report, or presentation.

Risks to account for:
- Project scope may expand beyond the initial plan.
- Missing stakeholder input may lead to rework.

Recommendations to preserve:
- Validate assumptions before execution starts.
- Use milestones as decision gates before expanding scope.

Assumptions to keep visible:
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Timeline was not specified and should be confirmed.

## Related Phases
- P1: Research Framing (1 week) - Define the research question, scope, and expected deliverables.
- P2: Literature and Data Planning (2-4 weeks) - Review prior work and prepare the evidence collection plan.
- P3: Analysis and Delivery (3-6 weeks) - Analyze findings and produce final academic outputs.

## Constraints
- Use the generated project plan as the source of truth.
- Do not build, deploy, or modify software from inside the planner.
- Keep implementation guidance appropriate for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt.
- No AI provider was used; this is a deterministic Phase 1 mock plan.
- Requirements are incomplete; this draft plan must be validated with stakeholders before implementation.
- Timeline was not specified and should be confirmed.
- This is a draft execution plan generated from incomplete requirements. Answer clarification questions before implementation.

## Expected Output
Produce implementation guidance or artifacts for Codex, Cursor, Claude Code, Claude, GitHub Copilot, Lovable, or Bolt. The output should be ready for an engineer to review and apply externally.
The planner itself must not build, deploy, or modify software.

## Acceptance Criteria
- The Frontend Engineer output is aligned with the validated project plan.
- Relevant phases, tasks, assumptions, risks, and recommendations are addressed.
- The output is structured for engineer review before use in an external AI coding tool.
- Refine research question is reviewed and accepted by the project lead.
- Define methodology is reviewed and accepted by the project lead.
- Conduct literature review is reviewed and accepted by the project lead.

## Do Not Do
- Do not build or deploy the application automatically.
- Do not invent requirements, credentials, budgets, deadlines, integrations, or production infrastructure.
- Do not treat this draft as production-ready when requirements are incomplete.
- Do not remove assumptions, warnings, risks, or acceptance criteria from the engineering handoff.
- Do not treat this prompt as a substitute for engineer review.
```
